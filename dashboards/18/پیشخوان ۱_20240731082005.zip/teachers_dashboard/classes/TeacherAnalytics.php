<?php
/**
* @package     local_teachers_dashboard
* @author      Kristian
* @license     http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
* @var stdClass $plugin
*/

class TeacherAnalytics {

    public function teacher_uploaded_content ($user, $plot, $timeGrouping): string
    {
        global $DB, $USER, $PAGE, $CFG, $OUTPUT;
        $uid = $USER->id;
        $username = $USER->username;
        $context = context_system::instance();
        $tempText = '';

        try {
            $PAGE->requires->css('/local/teachers_dashboard/Styles/styles.css');
        } catch (exception $e) {
        }

        if ($plot == 'table') {
            if ($user == 'user') {
                $teacherContentCountQuery = "
                    SELECT DISTINCT f.id as fid, c.fullname, COUNT(DISTINCT f.id) as contentcount, c.fullname as coursename
                    FROM {files} f
                    JOIN {context} cx ON f.contextid = cx.id
                    JOIN {course_modules} cm ON cx.instanceid=cm.id
                    JOIN {course} c ON cm.course=c.id
                    JOIN {resource} r ON r.course = c.id
                    JOIN {user} u ON f.userid = u.id
                    JOIN {role_assignments} ra ON ra.userid = f.userid
                    JOIN {role} role ON role.id = ra.roleid
                    WHERE filename <> '.' AND f.filearea <> 'draft' AND f.userid = {$uid} AND f.author IS NOT null AND f.component = 'mod_resource' AND role.shortname = 'editingteacher' AND u.deleted = 0
                    GROUP BY c.id 
                ";

                $teacherContentCount = array_values($DB->get_records_sql($teacherContentCountQuery));

                $tempText .= '<div id="div_class">'.PHP_EOL.
                    "\t".'<h3 class="main_title">تعداد فایل های بارگذاری شده '.$username.'</h3>'.PHP_EOL.
                    "\t".'<table class="data-table">'.PHP_EOL."\t\t".'<tr>'.PHP_EOL.
                    "\t\t".'<th>نام درس</th>'.PHP_EOL."\t\t".'<th>تعداد فایل ها</th>'.PHP_EOL."\t\t".'</tr>';

                foreach ($teacherContentCount as $content) {
                    $tempText .= '<tr>';
                    $tempText .= '<td>'.$content->coursename.'</td>';
                    $tempText .= '<td>'.$content->contentcount.'</td>';
                    $tempText .= '</tr>';
                }
                $tempText .= "\t".'</table>'.PHP_EOL.'</div>'.'<br>';
            }
            else if ($user == 'all') {
                $teacherContentCountQuery =
                    "SELECT DISTINCT f.id as fid, c.fullname, COUNT(DISTINCT f.id) as contentcount, u.username as username, c.fullname as coursename
                    FROM {files} f
                    JOIN {context} cx ON f.contextid = cx.id
                    JOIN {course_modules} cm ON cx.instanceid=cm.id
                    JOIN {course} c ON cm.course=c.id
                    JOIN {resource} r ON r.course = c.id
                    JOIN {user} u ON f.userid = u.id
                    JOIN {role_assignments} ra ON ra.userid = f.userid
                    JOIN {role} role ON role.id = ra.roleid
                    WHERE filename <> '.' AND f.filearea <> 'draft' AND f.author IS NOT null AND f.component = 'mod_resource' AND role.shortname = 'editingteacher' AND u.deleted = 0
                    GROUP BY c.id, u.id";

                $teacherContentCount = array_values($DB->get_records_sql($teacherContentCountQuery));


                $tempText .= '<div id="div_class">'.PHP_EOL.
                    "\t".'<h3 class="main_title">تعداد فایل های بارگذاری شده مدرسان</h3>'.PHP_EOL.
                    "\t".'<table class="data-table">'.PHP_EOL."\t\t".'<tr>'.PHP_EOL."\t\t".'<th>نام درس</th>'
                    .PHP_EOL."\t\t".'<th>نام کاربری مدرس</th>'.PHP_EOL."\t\t".'<th>تعداد فایل ها</th>'.PHP_EOL."\t\t".'</tr>';

                foreach ($teacherContentCount as $content) {
                    $tempText .= '<tr>';
                    $tempText .= '<td>'.$content->coursename.'</td>';
                    $tempText .= '<td>'.$content->username.'</td>';
                    $tempText .= '<td>'.$content->contentcount.'</td>';
                    $tempText .= '</tr>';
                }
                $tempText .= "\t".'</table>'.PHP_EOL.'</div>'.'<br>';
            }
            else if ($user === 'admin_all_user_self') {
                $roles = get_user_roles($context, $USER->id, true);
                $role = key($roles);
                $rolename = $roles[$role]->shortname;
                if ($rolename === 'manager') {
                    return $this->teacher_uploaded_content('all', $plot, $timeGrouping);
                } else if ($rolename === 'editingteacher') {
                    return $this->teacher_uploaded_content('user', $plot, $timeGrouping);
                }
            }
        } else {

            $daystatement = "FROM_UNIXTIME(f.timecreated, '%j-%H')";

            $chartQuery = '';
            if ($user === 'user') {
                $chartQuery = "
                    SELECT DISTINCT f.id as fid, u.id as uid, {$daystatement} AS state, c.fullname, COUNT(DISTINCT f.id) as contentcount, c.fullname as coursename, u.username as username, WEEK(FROM_UNIXTIME(f.timecreated)) as week_num
                    FROM {files} f
                    JOIN {context} cx ON f.contextid = cx.id
                    JOIN {course_modules} cm ON cx.instanceid=cm.id
                    JOIN {course} c ON cm.course=c.id
                    JOIN {resource} r ON r.course = c.id
                    JOIN {user} u ON f.userid = u.id
                    JOIN {role_assignments} ra ON ra.userid = f.userid
                    JOIN {role} role ON role.id = ra.roleid
                    WHERE filename <> '.' AND f.filearea <> 'draft' AND f.userid = {$uid} AND f.author IS NOT null AND f.component = 'mod_resource' AND role.shortname = 'editingteacher' AND u.deleted = 0
                    GROUP BY c.id, state
                    ORDER BY state";
            } else if ($user === 'all') {
                $chartQuery = "
                    SELECT DISTINCT f.id as fid, u.id as uid, {$daystatement} AS state, c.fullname, COUNT(DISTINCT f.id) as contentcount, u.username as username, c.fullname as coursename, u.username as username, WEEK(FROM_UNIXTIME(f.timecreated)) as week_num
                    FROM {files} f
                    JOIN {context} cx ON f.contextid = cx.id
                    JOIN {course_modules} cm ON cx.instanceid=cm.id
                    JOIN {course} c ON cm.course=c.id
                    JOIN {resource} r ON r.course = c.id
                    JOIN {user} u ON f.userid = u.id
                    JOIN {role_assignments} ra ON ra.userid = f.userid
                    JOIN {role} role ON role.id = ra.roleid
                    WHERE filename <> '.' AND f.filearea <> 'draft' AND f.author IS NOT null AND f.component = 'mod_resource' AND role.shortname = 'editingteacher' AND u.deleted = 0
                    GROUP BY u.id, c.id, state
                    ORDER BY state";
            } else if ($user === 'admin_all_user_self') {
                $roles = get_user_roles($context, $USER->id, true);
                $role = key($roles);
                $rolename = $roles[$role]->shortname;
                if ($rolename === 'manager') {
                    return $this->teacher_uploaded_content('all', $plot, $timeGrouping);
                } else if ($rolename === 'editingteacher') {
                    return $this->teacher_uploaded_content('user', $plot, $timeGrouping);
                }
            }

            $teacherContentCount = array_values($DB->get_records_sql($chartQuery));

            $courseGroupedContentCount = [];
            foreach ($teacherContentCount as $content) {
                $courseGroupedContentCount[$content->coursename][] = $content;
            }
            $timeText = 'روزانه';
            if ($timeGrouping === 'weekly') $timeText = 'هفتگی';

            if ($user === 'user') {
                $tempText .= '<div id="div_class">'.PHP_EOL.
                    "\t".'<h3 class="main_title">تعداد فایل های بارگذاری شده '.$username.' به صورت '.$timeText.'</h3>';
            } else {
                $tempText .= '<div id="div_class">'.PHP_EOL.
                    "\t".'<h3 class="main_title">تعداد فایل های بارگذاری شده مدرسان به صورت '.$timeText.'</h3>';
            }

            foreach ($courseGroupedContentCount as $course => $content) {
                $mainGroupedResult = [];
                if ($timeGrouping === 'daily') {
                    foreach ($content as $res) {
                        $mainGroupedResult[(int)(explode('-', $res->state)[0])][] = $res;
                    }
                } else {
                    foreach ($content as $res) {
                        $mainGroupedResult[$res->week_num][] = $res;
                    }
                }

                $mainResultArray = [];
                foreach ($mainGroupedResult as $time => $results) {
                    $totalCount = 0;
                    foreach ($results as $currentRes) {
                        $totalCount += $currentRes->contentcount;
                    }
                    $arrayValue = new stdClass();
                    $arrayValue->course = $course;
                    $arrayValue->contentcount = $totalCount;
                    $arrayValue->username = $results[0]->username;
                    $mainResultArray[$time] = $arrayValue;
                }

                $groupX = [];
                $groupY = [];
                $currentTeacher = '';
                foreach ($mainResultArray as $time => $res) {
                    $currentTeacher = $res->username;
                    array_push($groupX, $time);
                    array_push($groupY, $res->contentcount);
                }

                if ($plot == 'line_sharp') {
                    $chart = new \core\chart_line();
                }
                else if ($plot == 'line_smooth') {
                    $chart = new \core\chart_line();
                    $chart->set_smooth(true);

                } else if ($plot == 'pie') {
                    $chart = new \core\chart_pie();

                } else if ($plot == 'doughnut') {
                    $chart = new \core\chart_pie();
                    $chart->set_doughnut(true);

                } else if ($plot == 'bar') {
                    $chart = new \core\chart_bar();
                }

                $series = new \core\chart_series($course, $groupY);
                $chart->add_series($series);
                $chart->set_labels($groupX);
                if ($plot !== 'pie' && $plot !== 'doughnut') $chart->get_yaxis(0, true)->set_min(0);

                if ($plot !== 'pie' && $plot !== 'doughnut') $chart->set_title(' تعداد فایل های بارگذاری شده '.$currentTeacher);
                else $chart->set_title(' تعداد فایل های بارگذاری شده '.$currentTeacher.' در دوره '.$course);

                $tempText .= $OUTPUT->render($chart).'<br>';
            }
            $tempText .= "\t\t".'</div>'.'<br>';
        }
        return $tempText;

	}
    public function teacher_activities ($user, $plot, $group): string {
        global $DB, $USER, $PAGE, $CFG, $OUTPUT;
        $uid = $USER->id;
        $username = $USER->username;
        $tempText = '';
        $context = context_system::instance();

        try {
            $PAGE->requires->css('/local/teachers_dashboard/Styles/styles.css');
        } catch (exception $e) {
        }
        if ($plot == 'table') {
            if ($user == 'user') {
                $teacherActivityQuery =
                    "SELECT c.fullname AS coursename, m.name AS activityname, COUNT(DISTINCT cm.id) AS activitycount
                    FROM {user} u
                    JOIN {user_enrolments} ue ON ue.userid = u.id
                    JOIN {enrol} e ON e.id = ue.enrolid
                    JOIN {course} c ON c.id = e.courseid
                    JOIN {course_modules} cm ON cm.course = c.id
                    JOIN {modules} m ON m.id = cm.module
                    JOIN {role_assignments} ra ON ue.userid = ra.userid
                    JOIN {role} r ON ra.roleid = r.id
                    LEFT OUTER JOIN {course_modules_completion} cmc ON cmc.coursemoduleid = cm.id
                    WHERE u.id = {$uid} AND (r.shortname = 'editingteacher')
                    GROUP BY c.id
                    ORDER BY activitycount DESC";

                $teacherActivity = array_values($DB->get_records_sql($teacherActivityQuery));

                $tempText .= '<div id="div_class">'.PHP_EOL.
                    "\t".'<h3 class="main_title">تعداد فعالیت های '.$username.'</h3>'.PHP_EOL.
                    "\t".'<table class="data-table">'.PHP_EOL."\t\t".'<tr>'.PHP_EOL.
                    "\t\t".'<th>نام دوره</th>'.PHP_EOL."\t\t".'<th>تعداد فعالیت ها</th>'.PHP_EOL."\t\t".'</tr>';

                foreach ($teacherActivity as $activity) {
                    $tempText .= '<tr>';
                    $tempText .= '<td>'.$activity->coursename.'</td>';
                    $tempText .= '<td>'.$activity->activitycount.'</td>';
                    $tempText .= '</tr>';
                }
            } else if ($user === 'all') {
                $teacherActivityQuery =
                    "SELECT c.id as cid, u.id as uid, u.username AS username, c.fullname AS coursename, m.name AS activityname, COUNT(DISTINCT cm.id) AS activitycount
                    FROM {user} u
                    JOIN {user_enrolments} ue ON ue.userid = u.id
                    JOIN {enrol} e ON e.id = ue.enrolid
                    JOIN {course} c ON c.id = e.courseid
                    JOIN {course_modules} cm ON cm.course = c.id
                    JOIN {modules} m ON m.id = cm.module
                    JOIN {role_assignments} ra ON u.id = ra.userid
                    JOIN {role} r ON ra.roleid = r.id
                    LEFT OUTER JOIN {course_modules_completion} cmc ON cmc.coursemoduleid = cm.id
                    WHERE (r.shortname = 'editingteacher')
                    GROUP BY u.id, c.id
                    ORDER BY activitycount DESC";

                $teacherActivity = array_values($DB->get_records_sql($teacherActivityQuery));

                $tempText .= '<div id="div_class">'.PHP_EOL.
                    "\t".'<h3 class="main_title">تعداد فعالیت های تمام مدرسان</h3>'.PHP_EOL.
                    "\t".'<table class="data-table">'.PHP_EOL."\t\t".'<tr>'.PHP_EOL."\t\t".'<th>نام    کاربری</th>'.
                    PHP_EOL."\t\t".'<th>نام دوره</th>'.PHP_EOL."\t\t".'<th>تعداد فعالیت ها</th>'.PHP_EOL."\t\t".'</tr>';

                foreach ($teacherActivity as $activity) {
                    $tempText .= '<tr>';
                    $tempText .= '<td>'.$activity->username.'</td>';
                    $tempText .= '<td>'.$activity->coursename.'</td>';
                    $tempText .= '<td>'.$activity->activitycount.'</td>';
                    $tempText .= '</tr>';
                }
            }
            else if ($user === 'admin_all_user_self') {
                $roles = get_user_roles($context, $USER->id, true);
                $role = key($roles);
                $rolename = $roles[$role]->shortname;
                if ($rolename === 'manager') {
                    return $this->teacher_activities('all', $plot, $group);
                } else if ($rolename === 'editingteacher') {
                    return $this->teacher_activities('user', $plot, $group);
                }
            }
            $tempText .= "\t".'</table>'.PHP_EOL.'</div>'."<br>";
        } else {
            $daystatement = "FROM_UNIXTIME(cm.added, '%j-%H')";

            $chartQuery = '';
            if ($user == 'user') {
                $chartQuery = "
                    SELECT cm.id, {$daystatement} AS state, c.id as cid, u.id AS uid, u.username AS username, c.fullname AS coursename, m.name AS activityname, COUNT(DISTINCT cm.id) AS activitycount, WEEK(FROM_UNIXTIME(cm.added)) as week_num
                    FROM {user} u
                    JOIN {user_enrolments} ue ON ue.userid = u.id
                    JOIN {enrol} e ON e.id = ue.enrolid
                    JOIN {course} c ON c.id = e.courseid
                    JOIN {course_modules} cm ON cm.course = c.id
                    JOIN {modules} m ON m.id = cm.module
                    JOIN {role_assignments} ra ON ue.userid = ra.userid
                    JOIN {role} r ON ra.roleid = r.id
                    LEFT OUTER JOIN {course_modules_completion} cmc ON cmc.coursemoduleid = cm.id
                    WHERE u.id = {$uid} AND (r.shortname = 'editingteacher')
                    GROUP BY c.id, state
                    ORDER BY state";
            } else if ($user === 'all') {
                $chartQuery = "
                    SELECT cm.id, {$daystatement} AS state, u.id AS uid, c.id as cid, u.username AS username, c.fullname AS coursename, m.name AS activityname, COUNT(DISTINCT cm.id) AS activitycount, WEEK(FROM_UNIXTIME(cm.added)) as week_num
                    FROM {user} u
                    JOIN {user_enrolments} ue ON ue.userid = u.id
                    JOIN {enrol} e ON e.id = ue.enrolid
                    JOIN {course} c ON c.id = e.courseid
                    JOIN {course_modules} cm ON cm.course = c.id
                    JOIN {modules} m ON m.id = cm.module
                    JOIN {role_assignments} ra ON u.id = ra.userid
                    JOIN {role} r ON ra.roleid = r.id
                    LEFT OUTER JOIN {course_modules_completion} cmc ON cmc.coursemoduleid = cm.id
                    WHERE (r.shortname = 'editingteacher')
                    GROUP BY u.id, c.id, state
                    ORDER BY state";
            }
            else if ($user === 'admin_all_user_self') {
                $roles = get_user_roles($context, $USER->id, true);
                $role = key($roles);
                $rolename = $roles[$role]->shortname;
                if ($rolename === 'manager') {
                    return $this->teacher_activities('all', $plot, $group);
                } else if ($rolename === 'editingteacher') {
                    return $this->teacher_activities('user', $plot, $group);
                }
            }


            $teacherActivity = array_values($DB->get_records_sql($chartQuery));

            $groupedArray = array();
            foreach ($teacherActivity as $activity) {
                $groupedArray[$activity->cid][] = $activity;
            }

            $mainResults = [];
            foreach ($groupedArray as $course => $activities) {
                $timedResultArray = [];

                if ($group === 'daily') {
                    foreach ($activities as $activity) {
                        $timedResultArray[(int)(explode('-', $activity->state)[0])][] = $activity;
                    }
                } else {
                    foreach ($activities as $activity) {
                        $timedResultArray[$activity->week_num][] = $activity;
                    }
                }

                $totalResultArray = [];
                $teacherName = null;
                foreach ($timedResultArray as $time => $activity) {
                    $total = 0;
                    foreach ($activity as $current) {
                        if (is_null($teacherName)) $teacherName = $current->username;
                        $total += $current->activitycount;
                    }
                    $totalResultArray[$time] = $total;
                }


                $value = new stdClass();
                $value->course = $DB->get_record('course', ['id'=>$course])->fullname;
                $value->result = $totalResultArray;
                $value->username = $teacherName;

                $mainResults[] = $value;

            }

            $timeText = 'روزانه';
            if ($group === 'weekly') $timeText = 'هفتگی';

            if ($user === 'user') {
                $tempText .= '<div id="div_class">'.PHP_EOL.
                    "\t".'<h3 class="main_title">تعداد فعالیت های انجام شده توسط '.$USER->username.' به  صورت '.$timeText.'</h3>';
            } else {
                $tempText .= '<div id="div_class">'.PHP_EOL.
                    "\t".'<h3 class="main_title">تعداد فعالیت های انجام شده تمام مدرسان به صورت '.$timeText.'</h3>';
            }


            foreach ($mainResults as $result) {
                $mainCourse = $result->course;
                $teacherName = $result->username;

                $groupX = [];
                $groupY = [];
                foreach ($result->result as $time => $activity) {
                    array_push($groupX, $time);
                    array_push($groupY, $activity);
                }

                if ($plot == 'line_sharp') {
                    $chart = new \core\chart_line();
                } else if ($plot == 'line_smooth') {
                    $chart = new \core\chart_line();
                    $chart->set_smooth(true);

                } else if ($plot == 'pie') {
                    $chart = new \core\chart_pie();

                } else if ($plot == 'doughnut') {
                    $chart = new \core\chart_pie();
                    $chart->set_doughnut(true);

                } else if ($plot == 'bar') {
                    $chart = new \core\chart_bar();
                }

                $series = new \core\chart_series($mainCourse, $groupY);
                $chart->add_series($series);
                $chart->set_labels($groupX);
                if ($plot !== 'pie' && $plot !== 'doughnut') $chart->set_title(' تعداد فعالیت های '.$teacherName);
                else $chart->set_title(' تعداد فعالیت های '.$teacherName.' در دوره '.$mainCourse);


                if ($plot !== 'pie' && $plot !== 'doughnut') $chart->get_yaxis(0, true)->set_min(0);

                $tempText .= $OUTPUT->render($chart).'<br>';
            }

            $tempText .= "\t\t".'</div>'."<br>";
        }
        return $tempText;

	}
    public function teacher_times_pent ($user, $plot, $timeGrouping): string {
        global $DB, $USER, $PAGE, $CFG, $OUTPUT, $username;
        $uid = $USER->id;
        $username = $USER->username;
        $tempText = '';
        $context = context_system::instance();

        try {
            $PAGE->requires->css('/local/teachers_dashboard/Styles/styles.css');
        } catch (exception $e) {
        }

        if ($plot === 'total') {
            $daystatement = "FROM_UNIXTIME(l.timecreated, '%j-%H')";

            $tempText .= '<div id="div_class">'.PHP_EOL."\t";

            if ($user === 'user') {
                $tempText .= '<h3 class="main_title">مجموع مدت زمان سپری شده در سامانه برای '.$username.'</h3>';

                $timeSpentQuery =
                    "SELECT {$daystatement} AS state, u.id, ROUND((MAX(l.timecreated) - MIN(l.timecreated))/3600, 2) AS hours
                    FROM {logstore_standard_log} l
                    JOIN {user} u ON l.userid = u.id
                    WHERE u.id = {$uid}
                    GROUP BY state";
                $teacherTimeSpent = array_values($DB->get_records_sql($timeSpentQuery));

                $mainTotalTime = 0;
                foreach ($teacherTimeSpent AS $times) $mainTotalTime += $times->hours;

                if ($mainTotalTime > 0) {
                    $tempText .= '<h3 >'.$mainTotalTime.' (ساعت)</h3>';
                } else {
                    $tempText .= '<h3>.هیچ زمانی را در سامانه سپری نکرده است '.$username.'</h3><br>';
                }
            } else if ($user === 'all') {
                $allUsers = $DB->get_records('user');
                $tempText .= '<h3 class="main_title">مجموع مدت زمان سپری شده در سامانه برای تمام مدرسان</h3>';

                $tempText .= '<table class="data-table">'.PHP_EOL."\t\t".'<tr>'.PHP_EOL."\t\t".'<th>نام کاربری</th>'.
                    PHP_EOL."\t\t".'<th>مجموع مدت زمان ها (ساعت)</th>'.PHP_EOL."\t\t".'</tr>';

                $groupedUsers = [];
                $context = context_system::instance();
                foreach ($allUsers as $currentUser) {
                    $roles = get_user_roles($context, $currentUser->id, true);
                    $role = key($roles);
                    $rolename = null;
                    if (isset($roles[$role])) {
                        $rolename = $roles[$role]->shortname;
                    }
                    if ($rolename === 'editingteacher') {
                        $timeSpentQuery =
                            "SELECT {$daystatement} AS state, (ROUND((MAX(l.timecreated) - MIN(l.timecreated))/3600, 2)) AS hours
                            FROM {logstore_standard_log} l
                            WHERE l.userid = {$currentUser->id}
                            GROUP BY state
                            ORDER BY state ";
                        $teacherTimeSpent = array_values($DB->get_records_sql($timeSpentQuery));

                        $mainTotalTime = 0;
                        foreach ($teacherTimeSpent AS $times) $mainTotalTime += $times->hours;
                        $groupedUsers[$currentUser->username] = number_format($mainTotalTime, 2, '.', '');
                    }
                }
                foreach ($groupedUsers as $name => $userTimes) {
                    $tempText .= '<tr>';
                    $tempText .= '<td>'.$name.'</td>';
                    $tempText .= '<td>'.$userTimes.'</td>';
                    $tempText .= '</tr>';
                }
                $tempText .= '</table>'.PHP_EOL;
            } else if ($user === 'admin_all_user_self') {
                $roles = get_user_roles($context, $USER->id, true);
                $role = key($roles);
                $rolename = $roles[$role]->shortname;
                if ($rolename === 'manager') {
                    return $this->teacher_times_pent('all', $plot, $timeGrouping);
                } else if ($rolename === 'editingteacher') {
                    return $this->teacher_times_pent('user', $plot, $timeGrouping);
                }
            }
            $tempText .= PHP_EOL.'</div>'."<br>";
        } else {
            $timeText = 'روزانه';
            if ($timeGrouping === 'weekly') $timeText = 'هفتگی';

            $daystatement = "FROM_UNIXTIME(l.timecreated, '%j-%H')";

            $mainResult = [];
            if ($user === 'user') {
                $tempText .= '<div id="div_class">'.PHP_EOL."\t";
                $tempText .= '<h3 class="main_title">مدت زمان سپری شده در سامانه برای '.$username.' به صورت '.$timeText.'</h3>';

                $timeSpentQuery =
                    "SELECT {$daystatement} AS state, u.id AS uid, u.username AS username, ROUND((MAX(l.timecreated) - MIN(l.timecreated))/3600, 2) AS hours, WEEK(FROM_UNIXTIME(l.timecreated)) as week_num
                    FROM {logstore_standard_log} l
                    JOIN {user} u ON l.userid = u.id
                    WHERE u.id = {$uid}
                    GROUP BY state
                    ORDER BY state";

                $mainResult = array_values($DB->get_records_sql($timeSpentQuery));

                $mainGroupedResult = [];
                if ($timeGrouping === 'daily') {
                    foreach ($mainResult as $res) {
                        $mainGroupedResult[(int)(explode('-', $res->state)[0])][] = $res;
                    }
                    foreach ($mainGroupedResult as $day => $result) {
                        $dayTotal = 0;
                        foreach ($result as $res) {
                            $dayTotal += $res->hours;
                        }
                        $mainGroupedResult[$day] = number_format($dayTotal, 2, '.', '');
                    }
                } else {
                    $weeklyGroupedResults = [];
                    foreach ($mainResult as $res) {
                        $weeklyGroupedResults[$res->week_num][] = $res;
                    }
                    foreach ($weeklyGroupedResults as $weekNum => $weekRes) {
                        $total_week = 0;
                        foreach ($weekRes as $currentWeek) {
                            $total_week += $currentWeek->hours;
                        }
                        $mainGroupedResult[$weekNum] = number_format($total_week, 2, '.', '');
                    }
                }
                if ($plot == 'line_sharp') {
                    $chart = new \core\chart_line();
                } else if ($plot == 'line_smooth') {
                    $chart = new \core\chart_line();
                    $chart->set_smooth(true);

                } else if ($plot == 'pie') {
                    $chart = new \core\chart_pie();

                } else if ($plot == 'doughnut') {
                    $chart = new \core\chart_pie();
                    $chart->set_doughnut(true);

                } else if ($plot == 'bar') {
                    $chart = new \core\chart_bar();
                }
                $groupX = [];
                $groupY = [];
                foreach ($mainGroupedResult as $grouping => $content) {
                    array_push($groupY, $content);
                    array_push($groupX, $grouping);
                }
                if (count($groupY) > 0) {
                    $series = new \core\chart_series($username, $groupY);
                    $chart->add_series($series);
                    $chart->set_labels($groupX);
                    $chart->set_title(' مدت زمان سپری شده '.$username.' در سامانه ');

                    if ($plot !== 'pie' && $plot !== 'doughnut') $chart->get_yaxis(0, true)->set_min(0);

                    $tempText .= $OUTPUT->render($chart).'<br>';
                } else {
                    $tempText .= '<h3>'.$username.' هیچ زمانی را در سامانه سپری نکرده است.</h3><br>';
                }


                $tempText .= "\t\t".'</div>'."<br>";

            } else if ($user === 'all') {
                $allUsers = $DB->get_records('user');

                $tempText .= '<div id="div_class">'.PHP_EOL."\t";
                $tempText .= '<h3 class="main_title">مجموع مدت زمان سپری شده در سامانه برای تمام مدرسان به صورت '.$timeText.'</h3>';

                $groupedUsers = [];
                $context = context_system::instance();
                foreach ($allUsers as $currentUser) {
                    $roles = get_user_roles($context, $currentUser->id, true);
                    $role = key($roles);
                    $rolename = null;
                    if (isset($roles[$role])) {
                        $rolename = $roles[$role]->shortname;
                    }
                    if ($rolename === 'editingteacher') {
                        $timeSpentQuery =
                            "SELECT {$daystatement} AS state, (ROUND((MAX(l.timecreated) - MIN(l.timecreated))/3600, 2)) AS hours, WEEK(FROM_UNIXTIME(l.timecreated)) as week_num
                            FROM {logstore_standard_log} l
                            WHERE l.userid = {$currentUser->id}
                            GROUP BY state
                            ORDER BY state ";
                        $teacherTimeSpent = array_values($DB->get_records_sql($timeSpentQuery));

                        $groupedUsers[$currentUser->username] = $teacherTimeSpent;
                    }
                }

                $mainGroupedResult = [];
                if ($timeGrouping === 'daily') {
                    foreach ($groupedUsers as $user => $result) {

                        $timeGroupResult = [];
                        foreach ($result as $res) {
                            $timeGroupResult[(int)(explode('-', $res->state)[0])][] = $res;
                        }

                        foreach ($timeGroupResult as $time => $res) {
                            $totalTime = 0;
                            foreach ($res as $results) {
                                $totalTime += $results->hours;
                            }
                            $timeGroupResult[$time] = $totalTime;
                        }
                        $mainGroupedResult[$user] = $timeGroupResult;
                    }
                } else {
                    foreach ($groupedUsers as $user => $result) {

                        $timeGroupResult = [];
                        foreach ($result as $res) {
                            $timeGroupResult[$res->week_num][] = $res;
                        }

                        foreach ($timeGroupResult as $time => $res) {
                            $totalTime = 0;
                            foreach ($res as $results) {
                                $totalTime += $results->hours;
                            }
                            $timeGroupResult[$time] = $totalTime;
                        }
                        $mainGroupedResult[$user] = $timeGroupResult;
                    }
                }

                foreach ($mainGroupedResult as $timeGroupName => $userTimes) {

                    if ($plot == 'line_sharp') {
                        $chart = new \core\chart_line();
                    } else if ($plot == 'line_smooth') {
                        $chart = new \core\chart_line();
                        $chart->set_smooth(true);

                    } else if ($plot == 'pie') {
                        $chart = new \core\chart_pie();

                    } else if ($plot == 'doughnut') {
                        $chart = new \core\chart_pie();
                        $chart->set_doughnut(true);

                    } else if ($plot == 'bar') {
                        $chart = new \core\chart_bar();
                    }

                    $groupX = [];
                    $groupY = [];
                    foreach ($userTimes as $time => $content) {
                        array_push($groupX, $time);
                        array_push($groupY, $content);
                    }

                    if (count($groupY) > 0) {
                        $series = new \core\chart_series($timeGroupName, $groupY);

                        $chart->add_series($series);
                        $chart->set_labels($groupX);
                        $chart->set_title(' مدت زمان سپری شده در سامانه برای '.$timeGroupName);
                        if ($plot !== 'pie' && $plot !== 'doughnut') $chart->get_yaxis(0, true)->set_min(0);

                        $tempText .= $OUTPUT->render($chart).'<br>';
                    } else {
                        $tempText .= '<h3>'.$timeGroupName.' هیچ زمانی را در سامانه سپری نکرده است.</h3><br>';
                    }
                }

                $tempText .= "\t\t".'</div>'."<br>";
            }  else if ($user === 'admin_all_user_self') {
                $roles = get_user_roles($context, $USER->id, true);
                $role = key($roles);
                $rolename = $roles[$role]->shortname;
                if ($rolename === 'manager') {
                    return $this->teacher_times_pent('all', $plot, $timeGrouping);
                } else if ($rolename === 'editingteacher') {
                    return $this->teacher_times_pent('user', $plot, $timeGrouping);
                }
            }
        }
        return $tempText;

	}
    public function teacher_average_times_pent ($user, $plot, $timeGrouping): string {
        global $DB, $USER, $PAGE, $CFG, $OUTPUT, $username;
        $uid = $USER->id;
        $username = $USER->username;
        $tempText = '';
        $context = context_system::instance();

        try {
            $PAGE->requires->css('/local/teachers_dashboard/Styles/styles.css');
        } catch (exception $e) {
        }

        if ($plot === 'total') {
            $daystatement = "FROM_UNIXTIME(l.timecreated, '%j-%H')";

            $tempText .= '<div id="div_class">'.PHP_EOL."\t";

            if ($user === 'user') {
                $tempText .= '<h3 class="main_title">میانگین مدت زمان سپری شده در سامانه برای '.$username.'</h3>';

                $timeSpentQuery =
                    "SELECT {$daystatement} AS state, u.id, ROUND((MAX(l.timecreated) - MIN(l.timecreated))/3600, 2) AS hours
                    FROM {logstore_standard_log} l
                    JOIN {user} u ON l.userid = u.id
                    WHERE u.id = {$uid}
                    GROUP BY state";
                $countQuery = "
                    SELECT COUNT(DISTINCT l.eventname) as cnt
                    FROM {logstore_standard_log} l
                    WHERE l.userid = {$uid}
                ";
                $teacherTimeSpent = array_values($DB->get_records_sql($timeSpentQuery));
                $countSpent = array_values($DB->get_records_sql($countQuery));

                $mainTotalTime = 0;
                foreach ($teacherTimeSpent AS $times) $mainTotalTime += $times->hours;

                if ($mainTotalTime > 0) {
                    $avgResult = ($mainTotalTime) / $countSpent[0]->cnt;
                    $tempText .= '<h3 >'.number_format($avgResult, 2, '.', '').' (ساعت)</h3>';
                } else {
                    $tempText .= '<h3>.هیچ زمانی را در سامانه سپری نکرده است '.$username.'</h3><br>';
                }
            } else if ($user === 'all') {
                $allUsers = $DB->get_records('user');
                $tempText .= '<h3 class="main_title">میانگین مدت زمان سپری شده در سامانه برای تمام مدرسان</h3>';

                $tempText .= '<table class="data-table">'.PHP_EOL."\t\t".'<tr>'.PHP_EOL."\t\t".'<th>نام کاربری</th>'.
                    PHP_EOL."\t\t".'<th>میانگین مدت زمان ها (ساعت)</th>'.PHP_EOL."\t\t".'</tr>';

                $groupedUsers = [];
                $context = context_system::instance();
                foreach ($allUsers as $currentUser) {
                    $roles = get_user_roles($context, $currentUser->id, true);
                    $role = key($roles);
                    $rolename = null;
                    if (isset($roles[$role])) {
                        $rolename = $roles[$role]->shortname;
                    }
                    if ($rolename === 'editingteacher') {
                        $timeSpentQuery =
                            "SELECT {$daystatement} AS state, (ROUND((MAX(l.timecreated) - MIN(l.timecreated))/3600, 2)) AS hours
                            FROM {logstore_standard_log} l
                            WHERE l.userid = {$currentUser->id}
                            GROUP BY state
                            ORDER BY state ";
                        $countQuery = "
                                    SELECT COUNT(DISTINCT l.eventname) as cnt
                                    FROM {logstore_standard_log} l
                                    WHERE l.userid = {$currentUser->id}
                                ";
                        $teacherTimeSpent = array_values($DB->get_records_sql($timeSpentQuery));
                        $countSpent = array_values($DB->get_records_sql($countQuery));

                        $mainTotalTime = 0;
                        foreach ($teacherTimeSpent AS $times) $mainTotalTime += $times->hours;

                        $avgTimeResult = 0;
                        if ($countSpent[0]->cnt > 0)
                            $avgTimeResult = $mainTotalTime / $countSpent[0]->cnt;

                        $groupedUsers[$currentUser->username] = number_format($avgTimeResult, 2, '.', '');
                    }
                }
                foreach ($groupedUsers as $name => $userTimes) {
                    $tempText .= '<tr>';
                    $tempText .= '<td>'.$name.'</td>';
                    $tempText .= '<td>'.$userTimes.'</td>';
                    $tempText .= '</tr>';
                }
                $tempText .= '</table>'.PHP_EOL;
            } else if ($user === 'admin_all_user_self') {
                $roles = get_user_roles($context, $USER->id, true);
                $role = key($roles);
                $rolename = $roles[$role]->shortname;
                if ($rolename === 'manager') {
                    return $this->teacher_average_times_pent('all', $plot, $timeGrouping);
                } else if ($rolename === 'editingteacher') {
                    return $this->teacher_average_times_pent('user', $plot, $timeGrouping);
                }
            }
            $tempText .= PHP_EOL.'</div>'."<br>";
        } else {
            $timeText = 'روزانه';
            if ($timeGrouping === 'weekly') $timeText = 'هفتگی';

            $daystatement = "FROM_UNIXTIME(l.timecreated, '%j-%H')";

            $mainResult = [];
            if ($user === 'user') {
                $tempText .= '<div id="div_class">'.PHP_EOL."\t";
                $tempText .= '<h3 class="main_title">میانگین مدت زمان سپری شده در سامانه برای '.$username.' به صورت '.$timeText.'</h3>';

                $timeSpentQuery =
                    "SELECT {$daystatement} AS state, COUNT(DISTINCT l.eventname) as cnt, u.id AS uid, u.username AS username, ROUND((MAX(l.timecreated) - MIN(l.timecreated))/3600, 2) AS hours, WEEK(FROM_UNIXTIME(l.timecreated)) as week_num
                    FROM {logstore_standard_log} l
                    JOIN {user} u ON l.userid = u.id
                    WHERE u.id = {$uid}
                    GROUP BY state
                    ORDER BY state";

                $mainResult = array_values($DB->get_records_sql($timeSpentQuery));

                $mainGroupedResult = [];
                if ($timeGrouping === 'daily') {
                    foreach ($mainResult as $res) {
                        $mainGroupedResult[(int)(explode('-', $res->state)[0])][] = $res;
                    }
                    foreach ($mainGroupedResult as $day => $result) {
                        $dayTotal = 0;
                        $avgTotal = 0;
                        foreach ($result as $res) {
                            $dayTotal += $res->hours;
                            $avgTotal += $res->cnt;
                        }
                        $mainAvgResult = 0;
                        if ($avgTotal > 0) $mainAvgResult = $dayTotal / $avgTotal;
                        $mainGroupedResult[$day] = number_format($mainAvgResult, 2, '.', '');
                    }
                } else {
                    $weeklyGroupedResults = [];
                    foreach ($mainResult as $res) {
                        $weeklyGroupedResults[$res->week_num][] = $res;
                    }
                    foreach ($weeklyGroupedResults as $weekNum => $weekRes) {
                        $total_week = 0;
                        $avgTotal = 0;

                        foreach ($weekRes as $currentWeek) {
                            $total_week += $currentWeek->hours;
                            $avgTotal += $currentWeek->cnt;
                        }
                        $mainAvgResult = 0;
                        if ($avgTotal > 0) $mainAvgResult = $total_week / $avgTotal;
                        $mainGroupedResult[$weekNum] = number_format($mainAvgResult, 2, '.', '');
                    }
                }
                if ($plot == 'line_sharp') {
                    $chart = new \core\chart_line();
                } else if ($plot == 'line_smooth') {
                    $chart = new \core\chart_line();
                    $chart->set_smooth(true);

                } else if ($plot == 'pie') {
                    $chart = new \core\chart_pie();

                } else if ($plot == 'doughnut') {
                    $chart = new \core\chart_pie();
                    $chart->set_doughnut(true);

                } else if ($plot == 'bar') {
                    $chart = new \core\chart_bar();
                }
                $groupX = [];
                $groupY = [];
                foreach ($mainGroupedResult as $grouping => $content) {
                    array_push($groupY, $content);
                    array_push($groupX, $grouping);
                }
                if (count($groupY) > 0) {
                    $series = new \core\chart_series($username, $groupY);
                    $chart->add_series($series);
                    $chart->set_labels($groupX);
                    $chart->set_title(' میانگین مدت زمان سپری شده '.$username.' در سامانه ');

                    if ($plot !== 'pie' && $plot !== 'doughnut') $chart->get_yaxis(0, true)->set_min(0);

                    $tempText .= $OUTPUT->render($chart).'<br>';
                }
                else {
                    $tempText .= '<h3>'.$username.' هیچ زمانی را در سامانه سپری نکرده است.</h3><br>';
                }
                $tempText .= "\t\t".'</div>'."<br>";
            } else if ($user === 'all') {
                $allUsers = $DB->get_records('user');

                $tempText .= '<div id="div_class">'.PHP_EOL."\t";
                $tempText .= '<h3 class="main_title">میانگین مدت زمان سپری شده در سامانه برای تمام مدرسان به صورت '.$timeText.'</h3>';

                $groupedUsers = [];
                $context = context_system::instance();
                foreach ($allUsers as $currentUser) {
                    $roles = get_user_roles($context, $currentUser->id, true);
                    $role = key($roles);
                    $rolename = null;
                    if (isset($roles[$role])) {
                        $rolename = $roles[$role]->shortname;
                    }
                    if ($rolename === 'editingteacher') {
                        $timeSpentQuery =
                            "SELECT {$daystatement} AS state, COUNT(DISTINCT l.eventname) as cnt , (ROUND((MAX(l.timecreated) - MIN(l.timecreated))/3600, 2)) AS hours, WEEK(FROM_UNIXTIME(l.timecreated)) as week_num
                            FROM {logstore_standard_log} l
                            WHERE l.userid = {$currentUser->id}
                            GROUP BY state
                            ORDER BY state ";
                        $teacherTimeSpent = array_values($DB->get_records_sql($timeSpentQuery));

                        $groupedUsers[$currentUser->username] = $teacherTimeSpent;
                    }
                }

                $mainGroupedResult = [];
                if ($timeGrouping === 'daily') {
                    foreach ($groupedUsers as $user => $result) {

                        $timeGroupResult = [];
                        foreach ($result as $res) {
                            $timeGroupResult[(int)(explode('-', $res->state)[0])][] = $res;
                        }

                        foreach ($timeGroupResult as $time => $res) {
                            $totalTime = 0;
                            $avgTotal = 0;
                            foreach ($res as $results) {
                                $totalTime += $results->hours;
                                $avgTotal += $results->cnt;
                            }
                            $mainAvgTime = 0;
                            if ($avgTotal > 0) $mainAvgTime = $totalTime / $avgTotal;
                            $timeGroupResult[$time] = $mainAvgTime;
                        }
                        $mainGroupedResult[$user] = $timeGroupResult;
                    }
                } else {
                    foreach ($groupedUsers as $user => $result) {

                        $timeGroupResult = [];
                        foreach ($result as $res) {
                            $timeGroupResult[$res->week_num][] = $res;
                        }

                        foreach ($timeGroupResult as $time => $res) {
                            $totalTime = 0;
                            $avgTotal = 0;
                            foreach ($res as $results) {
                                $totalTime += $results->hours;
                                $avgTotal += $results->cnt;
                            }
                            $mainAvgTime = 0;
                            if ($avgTotal > 0) $mainAvgTime = $totalTime / $avgTotal;
                            $timeGroupResult[$time] = $mainAvgTime;
                        }
                        $mainGroupedResult[$user] = $timeGroupResult;
                    }
                }

                foreach ($mainGroupedResult as $timeGroupName => $userTimes) {

                    if ($plot == 'line_sharp') {
                        $chart = new \core\chart_line();
                    } else if ($plot == 'line_smooth') {
                        $chart = new \core\chart_line();
                        $chart->set_smooth(true);

                    } else if ($plot == 'pie') {
                        $chart = new \core\chart_pie();

                    } else if ($plot == 'doughnut') {
                        $chart = new \core\chart_pie();
                        $chart->set_doughnut(true);

                    } else if ($plot == 'bar') {
                        $chart = new \core\chart_bar();
                    }

                    $groupX = [];
                    $groupY = [];
                    foreach ($userTimes as $time => $content) {
                        array_push($groupX, $time);
                        array_push($groupY, $content);
                    }

                    if (count($groupY) > 0) {
                        $series = new \core\chart_series($timeGroupName, $groupY);

                        $chart->add_series($series);
                        $chart->set_labels($groupX);
                        $chart->set_title(' میانگین مدت زمان سپری شده در سامانه برای '.$timeGroupName);

                        if ($plot !== 'pie' && $plot !== 'doughnut') $chart->get_yaxis(0, true)->set_min(0);

                        $tempText .= $OUTPUT->render($chart).'<br>';
                    } else {
                        $tempText .= '<h3>'.$timeGroupName.' هیچ زمانی را در سامانه سپری نکرده است.</h3><br>';
                    }
                }

                $tempText .= "\t\t".'</div>'."<br>";
            }  else if ($user === 'admin_all_user_self') {
                $roles = get_user_roles($context, $USER->id, true);
                $role = key($roles);
                $rolename = $roles[$role]->shortname;
                if ($rolename === 'manager') {
                    return $this->teacher_average_times_pent('all', $plot, $timeGrouping);
                } else if ($rolename === 'editingteacher') {
                    return $this->teacher_average_times_pent('user', $plot, $timeGrouping);
                }
            }


        }
        return $tempText;

	}
    public function teacher_time_response ($user, $plot, $group): string {
        global $DB, $USER, $PAGE, $CFG, $OUTPUT;
        $uid = $USER->id;
        $username = $USER->username;
        $tempText = '';
        $context = context_system::instance();

        try {
            $PAGE->requires->css('/local/teachers_dashboard/Styles/styles.css');
        } catch (exception $e) {
        }

        if ($plot == 'total') {
            if ($user === 'user') {
                $teacherResponseTimeQuery = "SELECT DISTINCT q.id AS qid, r.id AS rid,
                    uq.username AS studentname,
                    ur.username AS teachername,
                    q.id AS question_id,
                    q.subject AS question_subject,
                    q.created AS question_time,
                    r.userid AS teacher_id,
                    r.id AS response_id,
                    r.subject AS response_subject,
                    r.created AS response_time,
                    cc.fullname AS coursename,
                    cc.id AS ccid,
                    (r.created - q.created) AS response_time_hour
                    FROM {forum_posts} q
                    JOIN {forum_posts} r ON r.parent = q.id
                    JOIN {forum_discussions} d ON q.discussion = d.id   
                    JOIN {course} cc ON cc.id = d.course
                    JOIN {user} uq ON q.userid = uq.id
                    JOIN {user} ur ON r.userid = ur.id
                    JOIN {role_assignments} ra ON ur.id = ra.userid
                    JOIN {role_assignments} raq ON uq.id = raq.userid
                    JOIN {role} role ON role.id = ra.roleid
                    JOIN {role} roleq ON roleq.id = raq.roleid
                    WHERE (ur.id = {$uid}) AND (role.shortname = 'editingteacher') AND 
                    roleq.shortname = 'student' AND (ur.deleted = 0 AND uq.deleted = 0 AND q.deleted = 0 AND r.deleted = 0)";

                $teacherResponseTimes = array_values($DB->get_records_sql($teacherResponseTimeQuery));

                $tempText .= '<div id="div_class">'.PHP_EOL.
                    "\t".'<h3 class="main_title">مدت زمان پاسخگویی '.$username.' به سوالات در انجمن (فروم)</h3>'.PHP_EOL.
                    "\t".'<table class="data-table">'.PHP_EOL."\t\t".'<th>نام دوره</th>'.PHP_EOL."\t\t".'<th>مدت زمان</th>'.PHP_EOL."\t\t".'</tr>';

                $groupedArray = array();
                $mainTotalArray = array();
                foreach ($teacherResponseTimes as $content) {
                    $groupedArray[$content->coursename][] = $content;
                }
                foreach ($groupedArray AS $index => $item) {
                    $itemTotal = 0;
                    foreach ($item AS $times) {
                        $itemTotal += $times->response_time_hour;
                    }
                    $mainTotalArray[$index] = $itemTotal;
                }

                foreach ($mainTotalArray as $index => $main) {
                    $formatted_date = format_time($main);
                    if (strpos($formatted_date, 'hours') !== false) $formatted_date = str_replace('hours', 'ساعت', $formatted_date);
                    if (strpos($formatted_date, 'hour') !== false) $formatted_date = str_replace('hour', 'ساعت', $formatted_date);
                    if (strpos($formatted_date, 'mins') !== false) $formatted_date = str_replace('mins', 'دقیقه', $formatted_date);
                    if (strpos($formatted_date, 'min') !== false) $formatted_date = str_replace('min', 'دقیقه', $formatted_date);
                    if (strpos($formatted_date, 'secs') !== false) $formatted_date = str_replace('secs', 'ثانیه', $formatted_date);
                    if (strpos($formatted_date, 'sec') !== false) $formatted_date = str_replace('sec', 'ثانیه', $formatted_date);

                    $tempText .= '<tr>';
                    $tempText .= '<td>'.$index.'</td>';
                    $tempText .= '<td>'.$formatted_date.'</td>';
                    $tempText .= '</tr>';

                    //$tempText .= '<h3>نام دوره: '.$index.' &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp مجموع مدت زمان: '.$formatted_date.'<h3>';
                }

            } else if ($user === 'all') {
                $teacherResponseTimeQuery = "SELECT DISTINCT q.id AS qid, r.id AS rid, 
                    uq.username AS studentname,
                    ur.username AS teachername,
                    q.id AS question_id,
                    q.subject AS question_subject,
                    q.created AS question_time,
                    r.userid AS teacher_id,
                    r.id AS response_id,
                    cc.id AS ccid,
                    r.subject AS response_subject,
                    r.created AS response_time,
                    cc.fullname AS coursename,
                    (r.created - q.created) AS response_time_hour
                    FROM {forum_posts} q
                    JOIN {forum_posts} r ON r.parent = q.id
                    JOIN {forum_discussions} d ON q.discussion = d.id
                    JOIN {course} cc ON cc.id = d.course    
                    JOIN {user} uq ON q.userid = uq.id
                    JOIN {user} ur ON r.userid = ur.id
                    JOIN {role_assignments} ra ON ur.id = ra.userid
                    JOIN {role_assignments} raq ON uq.id = raq.userid
                    JOIN {role} role ON role.id = ra.roleid
                    JOIN {role} roleq ON roleq.id = raq.roleid
                    WHERE (role.shortname = 'editingteacher') AND 
                    roleq.shortname = 'student' AND (ur.deleted = 0 AND uq.deleted = 0 AND q.deleted = 0 AND r.deleted = 0)
                    ";

                $teacherResponseTimes = array_values($DB->get_records_sql($teacherResponseTimeQuery));

                $tempText .= '<div id="div_class">'.PHP_EOL.
                    "\t".'<h3 class="main_title">مدت زمان پاسخگویی تمام مدرسان به سوالات در انجمن (فروم)</h3>'.PHP_EOL.
                    "\t".'<table class="data-table">'.PHP_EOL."\t\t".'<tr>'.PHP_EOL."\t\t".'<th>نام مدرس</th>'.
                    PHP_EOL."\t\t".'<th>نام دوره</th>'.PHP_EOL."\t\t".'<th>مدت زمان پاسخ</th>'.PHP_EOL."\t\t".'</tr>';

                $groupedArray = array();
                foreach ($teacherResponseTimes as $content) {
                    $stdClass = new stdClass();
                    $stdClass->time = $content->response_time_hour;
                    $stdClass->course = $content->coursename;
                    $groupedArray[$content->teachername][] = $stdClass;
                }

                foreach ($groupedArray AS $index => $item) {
                    $courseGrouped = array();
                    foreach ($item as $current) {
                        $courseGrouped[$current->course][] = $current;
                    }
                    //echo '<br>';
                    foreach ($courseGrouped as $course => $courseItem) {
                        $itemCourseTotal = 0;
                        foreach ($courseItem AS $item) {
                            $itemCourseTotal += $item->time;
                        }

                        $formatted_date = format_time($itemCourseTotal);
                        if (strpos($formatted_date, 'hours') !== false) $formatted_date = str_replace('hours', 'ساعت', $formatted_date);
                        if (strpos($formatted_date, 'hour') !== false) $formatted_date = str_replace('hour', 'ساعت', $formatted_date);
                        if (strpos($formatted_date, 'mins') !== false) $formatted_date = str_replace('mins', 'دقیقه', $formatted_date);
                        if (strpos($formatted_date, 'min') !== false) $formatted_date = str_replace('min', 'دقیقه', $formatted_date);
                        if (strpos($formatted_date, 'secs') !== false) $formatted_date = str_replace('secs', 'ثانیه', $formatted_date);
                        if (strpos($formatted_date, 'sec') !== false) $formatted_date = str_replace('sec', 'ثانیه', $formatted_date);

                        $tempText .= '<tr>';
                        $tempText .= '<td>'.$index.'</td>';
                        $tempText .= '<td>'.$course.'</td>';
                        $tempText .= '<td>'.$formatted_date.'</td>';
                        $tempText .= '</tr>';

                    }
                }
            } else if ($user === 'admin_all_user_self') {
                $roles = get_user_roles($context, $USER->id, true);
                $role = key($roles);
                $rolename = $roles[$role]->shortname;
                if ($rolename === 'manager') {
                    return $this->teacher_time_response('all', $plot, $group);
                } else if ($rolename === 'editingteacher') {
                    return $this->teacher_time_response('user', $plot, $group);
                }
            }
            $tempText .= "\t".'</table>'.PHP_EOL.'</div>'."<br>";
        }
        else if ($plot === 'table') {
            if ($user === 'user') {
                $teacherResponseTimeQuery = "SELECT DISTINCT q.id AS qid, r.id AS rid,
                    uq.username AS studentname,
                    ur.username AS teachername,
                    q.id AS question_id,
                    q.subject AS question_subject,
                    q.created AS question_time,
                    r.userid AS teacher_id,
                    r.id AS response_id,
                    r.subject AS response_subject,
                    r.created AS response_time,
                    cc.fullname AS coursename,
                    SEC_TO_TIME(r.created - q.created) AS response_time_seconds
                    FROM {forum_posts} q
                    JOIN {forum_posts} r ON r.parent = q.id
                    JOIN {forum_discussions} d ON q.discussion = d.id   
                    JOIN {course} cc ON cc.id = d.course
                    JOIN {user} uq ON q.userid = uq.id
                    JOIN {user} ur ON r.userid = ur.id
                    JOIN {role_assignments} ra ON ur.id = ra.userid
                    JOIN {role_assignments} raq ON uq.id = raq.userid
                    JOIN {role} role ON role.id = ra.roleid
                    JOIN {role} roleq ON roleq.id = raq.roleid
                    WHERE (ur.id = {$uid}) AND (role.shortname = 'editingteacher') AND 
                    roleq.shortname = 'student' AND (ur.deleted = 0 AND uq.deleted = 0 AND q.deleted = 0 AND r.deleted = 0)";

                $teacherResponseTimes = array_values($DB->get_records_sql($teacherResponseTimeQuery));

                $tempText .= '<div id="div_class">'.PHP_EOL.
                    "\t".'<h3 class="main_title">مدت زمان پاسخگویی '.$username.' به سوالات در انجمن (فروم)</h3>'.PHP_EOL.
                    "\t".'<table class="data-table">'.PHP_EOL."\t\t".'<tr>'.PHP_EOL."\t\t".'<th>عنوان پاسخ</th>'.PHP_EOL."\t\t".'<th>نام کاربری فراگیر</th>'.PHP_EOL."\t\t".'<th>نام دوره</th>'.PHP_EOL."\t\t".'<th>مدت زمان</th>'.PHP_EOL."\t\t".'</tr>';

                foreach ($teacherResponseTimes as $responseTimes) {
                    $tempText .= '<tr>';
                    $tempText .= '<td>'.$responseTimes->response_subject.'</td>';
                    $tempText .= '<td>'.$responseTimes->studentname.'</td>';
                    $tempText .= '<td>'.$responseTimes->coursename.'</td>';
                    $tempText .= '<td>'.$responseTimes->response_time_seconds.'</td>';
                    $tempText .= '</tr>';
                }

            } else if ($user === 'all') {
                $teacherResponseTimeQuery = "SELECT DISTINCT q.id AS qid, r.id AS rid, 
                    uq.username AS studentname,
                    ur.username AS teachername,
                    q.id AS question_id,
                    q.subject AS question_subject,
                    q.created AS question_time,
                    r.userid AS teacher_id,
                    r.id AS response_id,
                    r.subject AS response_subject,
                    r.created AS response_time,
                    cc.fullname AS coursename,
                    SEC_TO_TIME(r.created - q.created) AS response_time_seconds
                    FROM {forum_posts} q
                    JOIN {forum_posts} r ON r.parent = q.id
                    JOIN {forum_discussions} d ON q.discussion = d.id
                    JOIN {course} cc ON cc.id = d.course    
                    JOIN {user} uq ON q.userid = uq.id
                    JOIN {user} ur ON r.userid = ur.id
                    JOIN {role_assignments} ra ON ur.id = ra.userid
                    JOIN {role_assignments} raq ON uq.id = raq.userid
                    JOIN {role} role ON role.id = ra.roleid
                    JOIN {role} roleq ON roleq.id = raq.roleid
                    WHERE (role.shortname = 'editingteacher') AND 
                    roleq.shortname = 'student' AND (ur.deleted = 0 AND uq.deleted = 0 AND q.deleted = 0 AND r.deleted = 0)";

                $teacherResponseTimes = array_values($DB->get_records_sql($teacherResponseTimeQuery));

                $tempText .= '<div id="div_class">'.PHP_EOL.
                    "\t".'<h3 class="main_title">مدت زمان پاسخگویی تمام مدرسان به سوالات در انجمن (فروم)</h3>'.PHP_EOL.
                    "\t".'<table class="data-table">'.PHP_EOL."\t\t".'<tr>'.PHP_EOL."\t\t".'<th>نام مدرس</th>'.
                    PHP_EOL."\t\t".'<th>عنوان پاسخ</th>'.PHP_EOL."\t\t".'<th>نام کاربری فراگیر</th>'.PHP_EOL."\t\t".'<th>نام دوره</th>'.PHP_EOL."\t\t".'<th>مدت زمان پاسخ</th>'.PHP_EOL."\t\t".'</tr>';

                foreach ($teacherResponseTimes as $responseTimes) {
                    $tempText .= '<tr>';
                    $tempText .= '<td>'.$responseTimes->teachername.'</td>';
                    $tempText .= '<td>'.$responseTimes->response_subject.'</td>';
                    $tempText .= '<td>'.$responseTimes->studentname.'</td>';
                    $tempText .= '<td>'.$responseTimes->coursename.'</td>';
                    $tempText .= '<td>'.$responseTimes->response_time_seconds.'</td>';
                    $tempText .= '</tr>';
                }
            } else if ($user === 'admin_all_user_self') {
                $roles = get_user_roles($context, $USER->id, true);
                $role = key($roles);
                $rolename = $roles[$role]->shortname;
                if ($rolename === 'manager') {
                    return $this->teacher_time_response('all', $plot, $group);
                } else if ($rolename === 'editingteacher') {
                    return $this->teacher_time_response('user', $plot, $group);
                }
            }
            $tempText .= "\t".'</table>'.PHP_EOL.'</div>'."<br>";
        } else {
            $timeText = 'روزانه';
            if ($group === 'weekly') $timeText = 'هفتگی';

            $daystatement = "FROM_UNIXTIME(r.created, '%j-%H')";

            $chartQuery = '';
            if ($user == 'user') {
                $chartQuery = "
                    SELECT r.id AS response_id, {$daystatement} AS state, r.id AS rid, cc.fullname,
                    uq.username AS studentname,
                    ur.username AS teachername,
                    q.id AS question_id,
                    q.subject AS question_subject,
                    q.created AS question_time,
                    r.userid AS teacher_id,
                    cc.id as ccid,
                    r.subject AS response_subject,
                    r.created AS response_time,
                    cc.fullname AS coursename,
                    ROUND(((r.created - q.created) / 3600), 2) AS response_time_hour, WEEK(FROM_UNIXTIME(r.created)) as week_num
                    FROM {forum_posts} q
                    JOIN {forum_posts} r ON r.parent = q.id
                    JOIN {forum_discussions} d ON q.discussion = d.id   
                    JOIN {course} cc ON cc.id = d.course
                    JOIN {user} uq ON q.userid = uq.id
                    JOIN {user} ur ON r.userid = ur.id
                    JOIN {role_assignments} ra ON ur.id = ra.userid
                    JOIN {role_assignments} raq ON uq.id = raq.userid
                    JOIN {role} role ON role.id = ra.roleid
                    JOIN {role} roleq ON roleq.id = raq.roleid
                    WHERE (ur.id = {$uid}) AND (role.shortname = 'editingteacher') AND 
                    roleq.shortname = 'student' AND (ur.deleted = 0 AND uq.deleted = 0 AND q.deleted = 0 AND r.deleted = 0)
                    GROUP BY cc.id, state
                    ORDER BY state";
            } else if ($user === 'all') {
                $chartQuery = "
                    SELECT r.id AS response_id, {$daystatement} AS state, q.id AS qid, r.id AS rid, ur.id AS urid, uq.id AS uqid, 
                    uq.username AS studentname,
                    ur.username AS teachername,
                    q.id AS question_id,
                    q.subject AS question_subject,
                    q.created AS question_time,
                    r.userid AS teacher_id,
                    cc.id as ccid,
                    r.subject AS response_subject,
                    r.created AS response_time,
                    cc.fullname AS coursename,
                    ROUND(((r.created - q.created) / 3600), 2) AS response_time_hour, WEEK(FROM_UNIXTIME(r.created)) as week_num
                    FROM {forum_posts} q
                    JOIN {forum_posts} r ON r.parent = q.id
                    JOIN {forum_discussions} d ON q.discussion = d.id
                    JOIN {course} cc ON cc.id = d.course    
                    JOIN {user} uq ON q.userid = uq.id
                    JOIN {user} ur ON r.userid = ur.id
                    JOIN {role_assignments} ra ON ur.id = ra.userid
                    JOIN {role_assignments} raq ON uq.id = raq.userid
                    JOIN {role} role ON role.id = ra.roleid
                    JOIN {role} roleq ON roleq.id = raq.roleid
                    WHERE (role.shortname = 'editingteacher') AND 
                    roleq.shortname = 'student' AND (ur.deleted = 0 AND uq.deleted = 0 AND q.deleted = 0 AND r.deleted = 0)
                    GROUP BY urid, cc.id, state
                    ORDER BY state";
            }
            else if ($user === 'admin_all_user_self') {
                $roles = get_user_roles($context, $USER->id, true);
                $role = key($roles);
                $rolename = $roles[$role]->shortname;
                if ($rolename === 'manager') {
                    return $this->teacher_time_response('all', $plot, $group);
                } else if ($rolename === 'editingteacher') {
                    return $this->teacher_time_response('user', $plot, $group);
                }
            }

            $teacherResponseTimes = array_values($DB->get_records_sql($chartQuery));

            if ($user === 'user') {
                $tempText .= '<div id="div_class">'.PHP_EOL.
                    "\t".'<h3 class="main_title">مدت زمان پاسخگویی '.$username.' به سوالات در انجمن (فروم) به صورت '.$timeText.'</h3>';
            } else {
                $tempText .= '<div id="div_class">'.PHP_EOL.
                    "\t".'<h3 class="main_title">مدت زمان پاسخگویی تمام مدرسان به سوالات در انجمن (فروم) به صورت '.$timeText.'</h3>';
            }

            $groupedArray = array();
            foreach ($teacherResponseTimes as $response) {
                $groupedArray[$response->ccid][] = $response;
            }

            foreach ($groupedArray as $course => $responseContent) {
                $mainGroupedResult = [];
                $courseName = ($DB->get_record('course', ['id'=>$course]))->fullname;
                if ($group === 'daily') {
                    foreach ($responseContent as $res) {
                        $mainGroupedResult[(int)(explode('-', $res->state)[0])][] = $res;
                    }
                } else {
                    foreach ($responseContent as $res) {
                        $mainGroupedResult[$res->week_num][] = $res;
                    }
                }

                $mainResultArray = [];
                $currentUser = null;
                foreach ($mainGroupedResult as $time => $results) {
                    $totalTime = 0;
                    foreach ($results as $currentRes) {
                        if (is_null($currentUser)) $currentUser = $currentRes->teachername;
                        $totalTime += $currentRes->response_time_hour;
                    }
                    $arrayValue = new stdClass();
                    $arrayValue->course = $courseName;
                    $arrayValue->totalTime = $totalTime;
                    $arrayValue->username = $currentUser;
                    $mainResultArray[$time] = $arrayValue;
                }

                if ($plot == 'line_sharp') {
                    $chart = new \core\chart_line();
                } else if ($plot == 'line_smooth') {
                    $chart = new \core\chart_line();
                    $chart->set_smooth(true);

                } else if ($plot == 'pie') {
                    $chart = new \core\chart_pie();

                } else if ($plot == 'doughnut') {
                    $chart = new \core\chart_pie();
                    $chart->set_doughnut(true);

                } else if ($plot == 'bar') {
                    $chart = new \core\chart_bar();
                }

                $groupX = [];
                $groupY = [];
                $currentUser = null;
                $currentCourse = null;
                foreach ($mainResultArray as $time => $content) {
                    array_push($groupX, $time);
                    array_push($groupY, $content->totalTime);
                    if (is_null($currentUser)) $currentUser = $content->username;
                    if (is_null($currentCourse)) $currentCourse = $content->course;
                }
                $series = new \core\chart_series($currentCourse, $groupY);
                $chart->add_series($series);
                $chart->set_labels($groupX);
                if ($plot !== 'pie' && $plot !== 'doughnut') $chart->set_title(' مدت زمان پاسخ '.$currentUser);
                else $chart->set_title(' مدت زمان پاسخ '.$currentUser.' در دوره '.$currentCourse);


                if ($plot !== 'pie' && $plot !== 'doughnut') $chart->get_yaxis(0, true)->set_min(0);

                $tempText .= $OUTPUT->render($chart).'<br>';
            }
            $tempText .= "\t".'</div>'."<br>";
        }

        return $tempText;

	}
    public function teacher_main_info ($user): string {
        global $DB, $USER, $PAGE, $CFG, $OUTPUT, $username;
        $uid = $USER->id;
        $username = $USER->username;
        $tempText = '';
        $context = context_system::instance();

        try {
            $PAGE->requires->css('/local/teachers_dashboard/Styles/styles.css');
        } catch (exception $e) {
        }

        if ($user === 'user') {
            $context = context_system::instance();
            $roles = get_user_roles($context, $USER->id, true);
            $role = key($roles);
            $rolename = $roles[$role]->shortname;

            $tempText .= '<div id="div_class">'.PHP_EOL.
                "\t".'<h3 class="main_title">اطلاعات کاربری '.$username.'</h3>'.PHP_EOL.
                "\t".'<table class="data-table">'.PHP_EOL."\t\t".'<tr>'.PHP_EOL.
                "\t\t".'<th>نام</th>'.PHP_EOL."\t\t".'<th>نام خانوادگی</th>'.PHP_EOL.
                "\t\t".'<th>نقش</th>'.PHP_EOL."\t\t".'<th>ایمیل</th>'.PHP_EOL."\t\t".'<th>دپارتمان</th>'.PHP_EOL.
                "\t\t".'<th>تلفن</th>'.PHP_EOL."\t\t".'<th>شهر</th>'.PHP_EOL."\t\t".'<th>کشور</th>'.PHP_EOL.
                "\t\t".'</tr>';

            $tempText .= '<tr>';
            $tempText .= '<td>'.$USER->firstname.'</td>';
            $tempText .= '<td>'.$USER->lastname.'</td>';
            $tempText .= '<td>'.$rolename.'</td>';
            $tempText .= '<td>'.$USER->email.'</td>';
            $tempText .= '<td>'.$USER->department.'</td>';
            $tempText .= '<td>'.$USER->phone1.'</td>';
            $tempText .= '<td>'.$USER->city.'</td>';
            $tempText .= '<td>'.$USER->country.'</td>';
            $tempText .= '</tr>';

        } else if ($user === 'all') {
            $allUsers = $DB->get_records('user');


            $tempText .= '<div id="div_class">'.PHP_EOL.
                "\t".'<h3 class="main_title">اطلاعات کاربری تمام مدرسان</h3>'.PHP_EOL.
                "\t".'<table class="data-table">'.PHP_EOL."\t\t".'<tr>'.PHP_EOL.
                "\t\t".'<th>نام</th>'.PHP_EOL."\t\t".'<th>نام خانوادگی</th>'.PHP_EOL.
                "\t\t".'<th>نقش</th>'.PHP_EOL."\t\t".'<th>ایمیل</th>'.PHP_EOL."\t\t".'<th>دپارتمان</th>'.PHP_EOL.
                "\t\t".'<th>تلفن</th>'.PHP_EOL."\t\t".'<th>شهر</th>'.PHP_EOL."\t\t".'<th>کشور</th>'.PHP_EOL.
                "\t\t".'</tr>';


            foreach ($allUsers as $user) {
                $roles = get_user_roles($context, $user->id, true);
                $role = key($roles);
                $rolename = '';
                if (isset($roles[$role])) {
                    $rolename = $roles[$role]->shortname;
                }
                if (strlen($rolename) > 0 && $rolename === 'editingteacher') {
                    $tempText .= '<tr>';
                    $tempText .= '<td>'.$user->firstname.'</td>';
                    $tempText .= '<td>'.$user->lastname.'</td>';
                    $tempText .= '<td>'.$rolename.'</td>';
                    $tempText .= '<td>'.$user->email.'</td>';
                    $tempText .= '<td>'.$user->department.'</td>';
                    $tempText .= '<td>'.$user->phone1.'</td>';
                    $tempText .= '<td>'.$user->city.'</td>';
                    $tempText .= '<td>'.$user->country.'</td>';
                    $tempText .= '</tr>';
                }
            }
        } else if ($user === 'admin_all_user_self') {
            $roles = get_user_roles($context, $USER->id, true);
            $role = key($roles);
            $rolename = $roles[$role]->shortname;
            if ($rolename === 'manager') {
                return $this->teacher_main_info('all');
            } else if ($rolename === 'editingteacher') {
                return $this->teacher_main_info('user');
            }
        }
        $tempText .= "\t".'</table>'.PHP_EOL.'</div>'.'<br>';
        return $tempText;

	}

}

?>