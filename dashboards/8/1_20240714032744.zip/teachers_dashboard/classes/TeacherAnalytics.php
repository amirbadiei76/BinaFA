<?php
/**
* @package     local_teachers_dashboard
* @author      Kristian
* @license     http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
* @var stdClass $plugin
*/

class TeacherAnalytics {

    public function teacher_average_times_pent ($user, $plot, $timeGrouping): string {
        global $DB, $USER, $PAGE, $CFG, $OUTPUT, $username;
        $uid = $USER->id;
        $username = $USER->username;
        $tempText = '';
        $context = context_system::instance();

        try {
            $PAGE->requires->css('/local/teachers_dashboard/Styles/styles.css');
        } catch (exception $e) {
        }

        if ($plot === 'total') {
            $daystatement = "FROM_UNIXTIME(l.timecreated, '%j-%H')";

            $tempText .= '<div id="div_class">'.PHP_EOL."\t";

            if ($user === 'user') {
                $tempText .= '<h3 class="main_title">میانگین مدت زمان سپری شده در سامانه برای '.$username.'</h3>';

                $timeSpentQuery =
                    "SELECT {$daystatement} AS state, u.id, ROUND((MAX(l.timecreated) - MIN(l.timecreated))/3600, 2) AS hours
                    FROM {logstore_standard_log} l
                    JOIN {user} u ON l.userid = u.id
                    WHERE u.id = {$uid}
                    GROUP BY state";
                $countQuery = "
                    SELECT COUNT(DISTINCT l.eventname) as cnt
                    FROM {logstore_standard_log} l
                    WHERE l.userid = {$uid}
                ";
                $teacherTimeSpent = array_values($DB->get_records_sql($timeSpentQuery));
                $countSpent = array_values($DB->get_records_sql($countQuery));

                $mainTotalTime = 0;
                foreach ($teacherTimeSpent AS $times) $mainTotalTime += $times->hours;

                if ($mainTotalTime > 0) {
                    $avgResult = ($mainTotalTime) / $countSpent[0]->cnt;
                    $tempText .= '<h3 >'.number_format($avgResult, 2, '.', '').' (ساعت)</h3>';
                } else {
                    $tempText .= '<h3>.هیچ زمانی را در سامانه سپری نکرده است '.$username.'</h3><br>';
                }
            } else if ($user === 'all') {
                $allUsers = $DB->get_records('user');
                $tempText .= '<h3 class="main_title">میانگین مدت زمان سپری شده در سامانه برای تمام مدرسان</h3>';

                $tempText .= '<table class="data-table">'.PHP_EOL."\t\t".'<tr>'.PHP_EOL."\t\t".'<th>نام کاربری</th>'.
                    PHP_EOL."\t\t".'<th>میانگین مدت زمان ها (ساعت)</th>'.PHP_EOL."\t\t".'</tr>';

                $groupedUsers = [];
                $context = context_system::instance();
                foreach ($allUsers as $currentUser) {
                    $roles = get_user_roles($context, $currentUser->id, true);
                    $role = key($roles);
                    $rolename = null;
                    if (isset($roles[$role])) {
                        $rolename = $roles[$role]->shortname;
                    }
                    if ($rolename === 'editingteacher') {
                        $timeSpentQuery =
                            "SELECT {$daystatement} AS state, (ROUND((MAX(l.timecreated) - MIN(l.timecreated))/3600, 2)) AS hours
                            FROM {logstore_standard_log} l
                            WHERE l.userid = {$currentUser->id}
                            GROUP BY state
                            ORDER BY state ";
                        $countQuery = "
                                    SELECT COUNT(DISTINCT l.eventname) as cnt
                                    FROM {logstore_standard_log} l
                                    WHERE l.userid = {$currentUser->id}
                                ";
                        $teacherTimeSpent = array_values($DB->get_records_sql($timeSpentQuery));
                        $countSpent = array_values($DB->get_records_sql($countQuery));

                        $mainTotalTime = 0;
                        foreach ($teacherTimeSpent AS $times) $mainTotalTime += $times->hours;

                        $avgTimeResult = 0;
                        if ($countSpent[0]->cnt > 0)
                            $avgTimeResult = $mainTotalTime / $countSpent[0]->cnt;

                        $groupedUsers[$currentUser->username] = number_format($avgTimeResult, 2, '.', '');
                    }
                }
                foreach ($groupedUsers as $name => $userTimes) {
                    $tempText .= '<tr>';
                    $tempText .= '<td>'.$name.'</td>';
                    $tempText .= '<td>'.$userTimes.'</td>';
                    $tempText .= '</tr>';
                }
                $tempText .= '</table>'.PHP_EOL;
            } else if ($user === 'admin_all_user_self') {
                $roles = get_user_roles($context, $USER->id, true);
                $role = key($roles);
                $rolename = $roles[$role]->shortname;
                if ($rolename === 'manager') {
                    return $this->teacher_average_times_pent('all', $plot, $timeGrouping);
                } else if ($rolename === 'editingteacher') {
                    return $this->teacher_average_times_pent('user', $plot, $timeGrouping);
                }
            }
            $tempText .= PHP_EOL.'</div>'."<br>";
        } else {
            $timeText = 'روزانه';
            if ($timeGrouping === 'weekly') $timeText = 'هفتگی';

            $daystatement = "FROM_UNIXTIME(l.timecreated, '%j-%H')";

            $mainResult = [];
            if ($user === 'user') {
                $tempText .= '<div id="div_class">'.PHP_EOL."\t";
                $tempText .= '<h3 class="main_title">میانگین مدت زمان سپری شده در سامانه برای '.$username.' به صورت '.$timeText.'</h3>';

                $timeSpentQuery =
                    "SELECT {$daystatement} AS state, COUNT(DISTINCT l.eventname) as cnt, u.id AS uid, u.username AS username, ROUND((MAX(l.timecreated) - MIN(l.timecreated))/3600, 2) AS hours, WEEK(FROM_UNIXTIME(l.timecreated)) as week_num
                    FROM {logstore_standard_log} l
                    JOIN {user} u ON l.userid = u.id
                    WHERE u.id = {$uid}
                    GROUP BY state
                    ORDER BY state";

                $mainResult = array_values($DB->get_records_sql($timeSpentQuery));

                $mainGroupedResult = [];
                if ($timeGrouping === 'daily') {
                    foreach ($mainResult as $res) {
                        $mainGroupedResult[(int)(explode('-', $res->state)[0])][] = $res;
                    }
                    foreach ($mainGroupedResult as $day => $result) {
                        $dayTotal = 0;
                        $avgTotal = 0;
                        foreach ($result as $res) {
                            $dayTotal += $res->hours;
                            $avgTotal += $res->cnt;
                        }
                        $mainAvgResult = 0;
                        if ($avgTotal > 0) $mainAvgResult = $dayTotal / $avgTotal;
                        $mainGroupedResult[$day] = number_format($mainAvgResult, 2, '.', '');
                    }
                } else {
                    $weeklyGroupedResults = [];
                    foreach ($mainResult as $res) {
                        $weeklyGroupedResults[$res->week_num][] = $res;
                    }
                    foreach ($weeklyGroupedResults as $weekNum => $weekRes) {
                        $total_week = 0;
                        $avgTotal = 0;

                        foreach ($weekRes as $currentWeek) {
                            $total_week += $currentWeek->hours;
                            $avgTotal += $currentWeek->cnt;
                        }
                        $mainAvgResult = 0;
                        if ($avgTotal > 0) $mainAvgResult = $total_week / $avgTotal;
                        $mainGroupedResult[$weekNum] = number_format($mainAvgResult, 2, '.', '');
                    }
                }
                if ($plot == 'line_sharp') {
                    $chart = new \core\chart_line();
                } else if ($plot == 'line_smooth') {
                    $chart = new \core\chart_line();
                    $chart->set_smooth(true);

                } else if ($plot == 'pie') {
                    $chart = new \core\chart_pie();

                } else if ($plot == 'doughnut') {
                    $chart = new \core\chart_pie();
                    $chart->set_doughnut(true);

                } else if ($plot == 'bar') {
                    $chart = new \core\chart_bar();
                }
                $groupX = [];
                $groupY = [];
                foreach ($mainGroupedResult as $grouping => $content) {
                    array_push($groupY, $content);
                    array_push($groupX, $grouping);
                }
                if (count($groupY) > 0) {
                    $series = new \core\chart_series($username, $groupY);
                    $chart->add_series($series);
                    $chart->set_labels($groupX);
                    $chart->set_title(' میانگین مدت زمان سپری شده '.$username.' در سامانه ');

                    if ($plot !== 'pie' && $plot !== 'doughnut') $chart->get_yaxis(0, true)->set_min(0);

                    $tempText .= $OUTPUT->render($chart).'<br>';
                }
                else {
                    $tempText .= '<h3>'.$username.' هیچ زمانی را در سامانه سپری نکرده است.</h3><br>';
                }
                $tempText .= "\t\t".'</div>'."<br>";
            } else if ($user === 'all') {
                $allUsers = $DB->get_records('user');

                $tempText .= '<div id="div_class">'.PHP_EOL."\t";
                $tempText .= '<h3 class="main_title">میانگین مدت زمان سپری شده در سامانه برای تمام مدرسان به صورت '.$timeText.'</h3>';

                $groupedUsers = [];
                $context = context_system::instance();
                foreach ($allUsers as $currentUser) {
                    $roles = get_user_roles($context, $currentUser->id, true);
                    $role = key($roles);
                    $rolename = null;
                    if (isset($roles[$role])) {
                        $rolename = $roles[$role]->shortname;
                    }
                    if ($rolename === 'editingteacher') {
                        $timeSpentQuery =
                            "SELECT {$daystatement} AS state, COUNT(DISTINCT l.eventname) as cnt , (ROUND((MAX(l.timecreated) - MIN(l.timecreated))/3600, 2)) AS hours, WEEK(FROM_UNIXTIME(l.timecreated)) as week_num
                            FROM {logstore_standard_log} l
                            WHERE l.userid = {$currentUser->id}
                            GROUP BY state
                            ORDER BY state ";
                        $teacherTimeSpent = array_values($DB->get_records_sql($timeSpentQuery));

                        $groupedUsers[$currentUser->username] = $teacherTimeSpent;
                    }
                }

                $mainGroupedResult = [];
                if ($timeGrouping === 'daily') {
                    foreach ($groupedUsers as $user => $result) {

                        $timeGroupResult = [];
                        foreach ($result as $res) {
                            $timeGroupResult[(int)(explode('-', $res->state)[0])][] = $res;
                        }

                        foreach ($timeGroupResult as $time => $res) {
                            $totalTime = 0;
                            $avgTotal = 0;
                            foreach ($res as $results) {
                                $totalTime += $results->hours;
                                $avgTotal += $results->cnt;
                            }
                            $mainAvgTime = 0;
                            if ($avgTotal > 0) $mainAvgTime = $totalTime / $avgTotal;
                            $timeGroupResult[$time] = $mainAvgTime;
                        }
                        $mainGroupedResult[$user] = $timeGroupResult;
                    }
                } else {
                    foreach ($groupedUsers as $user => $result) {

                        $timeGroupResult = [];
                        foreach ($result as $res) {
                            $timeGroupResult[$res->week_num][] = $res;
                        }

                        foreach ($timeGroupResult as $time => $res) {
                            $totalTime = 0;
                            $avgTotal = 0;
                            foreach ($res as $results) {
                                $totalTime += $results->hours;
                                $avgTotal += $results->cnt;
                            }
                            $mainAvgTime = 0;
                            if ($avgTotal > 0) $mainAvgTime = $totalTime / $avgTotal;
                            $timeGroupResult[$time] = $mainAvgTime;
                        }
                        $mainGroupedResult[$user] = $timeGroupResult;
                    }
                }

                foreach ($mainGroupedResult as $timeGroupName => $userTimes) {

                    if ($plot == 'line_sharp') {
                        $chart = new \core\chart_line();
                    } else if ($plot == 'line_smooth') {
                        $chart = new \core\chart_line();
                        $chart->set_smooth(true);

                    } else if ($plot == 'pie') {
                        $chart = new \core\chart_pie();

                    } else if ($plot == 'doughnut') {
                        $chart = new \core\chart_pie();
                        $chart->set_doughnut(true);

                    } else if ($plot == 'bar') {
                        $chart = new \core\chart_bar();
                    }

                    $groupX = [];
                    $groupY = [];
                    foreach ($userTimes as $time => $content) {
                        array_push($groupX, $time);
                        array_push($groupY, $content);
                    }

                    if (count($groupY) > 0) {
                        $series = new \core\chart_series($timeGroupName, $groupY);

                        $chart->add_series($series);
                        $chart->set_labels($groupX);
                        $chart->set_title(' میانگین مدت زمان سپری شده در سامانه برای '.$timeGroupName);

                        if ($plot !== 'pie' && $plot !== 'doughnut') $chart->get_yaxis(0, true)->set_min(0);

                        $tempText .= $OUTPUT->render($chart).'<br>';
                    } else {
                        $tempText .= '<h3>'.$timeGroupName.' هیچ زمانی را در سامانه سپری نکرده است.</h3><br>';
                    }
                }

                $tempText .= "\t\t".'</div>'."<br>";
            }  else if ($user === 'admin_all_user_self') {
                $roles = get_user_roles($context, $USER->id, true);
                $role = key($roles);
                $rolename = $roles[$role]->shortname;
                if ($rolename === 'manager') {
                    return $this->teacher_average_times_pent('all', $plot, $timeGrouping);
                } else if ($rolename === 'editingteacher') {
                    return $this->teacher_average_times_pent('user', $plot, $timeGrouping);
                }
            }


        }
        return $tempText;

	}

}

?>