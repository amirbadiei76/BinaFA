<?php
/**
 * @package     local_teachers_dashboard
 * @author      Kristian
 * @license     http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 * @var stdClass $plugin
 */

defined('MOODLE_INTERNAL') || die;

if ($hassiteconfig) {

    $settings = null;

    $settingscategory = new admin_category('local_teachers_dashboard', 'local_teachers_dashboard');
    $ADMIN->add('localplugins', $settingscategory);

    $settings = new admin_settingpage('local_teachers_dashboard_general_settings',
        'General Settings');

    if ($ADMIN->fulltree) {

        $settings->add(new admin_setting_configtext(
            'local_teachers_dashboard/navigation_position_beforekey',
            'navigation_position_beforekey',
            get_string('navigation_position_beforekey_description', 'local_teachers_dashboard'),
            '',
            PARAM_RAW
        ));
    }
}
