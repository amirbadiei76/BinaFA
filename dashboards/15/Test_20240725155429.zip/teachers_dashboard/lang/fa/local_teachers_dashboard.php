<?php


$string['general_settings'] = 'تنظیمات عمومی';
$string['navigation_position_beforekey_description'] = 'اجازه می دهد تا مشخص کند که به کجای صفحه در نمای پیمایش اضافه شود';

?>