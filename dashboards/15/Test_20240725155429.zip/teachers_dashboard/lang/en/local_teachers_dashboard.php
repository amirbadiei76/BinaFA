<?php


$string['general_settings'] = 'General Settings';
$string['navigation_position_beforekey_description'] = 'Allows to specify where in the navigation bar the link to the page is added';
?>