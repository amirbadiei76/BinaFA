<?php
/**
* @package     local_teachers_dashboard
* @author      Kristian
* @license     http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
* @var stdClass $plugin
*/

class TeacherAnalytics {

    public function teacher_uploaded_content ($user, $plot, $timeGrouping): string
    {
        global $DB, $USER, $PAGE, $CFG, $OUTPUT;
        $uid = $USER->id;
        $username = $USER->username;
        $context = context_system::instance();
        $tempText = '';

        try {
            $PAGE->requires->css('/local/teachers_dashboard/Styles/styles.css');
        } catch (exception $e) {
        }

        if ($plot == 'table') {
            if ($user == 'user') {
                $teacherContentCountQuery = "
                    SELECT DISTINCT f.id as fid, c.fullname, COUNT(DISTINCT f.id) as contentcount, c.fullname as coursename
                    FROM {files} f
                    JOIN {context} cx ON f.contextid = cx.id
                    JOIN {course_modules} cm ON cx.instanceid=cm.id
                    JOIN {course} c ON cm.course=c.id
                    JOIN {resource} r ON r.course = c.id
                    JOIN {user} u ON f.userid = u.id
                    JOIN {role_assignments} ra ON ra.userid = f.userid
                    JOIN {role} role ON role.id = ra.roleid
                    WHERE filename <> '.' AND f.filearea <> 'draft' AND f.userid = {$uid} AND f.author IS NOT null AND f.component = 'mod_resource' AND role.shortname = 'editingteacher' AND u.deleted = 0
                    GROUP BY c.id 
                ";

                $teacherContentCount = array_values($DB->get_records_sql($teacherContentCountQuery));

                $tempText .= '<div id="div_class">'.PHP_EOL.
                    "\t".'<h3 class="main_title">تعداد فایل های بارگذاری شده '.$username.'</h3>'.PHP_EOL.
                    "\t".'<table class="data-table">'.PHP_EOL."\t\t".'<tr>'.PHP_EOL.
                    "\t\t".'<th>نام درس</th>'.PHP_EOL."\t\t".'<th>تعداد فایل ها</th>'.PHP_EOL."\t\t".'</tr>';

                foreach ($teacherContentCount as $content) {
                    $tempText .= '<tr>';
                    $tempText .= '<td>'.$content->coursename.'</td>';
                    $tempText .= '<td>'.$content->contentcount.'</td>';
                    $tempText .= '</tr>';
                }
                $tempText .= "\t".'</table>'.PHP_EOL.'</div>'.'<br>';
            }
            else if ($user == 'all') {
                $teacherContentCountQuery =
                    "SELECT DISTINCT f.id as fid, c.fullname, COUNT(DISTINCT f.id) as contentcount, u.username as username, c.fullname as coursename
                    FROM {files} f
                    JOIN {context} cx ON f.contextid = cx.id
                    JOIN {course_modules} cm ON cx.instanceid=cm.id
                    JOIN {course} c ON cm.course=c.id
                    JOIN {resource} r ON r.course = c.id
                    JOIN {user} u ON f.userid = u.id
                    JOIN {role_assignments} ra ON ra.userid = f.userid
                    JOIN {role} role ON role.id = ra.roleid
                    WHERE filename <> '.' AND f.filearea <> 'draft' AND f.author IS NOT null AND f.component = 'mod_resource' AND role.shortname = 'editingteacher' AND u.deleted = 0
                    GROUP BY c.id, u.id";

                $teacherContentCount = array_values($DB->get_records_sql($teacherContentCountQuery));


                $tempText .= '<div id="div_class">'.PHP_EOL.
                    "\t".'<h3 class="main_title">تعداد فایل های بارگذاری شده مدرسان</h3>'.PHP_EOL.
                    "\t".'<table class="data-table">'.PHP_EOL."\t\t".'<tr>'.PHP_EOL."\t\t".'<th>نام درس</th>'
                    .PHP_EOL."\t\t".'<th>نام کاربری مدرس</th>'.PHP_EOL."\t\t".'<th>تعداد فایل ها</th>'.PHP_EOL."\t\t".'</tr>';

                foreach ($teacherContentCount as $content) {
                    $tempText .= '<tr>';
                    $tempText .= '<td>'.$content->coursename.'</td>';
                    $tempText .= '<td>'.$content->username.'</td>';
                    $tempText .= '<td>'.$content->contentcount.'</td>';
                    $tempText .= '</tr>';
                }
                $tempText .= "\t".'</table>'.PHP_EOL.'</div>'.'<br>';
            }
            else if ($user === 'admin_all_user_self') {
                $roles = get_user_roles($context, $USER->id, true);
                $role = key($roles);
                $rolename = $roles[$role]->shortname;
                if ($rolename === 'manager') {
                    return $this->teacher_uploaded_content('all', $plot, $timeGrouping);
                } else if ($rolename === 'editingteacher') {
                    return $this->teacher_uploaded_content('user', $plot, $timeGrouping);
                }
            }
        } else {

            $daystatement = "FROM_UNIXTIME(f.timecreated, '%j-%H')";

            $chartQuery = '';
            if ($user === 'user') {
                $chartQuery = "
                    SELECT DISTINCT f.id as fid, u.id as uid, {$daystatement} AS state, c.fullname, COUNT(DISTINCT f.id) as contentcount, c.fullname as coursename, u.username as username, WEEK(FROM_UNIXTIME(f.timecreated)) as week_num
                    FROM {files} f
                    JOIN {context} cx ON f.contextid = cx.id
                    JOIN {course_modules} cm ON cx.instanceid=cm.id
                    JOIN {course} c ON cm.course=c.id
                    JOIN {resource} r ON r.course = c.id
                    JOIN {user} u ON f.userid = u.id
                    JOIN {role_assignments} ra ON ra.userid = f.userid
                    JOIN {role} role ON role.id = ra.roleid
                    WHERE filename <> '.' AND f.filearea <> 'draft' AND f.userid = {$uid} AND f.author IS NOT null AND f.component = 'mod_resource' AND role.shortname = 'editingteacher' AND u.deleted = 0
                    GROUP BY c.id, state
                    ORDER BY state";
            } else if ($user === 'all') {
                $chartQuery = "
                    SELECT DISTINCT f.id as fid, u.id as uid, {$daystatement} AS state, c.fullname, COUNT(DISTINCT f.id) as contentcount, u.username as username, c.fullname as coursename, u.username as username, WEEK(FROM_UNIXTIME(f.timecreated)) as week_num
                    FROM {files} f
                    JOIN {context} cx ON f.contextid = cx.id
                    JOIN {course_modules} cm ON cx.instanceid=cm.id
                    JOIN {course} c ON cm.course=c.id
                    JOIN {resource} r ON r.course = c.id
                    JOIN {user} u ON f.userid = u.id
                    JOIN {role_assignments} ra ON ra.userid = f.userid
                    JOIN {role} role ON role.id = ra.roleid
                    WHERE filename <> '.' AND f.filearea <> 'draft' AND f.author IS NOT null AND f.component = 'mod_resource' AND role.shortname = 'editingteacher' AND u.deleted = 0
                    GROUP BY u.id, c.id, state
                    ORDER BY state";
            } else if ($user === 'admin_all_user_self') {
                $roles = get_user_roles($context, $USER->id, true);
                $role = key($roles);
                $rolename = $roles[$role]->shortname;
                if ($rolename === 'manager') {
                    return $this->teacher_uploaded_content('all', $plot, $timeGrouping);
                } else if ($rolename === 'editingteacher') {
                    return $this->teacher_uploaded_content('user', $plot, $timeGrouping);
                }
            }

            $teacherContentCount = array_values($DB->get_records_sql($chartQuery));

            $courseGroupedContentCount = [];
            foreach ($teacherContentCount as $content) {
                $courseGroupedContentCount[$content->coursename][] = $content;
            }
            $timeText = 'روزانه';
            if ($timeGrouping === 'weekly') $timeText = 'هفتگی';

            if ($user === 'user') {
                $tempText .= '<div id="div_class">'.PHP_EOL.
                    "\t".'<h3 class="main_title">تعداد فایل های بارگذاری شده '.$username.' به صورت '.$timeText.'</h3>';
            } else {
                $tempText .= '<div id="div_class">'.PHP_EOL.
                    "\t".'<h3 class="main_title">تعداد فایل های بارگذاری شده مدرسان به صورت '.$timeText.'</h3>';
            }

            foreach ($courseGroupedContentCount as $course => $content) {
                $mainGroupedResult = [];
                if ($timeGrouping === 'daily') {
                    foreach ($content as $res) {
                        $mainGroupedResult[(int)(explode('-', $res->state)[0])][] = $res;
                    }
                } else {
                    foreach ($content as $res) {
                        $mainGroupedResult[$res->week_num][] = $res;
                    }
                }

                $mainResultArray = [];
                foreach ($mainGroupedResult as $time => $results) {
                    $totalCount = 0;
                    foreach ($results as $currentRes) {
                        $totalCount += $currentRes->contentcount;
                    }
                    $arrayValue = new stdClass();
                    $arrayValue->course = $course;
                    $arrayValue->contentcount = $totalCount;
                    $arrayValue->username = $results[0]->username;
                    $mainResultArray[$time] = $arrayValue;
                }

                $groupX = [];
                $groupY = [];
                $currentTeacher = '';
                foreach ($mainResultArray as $time => $res) {
                    $currentTeacher = $res->username;
                    array_push($groupX, $time);
                    array_push($groupY, $res->contentcount);
                }

                if ($plot == 'line_sharp') {
                    $chart = new \core\chart_line();
                }
                else if ($plot == 'line_smooth') {
                    $chart = new \core\chart_line();
                    $chart->set_smooth(true);

                } else if ($plot == 'pie') {
                    $chart = new \core\chart_pie();

                } else if ($plot == 'doughnut') {
                    $chart = new \core\chart_pie();
                    $chart->set_doughnut(true);

                } else if ($plot == 'bar') {
                    $chart = new \core\chart_bar();
                }

                $series = new \core\chart_series($course, $groupY);
                $chart->add_series($series);
                $chart->set_labels($groupX);
                if ($plot !== 'pie' && $plot !== 'doughnut') $chart->get_yaxis(0, true)->set_min(0);

                if ($plot !== 'pie' && $plot !== 'doughnut') $chart->set_title(' تعداد فایل های بارگذاری شده '.$currentTeacher);
                else $chart->set_title(' تعداد فایل های بارگذاری شده '.$currentTeacher.' در دوره '.$course);

                $tempText .= $OUTPUT->render($chart).'<br>';
            }
            $tempText .= "\t\t".'</div>'.'<br>';
        }
        return $tempText;

	}
    public function teacher_time_response ($user, $plot, $group): string {
        global $DB, $USER, $PAGE, $CFG, $OUTPUT;
        $uid = $USER->id;
        $username = $USER->username;
        $tempText = '';
        $context = context_system::instance();

        try {
            $PAGE->requires->css('/local/teachers_dashboard/Styles/styles.css');
        } catch (exception $e) {
        }

        if ($plot == 'total') {
            if ($user === 'user') {
                $teacherResponseTimeQuery = "SELECT DISTINCT q.id AS qid, r.id AS rid,
                    uq.username AS studentname,
                    ur.username AS teachername,
                    q.id AS question_id,
                    q.subject AS question_subject,
                    q.created AS question_time,
                    r.userid AS teacher_id,
                    r.id AS response_id,
                    r.subject AS response_subject,
                    r.created AS response_time,
                    cc.fullname AS coursename,
                    cc.id AS ccid,
                    (r.created - q.created) AS response_time_hour
                    FROM {forum_posts} q
                    JOIN {forum_posts} r ON r.parent = q.id
                    JOIN {forum_discussions} d ON q.discussion = d.id   
                    JOIN {course} cc ON cc.id = d.course
                    JOIN {user} uq ON q.userid = uq.id
                    JOIN {user} ur ON r.userid = ur.id
                    JOIN {role_assignments} ra ON ur.id = ra.userid
                    JOIN {role_assignments} raq ON uq.id = raq.userid
                    JOIN {role} role ON role.id = ra.roleid
                    JOIN {role} roleq ON roleq.id = raq.roleid
                    WHERE (ur.id = {$uid}) AND (role.shortname = 'editingteacher') AND 
                    roleq.shortname = 'student' AND (ur.deleted = 0 AND uq.deleted = 0 AND q.deleted = 0 AND r.deleted = 0)";

                $teacherResponseTimes = array_values($DB->get_records_sql($teacherResponseTimeQuery));

                $tempText .= '<div id="div_class">'.PHP_EOL.
                    "\t".'<h3 class="main_title">مدت زمان پاسخگویی '.$username.' به سوالات در انجمن (فروم)</h3>'.PHP_EOL.
                    "\t".'<table class="data-table">'.PHP_EOL."\t\t".'<th>نام دوره</th>'.PHP_EOL."\t\t".'<th>مدت زمان</th>'.PHP_EOL."\t\t".'</tr>';

                $groupedArray = array();
                $mainTotalArray = array();
                foreach ($teacherResponseTimes as $content) {
                    $groupedArray[$content->coursename][] = $content;
                }
                foreach ($groupedArray AS $index => $item) {
                    $itemTotal = 0;
                    foreach ($item AS $times) {
                        $itemTotal += $times->response_time_hour;
                    }
                    $mainTotalArray[$index] = $itemTotal;
                }

                foreach ($mainTotalArray as $index => $main) {
                    $formatted_date = format_time($main);
                    if (strpos($formatted_date, 'hours') !== false) $formatted_date = str_replace('hours', 'ساعت', $formatted_date);
                    if (strpos($formatted_date, 'hour') !== false) $formatted_date = str_replace('hour', 'ساعت', $formatted_date);
                    if (strpos($formatted_date, 'mins') !== false) $formatted_date = str_replace('mins', 'دقیقه', $formatted_date);
                    if (strpos($formatted_date, 'min') !== false) $formatted_date = str_replace('min', 'دقیقه', $formatted_date);
                    if (strpos($formatted_date, 'secs') !== false) $formatted_date = str_replace('secs', 'ثانیه', $formatted_date);
                    if (strpos($formatted_date, 'sec') !== false) $formatted_date = str_replace('sec', 'ثانیه', $formatted_date);

                    $tempText .= '<tr>';
                    $tempText .= '<td>'.$index.'</td>';
                    $tempText .= '<td>'.$formatted_date.'</td>';
                    $tempText .= '</tr>';

                    //$tempText .= '<h3>نام دوره: '.$index.' &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp مجموع مدت زمان: '.$formatted_date.'<h3>';
                }

            } else if ($user === 'all') {
                $teacherResponseTimeQuery = "SELECT DISTINCT q.id AS qid, r.id AS rid, 
                    uq.username AS studentname,
                    ur.username AS teachername,
                    q.id AS question_id,
                    q.subject AS question_subject,
                    q.created AS question_time,
                    r.userid AS teacher_id,
                    r.id AS response_id,
                    cc.id AS ccid,
                    r.subject AS response_subject,
                    r.created AS response_time,
                    cc.fullname AS coursename,
                    (r.created - q.created) AS response_time_hour
                    FROM {forum_posts} q
                    JOIN {forum_posts} r ON r.parent = q.id
                    JOIN {forum_discussions} d ON q.discussion = d.id
                    JOIN {course} cc ON cc.id = d.course    
                    JOIN {user} uq ON q.userid = uq.id
                    JOIN {user} ur ON r.userid = ur.id
                    JOIN {role_assignments} ra ON ur.id = ra.userid
                    JOIN {role_assignments} raq ON uq.id = raq.userid
                    JOIN {role} role ON role.id = ra.roleid
                    JOIN {role} roleq ON roleq.id = raq.roleid
                    WHERE (role.shortname = 'editingteacher') AND 
                    roleq.shortname = 'student' AND (ur.deleted = 0 AND uq.deleted = 0 AND q.deleted = 0 AND r.deleted = 0)
                    ";

                $teacherResponseTimes = array_values($DB->get_records_sql($teacherResponseTimeQuery));

                $tempText .= '<div id="div_class">'.PHP_EOL.
                    "\t".'<h3 class="main_title">مدت زمان پاسخگویی تمام مدرسان به سوالات در انجمن (فروم)</h3>'.PHP_EOL.
                    "\t".'<table class="data-table">'.PHP_EOL."\t\t".'<tr>'.PHP_EOL."\t\t".'<th>نام مدرس</th>'.
                    PHP_EOL."\t\t".'<th>نام دوره</th>'.PHP_EOL."\t\t".'<th>مدت زمان پاسخ</th>'.PHP_EOL."\t\t".'</tr>';

                $groupedArray = array();
                foreach ($teacherResponseTimes as $content) {
                    $stdClass = new stdClass();
                    $stdClass->time = $content->response_time_hour;
                    $stdClass->course = $content->coursename;
                    $groupedArray[$content->teachername][] = $stdClass;
                }

                foreach ($groupedArray AS $index => $item) {
                    $courseGrouped = array();
                    foreach ($item as $current) {
                        $courseGrouped[$current->course][] = $current;
                    }
                    //echo '<br>';
                    foreach ($courseGrouped as $course => $courseItem) {
                        $itemCourseTotal = 0;
                        foreach ($courseItem AS $item) {
                            $itemCourseTotal += $item->time;
                        }

                        $formatted_date = format_time($itemCourseTotal);
                        if (strpos($formatted_date, 'hours') !== false) $formatted_date = str_replace('hours', 'ساعت', $formatted_date);
                        if (strpos($formatted_date, 'hour') !== false) $formatted_date = str_replace('hour', 'ساعت', $formatted_date);
                        if (strpos($formatted_date, 'mins') !== false) $formatted_date = str_replace('mins', 'دقیقه', $formatted_date);
                        if (strpos($formatted_date, 'min') !== false) $formatted_date = str_replace('min', 'دقیقه', $formatted_date);
                        if (strpos($formatted_date, 'secs') !== false) $formatted_date = str_replace('secs', 'ثانیه', $formatted_date);
                        if (strpos($formatted_date, 'sec') !== false) $formatted_date = str_replace('sec', 'ثانیه', $formatted_date);

                        $tempText .= '<tr>';
                        $tempText .= '<td>'.$index.'</td>';
                        $tempText .= '<td>'.$course.'</td>';
                        $tempText .= '<td>'.$formatted_date.'</td>';
                        $tempText .= '</tr>';

                    }
                }
            } else if ($user === 'admin_all_user_self') {
                $roles = get_user_roles($context, $USER->id, true);
                $role = key($roles);
                $rolename = $roles[$role]->shortname;
                if ($rolename === 'manager') {
                    return $this->teacher_time_response('all', $plot, $group);
                } else if ($rolename === 'editingteacher') {
                    return $this->teacher_time_response('user', $plot, $group);
                }
            }
            $tempText .= "\t".'</table>'.PHP_EOL.'</div>'."<br>";
        }
        else if ($plot === 'table') {
            if ($user === 'user') {
                $teacherResponseTimeQuery = "SELECT DISTINCT q.id AS qid, r.id AS rid,
                    uq.username AS studentname,
                    ur.username AS teachername,
                    q.id AS question_id,
                    q.subject AS question_subject,
                    q.created AS question_time,
                    r.userid AS teacher_id,
                    r.id AS response_id,
                    r.subject AS response_subject,
                    r.created AS response_time,
                    cc.fullname AS coursename,
                    SEC_TO_TIME(r.created - q.created) AS response_time_seconds
                    FROM {forum_posts} q
                    JOIN {forum_posts} r ON r.parent = q.id
                    JOIN {forum_discussions} d ON q.discussion = d.id   
                    JOIN {course} cc ON cc.id = d.course
                    JOIN {user} uq ON q.userid = uq.id
                    JOIN {user} ur ON r.userid = ur.id
                    JOIN {role_assignments} ra ON ur.id = ra.userid
                    JOIN {role_assignments} raq ON uq.id = raq.userid
                    JOIN {role} role ON role.id = ra.roleid
                    JOIN {role} roleq ON roleq.id = raq.roleid
                    WHERE (ur.id = {$uid}) AND (role.shortname = 'editingteacher') AND 
                    roleq.shortname = 'student' AND (ur.deleted = 0 AND uq.deleted = 0 AND q.deleted = 0 AND r.deleted = 0)";

                $teacherResponseTimes = array_values($DB->get_records_sql($teacherResponseTimeQuery));

                $tempText .= '<div id="div_class">'.PHP_EOL.
                    "\t".'<h3 class="main_title">مدت زمان پاسخگویی '.$username.' به سوالات در انجمن (فروم)</h3>'.PHP_EOL.
                    "\t".'<table class="data-table">'.PHP_EOL."\t\t".'<tr>'.PHP_EOL."\t\t".'<th>عنوان پاسخ</th>'.PHP_EOL."\t\t".'<th>نام کاربری فراگیر</th>'.PHP_EOL."\t\t".'<th>نام دوره</th>'.PHP_EOL."\t\t".'<th>مدت زمان</th>'.PHP_EOL."\t\t".'</tr>';

                foreach ($teacherResponseTimes as $responseTimes) {
                    $tempText .= '<tr>';
                    $tempText .= '<td>'.$responseTimes->response_subject.'</td>';
                    $tempText .= '<td>'.$responseTimes->studentname.'</td>';
                    $tempText .= '<td>'.$responseTimes->coursename.'</td>';
                    $tempText .= '<td>'.$responseTimes->response_time_seconds.'</td>';
                    $tempText .= '</tr>';
                }

            } else if ($user === 'all') {
                $teacherResponseTimeQuery = "SELECT DISTINCT q.id AS qid, r.id AS rid, 
                    uq.username AS studentname,
                    ur.username AS teachername,
                    q.id AS question_id,
                    q.subject AS question_subject,
                    q.created AS question_time,
                    r.userid AS teacher_id,
                    r.id AS response_id,
                    r.subject AS response_subject,
                    r.created AS response_time,
                    cc.fullname AS coursename,
                    SEC_TO_TIME(r.created - q.created) AS response_time_seconds
                    FROM {forum_posts} q
                    JOIN {forum_posts} r ON r.parent = q.id
                    JOIN {forum_discussions} d ON q.discussion = d.id
                    JOIN {course} cc ON cc.id = d.course    
                    JOIN {user} uq ON q.userid = uq.id
                    JOIN {user} ur ON r.userid = ur.id
                    JOIN {role_assignments} ra ON ur.id = ra.userid
                    JOIN {role_assignments} raq ON uq.id = raq.userid
                    JOIN {role} role ON role.id = ra.roleid
                    JOIN {role} roleq ON roleq.id = raq.roleid
                    WHERE (role.shortname = 'editingteacher') AND 
                    roleq.shortname = 'student' AND (ur.deleted = 0 AND uq.deleted = 0 AND q.deleted = 0 AND r.deleted = 0)";

                $teacherResponseTimes = array_values($DB->get_records_sql($teacherResponseTimeQuery));

                $tempText .= '<div id="div_class">'.PHP_EOL.
                    "\t".'<h3 class="main_title">مدت زمان پاسخگویی تمام مدرسان به سوالات در انجمن (فروم)</h3>'.PHP_EOL.
                    "\t".'<table class="data-table">'.PHP_EOL."\t\t".'<tr>'.PHP_EOL."\t\t".'<th>نام مدرس</th>'.
                    PHP_EOL."\t\t".'<th>عنوان پاسخ</th>'.PHP_EOL."\t\t".'<th>نام کاربری فراگیر</th>'.PHP_EOL."\t\t".'<th>نام دوره</th>'.PHP_EOL."\t\t".'<th>مدت زمان پاسخ</th>'.PHP_EOL."\t\t".'</tr>';

                foreach ($teacherResponseTimes as $responseTimes) {
                    $tempText .= '<tr>';
                    $tempText .= '<td>'.$responseTimes->teachername.'</td>';
                    $tempText .= '<td>'.$responseTimes->response_subject.'</td>';
                    $tempText .= '<td>'.$responseTimes->studentname.'</td>';
                    $tempText .= '<td>'.$responseTimes->coursename.'</td>';
                    $tempText .= '<td>'.$responseTimes->response_time_seconds.'</td>';
                    $tempText .= '</tr>';
                }
            } else if ($user === 'admin_all_user_self') {
                $roles = get_user_roles($context, $USER->id, true);
                $role = key($roles);
                $rolename = $roles[$role]->shortname;
                if ($rolename === 'manager') {
                    return $this->teacher_time_response('all', $plot, $group);
                } else if ($rolename === 'editingteacher') {
                    return $this->teacher_time_response('user', $plot, $group);
                }
            }
            $tempText .= "\t".'</table>'.PHP_EOL.'</div>'."<br>";
        } else {
            $timeText = 'روزانه';
            if ($group === 'weekly') $timeText = 'هفتگی';

            $daystatement = "FROM_UNIXTIME(r.created, '%j-%H')";

            $chartQuery = '';
            if ($user == 'user') {
                $chartQuery = "
                    SELECT r.id AS response_id, {$daystatement} AS state, r.id AS rid, cc.fullname,
                    uq.username AS studentname,
                    ur.username AS teachername,
                    q.id AS question_id,
                    q.subject AS question_subject,
                    q.created AS question_time,
                    r.userid AS teacher_id,
                    cc.id as ccid,
                    r.subject AS response_subject,
                    r.created AS response_time,
                    cc.fullname AS coursename,
                    ROUND(((r.created - q.created) / 3600), 2) AS response_time_hour, WEEK(FROM_UNIXTIME(r.created)) as week_num
                    FROM {forum_posts} q
                    JOIN {forum_posts} r ON r.parent = q.id
                    JOIN {forum_discussions} d ON q.discussion = d.id   
                    JOIN {course} cc ON cc.id = d.course
                    JOIN {user} uq ON q.userid = uq.id
                    JOIN {user} ur ON r.userid = ur.id
                    JOIN {role_assignments} ra ON ur.id = ra.userid
                    JOIN {role_assignments} raq ON uq.id = raq.userid
                    JOIN {role} role ON role.id = ra.roleid
                    JOIN {role} roleq ON roleq.id = raq.roleid
                    WHERE (ur.id = {$uid}) AND (role.shortname = 'editingteacher') AND 
                    roleq.shortname = 'student' AND (ur.deleted = 0 AND uq.deleted = 0 AND q.deleted = 0 AND r.deleted = 0)
                    GROUP BY cc.id, state
                    ORDER BY state";
            } else if ($user === 'all') {
                $chartQuery = "
                    SELECT r.id AS response_id, {$daystatement} AS state, q.id AS qid, r.id AS rid, ur.id AS urid, uq.id AS uqid, 
                    uq.username AS studentname,
                    ur.username AS teachername,
                    q.id AS question_id,
                    q.subject AS question_subject,
                    q.created AS question_time,
                    r.userid AS teacher_id,
                    cc.id as ccid,
                    r.subject AS response_subject,
                    r.created AS response_time,
                    cc.fullname AS coursename,
                    ROUND(((r.created - q.created) / 3600), 2) AS response_time_hour, WEEK(FROM_UNIXTIME(r.created)) as week_num
                    FROM {forum_posts} q
                    JOIN {forum_posts} r ON r.parent = q.id
                    JOIN {forum_discussions} d ON q.discussion = d.id
                    JOIN {course} cc ON cc.id = d.course    
                    JOIN {user} uq ON q.userid = uq.id
                    JOIN {user} ur ON r.userid = ur.id
                    JOIN {role_assignments} ra ON ur.id = ra.userid
                    JOIN {role_assignments} raq ON uq.id = raq.userid
                    JOIN {role} role ON role.id = ra.roleid
                    JOIN {role} roleq ON roleq.id = raq.roleid
                    WHERE (role.shortname = 'editingteacher') AND 
                    roleq.shortname = 'student' AND (ur.deleted = 0 AND uq.deleted = 0 AND q.deleted = 0 AND r.deleted = 0)
                    GROUP BY urid, cc.id, state
                    ORDER BY state";
            }
            else if ($user === 'admin_all_user_self') {
                $roles = get_user_roles($context, $USER->id, true);
                $role = key($roles);
                $rolename = $roles[$role]->shortname;
                if ($rolename === 'manager') {
                    return $this->teacher_time_response('all', $plot, $group);
                } else if ($rolename === 'editingteacher') {
                    return $this->teacher_time_response('user', $plot, $group);
                }
            }

            $teacherResponseTimes = array_values($DB->get_records_sql($chartQuery));

            if ($user === 'user') {
                $tempText .= '<div id="div_class">'.PHP_EOL.
                    "\t".'<h3 class="main_title">مدت زمان پاسخگویی '.$username.' به سوالات در انجمن (فروم) به صورت '.$timeText.'</h3>';
            } else {
                $tempText .= '<div id="div_class">'.PHP_EOL.
                    "\t".'<h3 class="main_title">مدت زمان پاسخگویی تمام مدرسان به سوالات در انجمن (فروم) به صورت '.$timeText.'</h3>';
            }

            $groupedArray = array();
            foreach ($teacherResponseTimes as $response) {
                $groupedArray[$response->ccid][] = $response;
            }

            foreach ($groupedArray as $course => $responseContent) {
                $mainGroupedResult = [];
                $courseName = ($DB->get_record('course', ['id'=>$course]))->fullname;
                if ($group === 'daily') {
                    foreach ($responseContent as $res) {
                        $mainGroupedResult[(int)(explode('-', $res->state)[0])][] = $res;
                    }
                } else {
                    foreach ($responseContent as $res) {
                        $mainGroupedResult[$res->week_num][] = $res;
                    }
                }

                $mainResultArray = [];
                $currentUser = null;
                foreach ($mainGroupedResult as $time => $results) {
                    $totalTime = 0;
                    foreach ($results as $currentRes) {
                        if (is_null($currentUser)) $currentUser = $currentRes->teachername;
                        $totalTime += $currentRes->response_time_hour;
                    }
                    $arrayValue = new stdClass();
                    $arrayValue->course = $courseName;
                    $arrayValue->totalTime = $totalTime;
                    $arrayValue->username = $currentUser;
                    $mainResultArray[$time] = $arrayValue;
                }

                if ($plot == 'line_sharp') {
                    $chart = new \core\chart_line();
                } else if ($plot == 'line_smooth') {
                    $chart = new \core\chart_line();
                    $chart->set_smooth(true);

                } else if ($plot == 'pie') {
                    $chart = new \core\chart_pie();

                } else if ($plot == 'doughnut') {
                    $chart = new \core\chart_pie();
                    $chart->set_doughnut(true);

                } else if ($plot == 'bar') {
                    $chart = new \core\chart_bar();
                }

                $groupX = [];
                $groupY = [];
                $currentUser = null;
                $currentCourse = null;
                foreach ($mainResultArray as $time => $content) {
                    array_push($groupX, $time);
                    array_push($groupY, $content->totalTime);
                    if (is_null($currentUser)) $currentUser = $content->username;
                    if (is_null($currentCourse)) $currentCourse = $content->course;
                }
                $series = new \core\chart_series($currentCourse, $groupY);
                $chart->add_series($series);
                $chart->set_labels($groupX);
                if ($plot !== 'pie' && $plot !== 'doughnut') $chart->set_title(' مدت زمان پاسخ '.$currentUser);
                else $chart->set_title(' مدت زمان پاسخ '.$currentUser.' در دوره '.$currentCourse);


                if ($plot !== 'pie' && $plot !== 'doughnut') $chart->get_yaxis(0, true)->set_min(0);

                $tempText .= $OUTPUT->render($chart).'<br>';
            }
            $tempText .= "\t".'</div>'."<br>";
        }

        return $tempText;

	}
    public function teacher_main_info ($user): string {
        global $DB, $USER, $PAGE, $CFG, $OUTPUT, $username;
        $uid = $USER->id;
        $username = $USER->username;
        $tempText = '';
        $context = context_system::instance();

        try {
            $PAGE->requires->css('/local/teachers_dashboard/Styles/styles.css');
        } catch (exception $e) {
        }

        if ($user === 'user') {
            $context = context_system::instance();
            $roles = get_user_roles($context, $USER->id, true);
            $role = key($roles);
            $rolename = $roles[$role]->shortname;

            $tempText .= '<div id="div_class">'.PHP_EOL.
                "\t".'<h3 class="main_title">اطلاعات کاربری '.$username.'</h3>'.PHP_EOL.
                "\t".'<table class="data-table">'.PHP_EOL."\t\t".'<tr>'.PHP_EOL.
                "\t\t".'<th>نام</th>'.PHP_EOL."\t\t".'<th>نام خانوادگی</th>'.PHP_EOL.
                "\t\t".'<th>نقش</th>'.PHP_EOL."\t\t".'<th>ایمیل</th>'.PHP_EOL."\t\t".'<th>دپارتمان</th>'.PHP_EOL.
                "\t\t".'<th>تلفن</th>'.PHP_EOL."\t\t".'<th>شهر</th>'.PHP_EOL."\t\t".'<th>کشور</th>'.PHP_EOL.
                "\t\t".'</tr>';

            $tempText .= '<tr>';
            $tempText .= '<td>'.$USER->firstname.'</td>';
            $tempText .= '<td>'.$USER->lastname.'</td>';
            $tempText .= '<td>'.$rolename.'</td>';
            $tempText .= '<td>'.$USER->email.'</td>';
            $tempText .= '<td>'.$USER->department.'</td>';
            $tempText .= '<td>'.$USER->phone1.'</td>';
            $tempText .= '<td>'.$USER->city.'</td>';
            $tempText .= '<td>'.$USER->country.'</td>';
            $tempText .= '</tr>';

        } else if ($user === 'all') {
            $allUsers = $DB->get_records('user');


            $tempText .= '<div id="div_class">'.PHP_EOL.
                "\t".'<h3 class="main_title">اطلاعات کاربری تمام مدرسان</h3>'.PHP_EOL.
                "\t".'<table class="data-table">'.PHP_EOL."\t\t".'<tr>'.PHP_EOL.
                "\t\t".'<th>نام</th>'.PHP_EOL."\t\t".'<th>نام خانوادگی</th>'.PHP_EOL.
                "\t\t".'<th>نقش</th>'.PHP_EOL."\t\t".'<th>ایمیل</th>'.PHP_EOL."\t\t".'<th>دپارتمان</th>'.PHP_EOL.
                "\t\t".'<th>تلفن</th>'.PHP_EOL."\t\t".'<th>شهر</th>'.PHP_EOL."\t\t".'<th>کشور</th>'.PHP_EOL.
                "\t\t".'</tr>';


            foreach ($allUsers as $user) {
                $roles = get_user_roles($context, $user->id, true);
                $role = key($roles);
                $rolename = '';
                if (isset($roles[$role])) {
                    $rolename = $roles[$role]->shortname;
                }
                if (strlen($rolename) > 0 && $rolename === 'editingteacher') {
                    $tempText .= '<tr>';
                    $tempText .= '<td>'.$user->firstname.'</td>';
                    $tempText .= '<td>'.$user->lastname.'</td>';
                    $tempText .= '<td>'.$rolename.'</td>';
                    $tempText .= '<td>'.$user->email.'</td>';
                    $tempText .= '<td>'.$user->department.'</td>';
                    $tempText .= '<td>'.$user->phone1.'</td>';
                    $tempText .= '<td>'.$user->city.'</td>';
                    $tempText .= '<td>'.$user->country.'</td>';
                    $tempText .= '</tr>';
                }
            }
        } else if ($user === 'admin_all_user_self') {
            $roles = get_user_roles($context, $USER->id, true);
            $role = key($roles);
            $rolename = $roles[$role]->shortname;
            if ($rolename === 'manager') {
                return $this->teacher_main_info('all');
            } else if ($rolename === 'editingteacher') {
                return $this->teacher_main_info('user');
            }
        }
        $tempText .= "\t".'</table>'.PHP_EOL.'</div>'.'<br>';
        return $tempText;

	}

}

?>