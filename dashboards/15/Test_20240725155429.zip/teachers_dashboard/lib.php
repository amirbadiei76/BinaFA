<?php
/**
 * @package     local_teachers_dashboard
 * @author      Kristian
 * @license     http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 * @var stdClass $plugin
 */

defined('MOODLE_INTERNAL') || die();

require_once (__DIR__.'/../../config.php');


/**
 * @param global_navigation $nav
 * @throws coding_exception
 * @throws moodle_exception
 */


function local_teachers_dashboard_extend_navigation(global_navigation $navigation) {
    global $DB, $USER, $CFG, $PAGE, $OUTPUT, $COURSE, $ADMIN, $SITE;

    $context = context_system::instance();

    $url = $CFG->wwwroot.'/local/teachers_dashboard/index.php';

    $settingbeforekey = get_config('local_teachers_dashboard', 'navigation_position_beforekey');

    $beforekey = $settingbeforekey;
    $beforekey = null;
    if ($settingbeforekey === false || $settingbeforekey === '') {
        // Find first section node, and add our node before that (to be the last non-section node)
        $children = $navigation->children->type(navigation_node::TYPE_SECTION);
        if (count($children) !== 0) {
            $beforekey = reset($children)->key;
        }
    } else { // use setting
        $beforekey = $settingbeforekey;
    }

    if (isloggedin()) {
        $nodeText = 'پیشخوان تحلیل عملکرد مدرسان';

        $myNode = navigation_node::create(
            $nodeText,
            new moodle_url($url),
            navigation_node::TYPE_CUSTOM,
            null, $nodeText,
            new pix_icon('i/report', '')
        );
        $myNode->showinflatnavigation = true;

        $navigation->add_node($myNode, $beforekey);
    }
}