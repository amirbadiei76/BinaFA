<?php
/**
* @package     local_teachers_dashboard
* @author      Kristian
* @license     http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
* @var stdClass $plugin
*/

class StudentAnalytics {

    public function student_main_info ($user): string {
        global $DB, $USER, $PAGE, $CFG, $OUTPUT;
        $uid = $USER->id;
        $username = $USER->username;
        $tempText = '';
        $context = context_system::instance();

        try {
            $PAGE->requires->css('/local/teachers_dashboard/Styles/styles.css');
        } catch (exception $e) {
        }

        if ($user === 'user') {
            $userCourseQuery =
                "SELECT DISTINCT cc.id AS cid
                    FROM {user} u
                    JOIN {user_enrolments} ue ON ue.userid = u.id
                    JOIN {enrol} e ON e.id = ue.enrolid
                    JOIN {context} c ON c.instanceid = e.courseid
                    JOIN {role_assignments} ra ON (ra.userid = u.id AND ra.contextid = c.id)
                    JOIN {role} r ON ra.roleid = r.id
                    JOIN {course} cc ON e.courseid = cc.id
                    WHERE u.id = {$uid} AND u.deleted = 0 AND cc.id IS NOT NULL AND (r.shortname = 'editingteacher')
                    GROUP BY cc.id";

            $userCourses = array_values($DB->get_records_sql($userCourseQuery));
            $tempText .= '<div id="div_class">'.PHP_EOL.
                "\t".'<h3 class="main_title">اطلاعات کاربری فراگیران حاضر در دوره های '.$username.'</h3>'.PHP_EOL.
                "\t".'<table class="data-table">'.PHP_EOL."\t\t".'<tr>'.PHP_EOL.
                "\t\t".'<th>نام</th>'.PHP_EOL."\t\t".'<th>نام خانوادگی</th>'.PHP_EOL.
                "\t\t".'<th>نام کاربری</th>'.PHP_EOL."\t\t".'<th>ایمیل</th>'.PHP_EOL."\t\t".'<th>دپارتمان</th>'.PHP_EOL.
                "\t\t".'<th>تلفن</th>'.PHP_EOL."\t\t".'<th>شهر</th>'.PHP_EOL."\t\t".'<th>کشور</th>'.PHP_EOL.
                "\t\t".'</tr>';

            $users = [];
            foreach ($userCourses as $course) {
                $userInfoQuery =
                    "SELECT u.id as uid, u.username, u.firstname, u.lastname, u.email, u.department, u.phone1, u.city, u.country
                    FROM {user} u
                    JOIN {user_enrolments} ue ON ue.userid = u.id
                    JOIN {enrol} e ON e.id = ue.enrolid
                    JOIN {context} c ON c.instanceid = e.courseid
                    JOIN {role_assignments} ra ON (ra.userid = u.id AND ra.contextid = c.id)
                    JOIN {role} r ON ra.roleid = r.id
                    JOIN {course} cc ON e.courseid = cc.id
                    WHERE cc.id = ($course->cid) AND u.deleted = 0 AND cc.id IS NOT NULL AND (r.shortname = 'student')
                    ";
                $userInfo = array_values($DB->get_records_sql($userInfoQuery));

                foreach ($userInfo as $currentUser) {
                    if (!key_exists($currentUser->uid, $users)) {
                        $stdclass = new stdClass();
                        $stdclass->firstname = $currentUser->firstname;
                        $stdclass->lastname = $currentUser->lastname;
                        $stdclass->username = $currentUser->username;
                        $stdclass->email = $currentUser->email;
                        $stdclass->department = $currentUser->department;
                        $stdclass->phone = $currentUser->phone1;
                        $stdclass->city = $currentUser->city;
                        $stdclass->country = $currentUser->country;
                        $users[$currentUser->uid] = $stdclass;
                    }
                }
            }
            foreach ($users as $currentUser) {
                $tempText .= '<tr>';
                $tempText .= '<td>'.$currentUser->firstname.'</td>';
                $tempText .= '<td>'.$currentUser->lastname.'</td>';
                $tempText .= '<td>'.$currentUser->username.'</td>';
                $tempText .= '<td>'.$currentUser->email.'</td>';
                $tempText .= '<td>'.$currentUser->department.'</td>';
                $tempText .= '<td>'.$currentUser->phone.'</td>';
                $tempText .= '<td>'.$currentUser->city.'</td>';
                $tempText .= '<td>'.$currentUser->country.'</td>';
                $tempText .= '</tr>';
            }
        } else if ($user === 'all') {
            $allCoursesQuery =
                "SELECT DISTINCT cc.id AS cid
                    FROM {user} u
                    JOIN {user_enrolments} ue ON ue.userid = u.id
                    JOIN {enrol} e ON e.id = ue.enrolid
                    JOIN {context} c ON c.instanceid = e.courseid
                    JOIN {role_assignments} ra ON (ra.userid = u.id AND ra.contextid = c.id)
                    JOIN {role} r ON ra.roleid = r.id
                    JOIN {course} cc ON e.courseid = cc.id
                    WHERE u.deleted = 0 AND cc.id IS NOT NULL AND (r.shortname = 'editingteacher')
                    GROUP BY cc.id";

            $allCourses = array_values($DB->get_records_sql($allCoursesQuery));

            $tempText .= '<div id="div_class">'.PHP_EOL.
                "\t".'<h3 class="main_title">اطلاعات کاربری فراگیران حاضر در تمام دوره ها</h3>'.PHP_EOL.
                "\t".'<table class="data-table">'.PHP_EOL."\t\t".'<tr>'.PHP_EOL.
                "\t\t".'<th>نام</th>'.PHP_EOL."\t\t".'<th>نام خانوادگی</th>'.PHP_EOL.
                "\t\t".'<th>نام کاربری</th>'.PHP_EOL."\t\t".'<th>ایمیل</th>'.PHP_EOL."\t\t".'<th>دپارتمان</th>'.PHP_EOL.
                "\t\t".'<th>تلفن</th>'.PHP_EOL."\t\t".'<th>شهر</th>'.PHP_EOL."\t\t".'<th>کشور</th>'.PHP_EOL.
                "\t\t".'</tr>';

            $users = [];
            foreach ($allCourses as $course) {
                $userInfoQuery =
                    "SELECT u.id as uid, u.firstname, u.username, u.lastname, u.email, u.department, u.phone1, u.city, u.country
                    FROM {user} u
                    JOIN {user_enrolments} ue ON ue.userid = u.id
                    JOIN {enrol} e ON e.id = ue.enrolid
                    JOIN {context} c ON c.instanceid = e.courseid
                    JOIN {role_assignments} ra ON (ra.userid = u.id AND ra.contextid = c.id)
                    JOIN {role} r ON ra.roleid = r.id
                    JOIN {course} cc ON e.courseid = cc.id
                    WHERE cc.id = ($course->cid) AND u.deleted = 0 AND cc.id IS NOT NULL AND (r.shortname = 'student')
                    ";
                $userInfo = array_values($DB->get_records_sql($userInfoQuery));

                foreach ($userInfo as $currentUser) {
                    if (!key_exists($currentUser->uid, $users)) {
                        $stdclass = new stdClass();
                        $stdclass->firstname = $currentUser->firstname;
                        $stdclass->lastname = $currentUser->lastname;
                        $stdclass->username = $currentUser->username;
                        $stdclass->email = $currentUser->email;
                        $stdclass->department = $currentUser->department;
                        $stdclass->phone = $currentUser->phone1;
                        $stdclass->city = $currentUser->city;
                        $stdclass->country = $currentUser->country;
                        $users[$currentUser->uid] = $stdclass;
                    }
                }
            }
            foreach ($users as $currentUser) {
                $tempText .= '<tr>';
                $tempText .= '<td>'.$currentUser->firstname.'</td>';
                $tempText .= '<td>'.$currentUser->lastname.'</td>';
                $tempText .= '<td>'.$currentUser->username.'</td>';
                $tempText .= '<td>'.$currentUser->email.'</td>';
                $tempText .= '<td>'.$currentUser->department.'</td>';
                $tempText .= '<td>'.$currentUser->phone.'</td>';
                $tempText .= '<td>'.$currentUser->city.'</td>';
                $tempText .= '<td>'.$currentUser->country.'</td>';
                $tempText .= '</tr>';
            }
        }  else if ($user === 'admin_all_user_self') {
            $roles = get_user_roles($context, $USER->id, true);
            $role = key($roles);
            $rolename = $roles[$role]->shortname;
            if ($rolename === 'manager') {
                return $this->student_main_info('all');
            } else if ($rolename === 'editingteacher') {
                return $this->student_main_info('user');
            }
        }

        $tempText .= "\t".'</table>'.PHP_EOL.'</div>'.'<br>';
        return $tempText;

	}
    public function student_active_students ($user, $plot): string {
        global $DB, $USER, $PAGE, $CFG, $OUTPUT;
        $uid = $USER->id;
        $username = $USER->username;
        $tempText = '';
        $context = context_system::instance();

        try {
            $PAGE->requires->css('/local/teachers_dashboard/Styles/styles.css');
        } catch (exception $e) {
        }

        if ($plot === 'table') {
            if ($user === 'user') {
                $userCourseQuery =
                    "SELECT DISTINCT cc.id AS cid, cc.fullname AS coursename
                    FROM {user} u
                    JOIN {user_enrolments} ue ON ue.userid = u.id
                    JOIN {enrol} e ON e.id = ue.enrolid
                    JOIN {context} c ON c.instanceid = e.courseid
                    JOIN {role_assignments} ra ON (ra.userid = u.id AND ra.contextid = c.id)
                    JOIN {role} r ON ra.roleid = r.id
                    JOIN {course} cc ON e.courseid = cc.id
                    WHERE u.id = {$uid} AND u.deleted = 0 AND cc.id IS NOT NULL AND (r.shortname = 'editingteacher')
                    GROUP BY cc.id";

                $userCourses = array_values($DB->get_records_sql($userCourseQuery));

                $tempText .= '<div id="div_class">'.PHP_EOL.
                    "\t".'<h3 class="main_title">درصد و تعداد فراگیران فعال در انجمن در دوره های '.$username.'</h3>'.PHP_EOL. "\t".'<table class="data-table">'.PHP_EOL."\t\t".'<tr>'.PHP_EOL."\t\t".'<th>نام دوره</th>'.PHP_EOL."\t\t".'<th>نام انجمن</th>'.PHP_EOL."\t\t".'<th>تعداد فراگیران</th>'.PHP_EOL."\t\t".'<th>تعداد فراگیران فعال</th>'.'<th>درصد</th>'.PHP_EOL."\t\t"."\t\t".'</tr>';

                foreach ($userCourses as $currentCourse) {
                    $activeStudentsCountQuery =
                        "SELECT f.id as fid, d.id as did, f.name, COUNT(DISTINCT u.id) as cnt
                        FROM {forum_posts} q
                        JOIN {forum_discussions} d ON q.discussion = d.id   
                        JOIN {forum} f ON f.id = d.forum
                        JOIN {course} cc ON cc.id = d.course
                        JOIN {user} u ON q.userid = u.id
                        JOIN {role_assignments} ra ON ra.userid = u.id
                        JOIN {role} r ON ra.roleid = r.id
                        WHERE cc.id = {$currentCourse->cid} AND r.shortname = 'student'
                        GROUP BY f.id";

                    $participantsQuery =
                        "SELECT c.id as cid, COUNT(DISTINCT ue.userid) as participants
                        FROM {user} u
                        JOIN {user_enrolments} ue ON ue.userid = u.id
                        JOIN {enrol} e ON e.id = ue.enrolid
                        JOIN {course} c ON e.courseid = c.id
                        JOIN {role_assignments} ra ON ra.userid = u.id
                        JOIN {role} r ON ra.roleid = r.id
                        WHERE r.shortname = 'student' AND c.id = {$currentCourse->cid}
                        GROUP BY c.id";

                    $activeStudentsCount = array_values($DB->get_records_sql($activeStudentsCountQuery));
                    $participants = array_values($DB->get_records_sql($participantsQuery));

                    if (!empty($activeStudentsCount)) {
                        foreach ($activeStudentsCount as $activeForums) {
                            $tempText .= '<tr>';
                            $participantCount = 0;
                            $tempText .= '<td>'.$currentCourse->coursename.'</td>';
                            $tempText .= '<td>'.$activeForums->name.'</td>';
                            if (!empty($participants) && $participants[0]->participants) {
                                $participantCount = $participants[0]->participants;
                                $tempText .= '<td>'.$participantCount.'</td>';
                            } else {
                                $tempText .= '<td>0</td>';
                            }
                            $activeCount = $activeForums->cnt;
                            $activePercent = ($participantCount > 0) ? (($activeCount * 100)/$participantCount) : 0;
                            $activePercent = number_format($activePercent, 2, '.', '');
                            $tempText .= '<td>'.$activeCount.'</td>';
                            $tempText .= '<td>'.$activePercent.'%</td>';
                            $tempText .= '</tr>';
                        }
                    } else {
                        $participantCount = 0;
                        $tempText .= '<td>'.$currentCourse->coursename.'</td>';
                        $tempText .= '<td>-</td>';
                        if (!empty($participants) && $participants[0]->participants) {
                            $participantCount = $participants[0]->participants;
                            $tempText .= '<td>'.$participantCount.'</td>';
                        } else {
                            $tempText .= '<td>0</td>';
                        }
                        $tempText .= '<td>0</td>';
                        $tempText .= '<td>0.00%</td>';
                        $tempText .= '</tr>';
                    }
                }
            } else if ($user === 'all') {
                $allCoursesQuery =
                    "SELECT DISTINCT cc.id AS cid, cc.fullname AS coursename
                    FROM {user} u
                    JOIN {user_enrolments} ue ON ue.userid = u.id
                    JOIN {enrol} e ON e.id = ue.enrolid
                    JOIN {context} c ON c.instanceid = e.courseid
                    JOIN {role_assignments} ra ON (ra.userid = u.id AND ra.contextid = c.id)
                    JOIN {role} r ON ra.roleid = r.id
                    JOIN {course} cc ON e.courseid = cc.id
                    WHERE u.deleted = 0 AND cc.id IS NOT NULL AND (r.shortname = 'editingteacher')
                    GROUP BY cc.id";

                $allCourses = array_values($DB->get_records_sql($allCoursesQuery));

                $tempText .= '<div id="div_class">'.PHP_EOL.
                    "\t".'<h3 class="main_title">درصد و تعداد فراگیران فعال در انجمن در تمام دوره ها </h3>'.PHP_EOL. "\t".'<table class="data-table">'.PHP_EOL."\t\t".'<tr>'.PHP_EOL."\t\t".'<th>نام دوره</th>'.PHP_EOL."\t\t".'<th>نام انجمن</th>'.PHP_EOL."\t\t".'<th>تعداد فراگیران</th>'.PHP_EOL."\t\t".'<th>تعداد فراگیران فعال</th>'.'<th>درصد</th>'.PHP_EOL."\t\t"."\t\t".'</tr>';

                foreach ($allCourses as $currentCourse) {
                    $activeStudentsCountQuery =
                        "SELECT f.id as fid, d.id as did, f.name, COUNT(DISTINCT u.id) as cnt
                        FROM {forum_posts} q
                        JOIN {forum_discussions} d ON q.discussion = d.id   
                        JOIN {forum} f ON f.id = d.forum
                        JOIN {course} cc ON cc.id = d.course
                        JOIN {user} u ON q.userid = u.id
                        JOIN {role_assignments} ra ON ra.userid = u.id
                        JOIN {role} r ON ra.roleid = r.id
                        WHERE cc.id = {$currentCourse->cid} AND r.shortname = 'student'
                        GROUP BY f.id";

                    $participantsQuery =
                        "SELECT c.id as cid, COUNT(DISTINCT ue.userid) as participants
                        FROM {user} u
                        JOIN {user_enrolments} ue ON ue.userid = u.id
                        JOIN {enrol} e ON e.id = ue.enrolid
                        JOIN {course} c ON e.courseid = c.id
                        JOIN {role_assignments} ra ON ra.userid = u.id
                        JOIN {role} r ON ra.roleid = r.id
                        WHERE r.shortname = 'student' AND c.id = {$currentCourse->cid}
                        GROUP BY c.id";

                    $activeStudentsCount = array_values($DB->get_records_sql($activeStudentsCountQuery));
                    $participants = array_values($DB->get_records_sql($participantsQuery));

                    if (!empty($activeStudentsCount)) {
                        foreach ($activeStudentsCount as $activeForums) {
                            $tempText .= '<tr>';
                            $participantCount = 0;
                            $tempText .= '<td>'.$currentCourse->coursename.'</td>';
                            $tempText .= '<td>'.$activeForums->name.'</td>';
                            if (!empty($participants) && $participants[0]->participants) {
                                $participantCount = $participants[0]->participants;
                                $tempText .= '<td>'.$participantCount.'</td>';
                            } else {
                                $tempText .= '<td>0</td>';
                            }
                            $activeCount = $activeForums->cnt;
                            $activePercent = ($participantCount > 0) ? (($activeCount * 100)/$participantCount) : 0;
                            $activePercent = number_format($activePercent, 2, '.', '');
                            $tempText .= '<td>'.$activeCount.'</td>';
                            $tempText .= '<td>'.$activePercent.'%</td>';
                            $tempText .= '</tr>';
                        }
                    } else {
                        $participantCount = 0;
                        $tempText .= '<td>'.$currentCourse->coursename.'</td>';
                        $tempText .= '<td>-</td>';
                        if (!empty($participants) && $participants[0]->participants) {
                            $participantCount = $participants[0]->participants;
                            $tempText .= '<td>'.$participantCount.'</td>';
                        } else {
                            $tempText .= '<td>0</td>';
                        }
                        $tempText .= '<td>0</td>';
                        $tempText .= '<td>0.00%</td>';
                        $tempText .= '</tr>';
                    }
                }
            }  else if ($user === 'admin_all_user_self') {
                $roles = get_user_roles($context, $USER->id, true);
                $role = key($roles);
                $rolename = $roles[$role]->shortname;
                if ($rolename === 'manager') {
                    return $this->student_active_students('all', $plot);
                } else if ($rolename === 'editingteacher') {
                    return $this->student_active_students('user', $plot);
                }
            }

            $tempText .= "\t".'</table>'.PHP_EOL.'</div>'.'<br>';
        } else {
            // is chart
            if ($user === 'user') {
                $userCourseQuery =
                    "SELECT DISTINCT cc.id AS cid, cc.fullname AS coursename
                    FROM {user} u
                    JOIN {user_enrolments} ue ON ue.userid = u.id
                    JOIN {enrol} e ON e.id = ue.enrolid
                    JOIN {context} c ON c.instanceid = e.courseid
                    JOIN {role_assignments} ra ON (ra.userid = u.id AND ra.contextid = c.id)
                    JOIN {role} r ON ra.roleid = r.id
                    JOIN {course} cc ON e.courseid = cc.id
                    WHERE u.id = {$uid} AND u.deleted = 0 AND cc.id IS NOT NULL AND (r.shortname = 'editingteacher')
                    GROUP BY cc.id";

                $userCourses = array_values($DB->get_records_sql($userCourseQuery));
                $tempText .= '<div id="div_class">'.PHP_EOL.
                    "\t".'<h3 class="main_title">درصد و تعداد فراگیران فعال در انجمن در دوره های '.$username.'</h3>'.PHP_EOL;

                $activeCountYValues = [];
                $courseForumValues = [];
                foreach ($userCourses as $currentCourse) {
                    $activeStudentsCountQuery =
                        "SELECT f.id as fid, d.id as did, f.name, COUNT(DISTINCT u.id) as cnt
                        FROM {forum_posts} q
                        JOIN {forum_discussions} d ON q.discussion = d.id   
                        JOIN {forum} f ON f.id = d.forum
                        JOIN {course} cc ON cc.id = d.course
                        JOIN {user} u ON q.userid = u.id
                        JOIN {role_assignments} ra ON ra.userid = u.id
                        JOIN {role} r ON ra.roleid = r.id
                        WHERE cc.id = {$currentCourse->cid} AND r.shortname = 'student'
                        GROUP BY f.id";

                    $participantsQuery =
                        "SELECT c.id as cid, COUNT(DISTINCT ue.userid) as participants
                        FROM {user} u
                        JOIN {user_enrolments} ue ON ue.userid = u.id
                        JOIN {enrol} e ON e.id = ue.enrolid
                        JOIN {course} c ON e.courseid = c.id
                        JOIN {role_assignments} ra ON ra.userid = u.id
                        JOIN {role} r ON ra.roleid = r.id
                        WHERE r.shortname = 'student' AND c.id = {$currentCourse->cid}
                        GROUP BY c.id";

                    $activeStudentsCount = array_values($DB->get_records_sql($activeStudentsCountQuery));
                    $participants = array_values($DB->get_records_sql($participantsQuery));

                    if (!empty($activeStudentsCount)) {
                        foreach ($activeStudentsCount as $activeForums) {
                            $participantCount = 0;
                            if (!empty($participants) && $participants[0]->participants) {
                                $participantCount = $participants[0]->participants;
                            }
                            $activeCount = $activeForums->cnt;
                            $activePercent = ($participantCount > 0) ? (($activeCount * 100)/$participantCount) : 0;
                            $activePercent = number_format($activePercent, 2, '.', '');

                            array_push($courseForumValues, $currentCourse->coursename.' ('.$activeCount.')');
                            array_push($activeCountYValues, $activePercent);
                        }
                    }
                }
                if ($plot == 'line_sharp') {
                    $chart = new \core\chart_line();
                } else if ($plot == 'line_smooth') {
                    $chart = new \core\chart_line();
                    $chart->set_smooth(true);

                } else if ($plot == 'pie') {
                    $chart = new \core\chart_pie();

                } else if ($plot == 'doughnut') {
                    $chart = new \core\chart_pie();
                    $chart->set_doughnut(true);
                } else if ($plot == 'bar') {
                    $chart = new \core\chart_bar();
                }

                $series = new \core\chart_series('درصد و تعداد فراگیران فعال در انجمن', $activeCountYValues);
                $chart->add_series($series);
                $chart->set_labels($courseForumValues);
                $chart->set_title(' درصد و تعداد فراگیران فعال در انجمن ها در دوره های '.$username);
                if ($plot !== 'pie' && $plot !== 'doughnut') $chart->get_yaxis(0, true)->set_min(0);

                $tempText .= $OUTPUT->render($chart).'<br>';
            } else if ($user === 'all') {
                $userCourseQuery =
                    "SELECT DISTINCT cc.id AS cid, cc.fullname AS coursename
                    FROM {user} u
                    JOIN {user_enrolments} ue ON ue.userid = u.id
                    JOIN {enrol} e ON e.id = ue.enrolid
                    JOIN {context} c ON c.instanceid = e.courseid
                    JOIN {role_assignments} ra ON (ra.userid = u.id AND ra.contextid = c.id)
                    JOIN {role} r ON ra.roleid = r.id
                    JOIN {course} cc ON e.courseid = cc.id
                    WHERE u.deleted = 0 AND cc.id IS NOT NULL AND (r.shortname = 'editingteacher')
                    GROUP BY cc.id";

                $userCourses = array_values($DB->get_records_sql($userCourseQuery));
                $tempText .= '<div id="div_class">'.PHP_EOL.
                    "\t".'<h3 class="main_title">درصد و تعداد فراگیران فعال در انجمن در تمام دوره ها</h3>'.PHP_EOL;

                $activeCountYValues = [];
                $courseForumValues = [];
                foreach ($userCourses as $currentCourse) {
                    $activeStudentsCountQuery =
                        "SELECT f.id as fid, d.id as did, f.name, COUNT(DISTINCT u.id) as cnt
                        FROM {forum_posts} q
                        JOIN {forum_discussions} d ON q.discussion = d.id   
                        JOIN {forum} f ON f.id = d.forum
                        JOIN {course} cc ON cc.id = d.course
                        JOIN {user} u ON q.userid = u.id
                        JOIN {role_assignments} ra ON ra.userid = u.id
                        JOIN {role} r ON ra.roleid = r.id
                        WHERE cc.id = {$currentCourse->cid} AND r.shortname = 'student'
                        GROUP BY f.id";

                    $participantsQuery =
                        "SELECT c.id as cid, COUNT(DISTINCT ue.userid) as participants
                        FROM {user} u
                        JOIN {user_enrolments} ue ON ue.userid = u.id
                        JOIN {enrol} e ON e.id = ue.enrolid
                        JOIN {course} c ON e.courseid = c.id
                        JOIN {role_assignments} ra ON ra.userid = u.id
                        JOIN {role} r ON ra.roleid = r.id
                        WHERE r.shortname = 'student' AND c.id = {$currentCourse->cid}
                        GROUP BY c.id";

                    $activeStudentsCount = array_values($DB->get_records_sql($activeStudentsCountQuery));
                    $participants = array_values($DB->get_records_sql($participantsQuery));

                    if (!empty($activeStudentsCount)) {
                        foreach ($activeStudentsCount as $activeForums) {
                            $participantCount = 0;
                            if (!empty($participants) && $participants[0]->participants) {
                                $participantCount = $participants[0]->participants;
                            }
                            $activeCount = $activeForums->cnt;
                            $activePercent = ($participantCount > 0) ? (($activeCount * 100)/$participantCount) : 0;
                            $activePercent = number_format($activePercent, 2, '.', '');

                            array_push($courseForumValues, $currentCourse->coursename.' ('.$activeCount.')');
                            array_push($activeCountYValues, $activePercent);
                        }
                    }
                }
                if ($plot == 'line_sharp') {
                    $chart = new \core\chart_line();
                } else if ($plot == 'line_smooth') {
                    $chart = new \core\chart_line();
                    $chart->set_smooth(true);

                } else if ($plot == 'pie') {
                    $chart = new \core\chart_pie();

                } else if ($plot == 'doughnut') {
                    $chart = new \core\chart_pie();
                    $chart->set_doughnut(true);
                } else if ($plot == 'bar') {
                    $chart = new \core\chart_bar();
                }

                $series = new \core\chart_series('درصد و تعداد فراگیران فعال در انجمن', $activeCountYValues);
                $chart->add_series($series);
                $chart->set_labels($courseForumValues);
                $chart->set_title(' درصد و تعداد فراگیران فعال در انجمن ها در دوره ها');
                if ($plot !== 'pie' && $plot !== 'doughnut') $chart->get_yaxis(0, true)->set_min(0);

                $tempText .= $OUTPUT->render($chart).'<br>';
            }  else if ($user === 'admin_all_user_self') {
                $roles = get_user_roles($context, $USER->id, true);
                $role = key($roles);
                $rolename = $roles[$role]->shortname;
                if ($rolename === 'manager') {
                    return $this->student_active_students('all', $plot);
                } else if ($rolename === 'editingteacher') {
                    return $this->student_active_students('user', $plot);
                }
            }
            $tempText .= "\t".PHP_EOL.'</div>'.'<br>';
        }

        return $tempText;

	}
    public function student_login_count ($user, $plot): string {
        global $DB, $USER, $PAGE, $CFG, $OUTPUT;
        $uid = $USER->id;
        $username = $USER->username;
        $tempText = '';
        $context = context_system::instance();

        try {
            $PAGE->requires->css('/local/teachers_dashboard/Styles/styles.css');
        } catch (exception $e) {
        }

        if ($plot === 'table') {
            if ($user === 'user') {
                $userCourseQuery =
                    "SELECT DISTINCT cc.id AS cid, cc.fullname AS coursename
                    FROM {user} u
                    JOIN {user_enrolments} ue ON ue.userid = u.id
                    JOIN {enrol} e ON e.id = ue.enrolid
                    JOIN {context} c ON c.instanceid = e.courseid
                    JOIN {role_assignments} ra ON (ra.userid = u.id AND ra.contextid = c.id)
                    JOIN {role} r ON ra.roleid = r.id
                    JOIN {course} cc ON e.courseid = cc.id
                    WHERE u.id = {$uid} AND u.deleted = 0 AND cc.id IS NOT NULL AND (r.shortname = 'editingteacher')
                    GROUP BY cc.id";

                $userCourses = array_values($DB->get_records_sql($userCourseQuery));

                $tempText .= '<div id="div_class">'.PHP_EOL.
                    "\t".'<h3 class="main_title">تعداد ورود فراگیران به محیط یادگیری در دوره های '.$username.'</h3>'.PHP_EOL. "\t".'<table class="data-table">'.PHP_EOL."\t\t".'<tr>'.PHP_EOL."\t\t".'<th>نام دوره</th>'.PHP_EOL."\t\t".'<th>تعداد فراگیران</th>'.PHP_EOL."\t\t".'<th>تعداد ورود</th>'.'<th>میانگین دوره</th>'.PHP_EOL."\t\t"."\t\t".'</tr>';

                foreach ($userCourses as $currentCourse) {
                    $loginCountQuery =
                        "SELECT u.id AS uid, u.username AS username, COUNT(*) AS cnt
                        FROM {user} u
                        JOIN {logstore_standard_log} l ON u.id = l.userid
                        JOIN {user_enrolments} ue ON ue.userid = u.id
                        JOIN {enrol} e ON e.id = ue.enrolid
                        JOIN {course} cc ON e.courseid = cc.id
                        JOIN {role_assignments} ra ON ra.userid = u.id
                        JOIN {role} r ON ra.roleid = r.id
                        WHERE r.shortname = 'student' AND cc.id = {$currentCourse->cid} AND l.eventname = '\\\\core\\\\event\\\\user_loggedin'
                        GROUP BY u.id, u.username";

                    $participantsQuery =
                        "SELECT c.id as cid, COUNT(DISTINCT ue.userid) as participants
                        FROM {user} u
                        JOIN {user_enrolments} ue ON ue.userid = u.id
                        JOIN {enrol} e ON e.id = ue.enrolid
                        JOIN {course} c ON e.courseid = c.id
                        JOIN {role_assignments} ra ON ra.userid = u.id
                        JOIN {role} r ON ra.roleid = r.id
                        WHERE r.shortname = 'student' AND c.id = {$currentCourse->cid}
                        GROUP BY c.id";

                    $loginRecords = array_values($DB->get_records_sql($loginCountQuery));
                    $participants = array_values($DB->get_records_sql($participantsQuery));

                    $totalLogin = 0;
                    foreach ($loginRecords as $logins) {
                        $totalLogin += $logins->cnt;
                    }
                    $participantCount = 0;
                    if (!empty($participants) && $participants[0]->participants)
                        $participantCount = $participants[0]->participants;
                    if (!empty($participants) && $participantCount > 0)
                        $avgLogins = number_format(($totalLogin / $participants[0]->participants), 2, '.', '');
                    else $avgLogins = '-';
                    $tempText .= '<tr>';
                    $tempText .= '<td>'.$currentCourse->coursename.'</td>';
                    $tempText .= '<td>'.$participantCount.'</td>';
                    $tempText .= '<td>'.$totalLogin.'</td>';
                    $tempText .= '<td>'.$avgLogins.'</td>';
                    $tempText .= '</tr>';
                }
            } else if ($user === 'all') {
                $allCoursesQuery =
                    "SELECT DISTINCT cc.id AS cid, cc.fullname AS coursename
                    FROM {user} u
                    JOIN {user_enrolments} ue ON ue.userid = u.id
                    JOIN {enrol} e ON e.id = ue.enrolid
                    JOIN {context} c ON c.instanceid = e.courseid
                    JOIN {role_assignments} ra ON (ra.userid = u.id AND ra.contextid = c.id)
                    JOIN {role} r ON ra.roleid = r.id
                    JOIN {course} cc ON e.courseid = cc.id
                    WHERE u.deleted = 0 AND cc.id IS NOT NULL AND (r.shortname = 'editingteacher')
                    GROUP BY cc.id";

                $allCourses = array_values($DB->get_records_sql($allCoursesQuery));

                $tempText .= '<div id="div_class">'.PHP_EOL.
                    "\t".'<h3 class="main_title">تعداد ورود فراگیران به محیط یادگیری برای تمام دوره ها</h3>'.PHP_EOL. "\t".'<table class="data-table">'.PHP_EOL."\t\t".'<tr>'.PHP_EOL."\t\t".'<th>نام دوره</th>'.PHP_EOL."\t\t".'<th>تعداد فراگیران</th>'.PHP_EOL."\t\t".'<th>تعداد ورود</th>'.'<th>میانگین دوره</th>'.PHP_EOL."\t\t"."\t\t".'</tr>';

                foreach ($allCourses as $currentCourse) {
                    $loginCountQuery =
                        "SELECT u.id AS uid, u.username AS username, COUNT(*) AS cnt
                        FROM {user} u
                        JOIN {logstore_standard_log} l ON u.id = l.userid
                        JOIN {user_enrolments} ue ON ue.userid = u.id
                        JOIN {enrol} e ON e.id = ue.enrolid
                        JOIN {course} cc ON e.courseid = cc.id
                        JOIN {role_assignments} ra ON ra.userid = u.id
                        JOIN {role} r ON ra.roleid = r.id
                        WHERE r.shortname = 'student' AND cc.id = {$currentCourse->cid} AND l.eventname = '\\\\core\\\\event\\\\user_loggedin'
                        GROUP BY u.id, u.username";

                    $participantsQuery =
                        "SELECT c.id as cid, COUNT(DISTINCT ue.userid) as participants
                        FROM {user} u
                        JOIN {user_enrolments} ue ON ue.userid = u.id
                        JOIN {enrol} e ON e.id = ue.enrolid
                        JOIN {course} c ON e.courseid = c.id
                        JOIN {role_assignments} ra ON ra.userid = u.id
                        JOIN {role} r ON ra.roleid = r.id
                        WHERE r.shortname = 'student' AND c.id = {$currentCourse->cid}
                        GROUP BY c.id";

                    $loginRecords = array_values($DB->get_records_sql($loginCountQuery));
                    $participants = array_values($DB->get_records_sql($participantsQuery));

                    $totalLogin = 0;
                    foreach ($loginRecords as $logins) {
                        $totalLogin += $logins->cnt;
                    }
                    $participantCount = 0;
                    if (!empty($participants) && $participants[0]->participants)
                        $participantCount = $participants[0]->participants;
                    if (!empty($participants) && $participantCount > 0)
                        $avgLogins = number_format(($totalLogin / $participants[0]->participants), 2, '.', '');
                    else $avgLogins = '-';
                    $tempText .= '<tr>';
                    $tempText .= '<td>'.$currentCourse->coursename . '</td>';
                    $tempText .= '<td>'.$participantCount. '</td>';
                    $tempText .= '<td>'.$totalLogin.'</td>';
                    $tempText .= '<td>'.$avgLogins.'</td>';
                    $tempText .= '</tr>';
                }
            }  else if ($user === 'admin_all_user_self') {
                $roles = get_user_roles($context, $USER->id, true);
                $role = key($roles);
                $rolename = $roles[$role]->shortname;
                if ($rolename === 'manager') {
                    return $this->student_login_count('all', $plot);
                } else if ($rolename === 'editingteacher') {
                    return $this->student_login_count('user', $plot);
                }
            }

            $tempText .= "\t".'</table>'.PHP_EOL.'</div>'.'<br>';
        } else {
            // is chart

            if ($user === 'user') {
                $userCourseQuery =
                    "SELECT DISTINCT cc.id AS cid, cc.fullname AS coursename
                    FROM {user} u
                    JOIN {user_enrolments} ue ON ue.userid = u.id
                    JOIN {enrol} e ON e.id = ue.enrolid
                    JOIN {context} c ON c.instanceid = e.courseid
                    JOIN {role_assignments} ra ON (ra.userid = u.id AND ra.contextid = c.id)
                    JOIN {role} r ON ra.roleid = r.id
                    JOIN {course} cc ON e.courseid = cc.id
                    WHERE u.id = {$uid} AND u.deleted = 0 AND cc.id IS NOT NULL AND (r.shortname = 'editingteacher')
                    GROUP BY cc.id";

                $userCourses = array_values($DB->get_records_sql($userCourseQuery));
                $tempText .= '<div id="div_class">'.PHP_EOL.
                    "\t".'<h3 class="main_title">تعداد ورود فراگیران به محیط یادگیری در دوره های '.$username.'</h3>'.PHP_EOL;

                $loginYValues = [];
                $avgLoginYValues = [];
                $courseValues = [];

                foreach ($userCourses as $currentCourse) {
                    $loginCountQuery =
                        "SELECT u.id AS uid, u.username AS username, COUNT(*) AS cnt
                        FROM {user} u
                        JOIN {logstore_standard_log} l ON u.id = l.userid
                        JOIN {user_enrolments} ue ON ue.userid = u.id
                        JOIN {enrol} e ON e.id = ue.enrolid
                        JOIN {course} cc ON e.courseid = cc.id
                        JOIN {role_assignments} ra ON ra.userid = u.id
                        JOIN {role} r ON ra.roleid = r.id
                        WHERE r.shortname = 'student' AND cc.id = {$currentCourse->cid} AND l.eventname = '\\\\core\\\\event\\\\user_loggedin'
                        GROUP BY u.id, u.username";

                    $participantsQuery =
                        "SELECT c.id as cid, COUNT(DISTINCT ue.userid) as participants
                        FROM {user} u
                        JOIN {user_enrolments} ue ON ue.userid = u.id
                        JOIN {enrol} e ON e.id = ue.enrolid
                        JOIN {course} c ON e.courseid = c.id
                        JOIN {role_assignments} ra ON ra.userid = u.id
                        JOIN {role} r ON ra.roleid = r.id
                        WHERE r.shortname = 'student' AND c.id = {$currentCourse->cid}
                        GROUP BY c.id";

                    $loginRecords = array_values($DB->get_records_sql($loginCountQuery));
                    $participants = array_values($DB->get_records_sql($participantsQuery));

                    $totalLogin = 0;
                    foreach ($loginRecords as $logins) {
                        $totalLogin += $logins->cnt;
                    }
                    $participantCount = 0;
                    $avgLogins = 0;
                    if (!empty($participants) && $participants[0]->participants)
                        $participantCount = $participants[0]->participants;
                    if (!empty($participants) && $participantCount > 0)
                        $avgLogins = number_format(($totalLogin / $participants[0]->participants), 2, '.', '');

                    array_push($loginYValues, $totalLogin);
                    array_push($avgLoginYValues, $avgLogins);
                    array_push($courseValues, $currentCourse->coursename);
                }
                if ($plot == 'line_sharp') {
                    $chart = new \core\chart_line();
                } else if ($plot == 'line_smooth') {
                    $chart = new \core\chart_line();
                    $chart->set_smooth(true);

                } else if ($plot == 'pie') {
                    $chart = new \core\chart_pie();

                } else if ($plot == 'doughnut') {
                    $chart = new \core\chart_pie();
                    $chart->set_doughnut(true);
                } else if ($plot == 'bar') {
                    $chart = new \core\chart_bar();
                }


                if ($plot == 'line_sharp') {
                    $chart2 = new \core\chart_line();
                } else if ($plot == 'line_smooth') {
                    $chart2 = new \core\chart_line();
                    $chart2->set_smooth(true);

                } else if ($plot == 'pie') {
                    $chart2 = new \core\chart_pie();

                } else if ($plot == 'doughnut') {
                    $chart2 = new \core\chart_pie();
                    $chart2->set_doughnut(true);
                } else if ($plot == 'bar') {
                    $chart2 = new \core\chart_bar();
                }

                if ($plot !== 'pie' && $plot !== 'doughnut') {
                    $series = new \core\chart_series('تعداد ورود فراگیران به محیط یادگیری', $loginYValues);
                    $series2 = new \core\chart_series('میانگین ورود فراگیران به محیط یادگیری', $avgLoginYValues);
                    $chart->add_series($series);
                    $chart->add_series($series2);
                    $chart->set_labels($courseValues);
                    $chart->set_title(' تعداد ورود فراگیران به محیط یادگیری در دوره های '.$username);
                }
                else {
                    $series = new \core\chart_series('تعداد ورود فراگیران به محیط یادگیری', $loginYValues);
                    $chart->add_series($series);
                    $chart->set_labels($courseValues);
                    $chart->set_title(' تعداد ورود فراگیران به محیط یادگیری در تمام دوره ها');


                    $series2 = new \core\chart_series('میانگین ورود فراگیران به محیط یادگیری', $avgLoginYValues);
                    $chart2->add_series($series2);
                    $chart2->set_labels($courseValues);
                    $chart2->set_title(' میانگین تعداد ورود فراگیران به محیط یادگیری در تمام دوره ها');
                }
                if ($plot !== 'pie' && $plot !== 'doughnut') $chart->get_yaxis(0, true)->set_min(0);

                $tempText .= $OUTPUT->render($chart).'<br>';
                if ($plot === 'pie' || $plot === 'doughnut') $tempText .= $OUTPUT->render($chart2).'<br>';

            } else if ($user === 'all') {
                $userCourseQuery =
                    "SELECT DISTINCT cc.id AS cid, cc.fullname AS coursename
                    FROM {user} u
                    JOIN {user_enrolments} ue ON ue.userid = u.id
                    JOIN {enrol} e ON e.id = ue.enrolid
                    JOIN {context} c ON c.instanceid = e.courseid
                    JOIN {role_assignments} ra ON (ra.userid = u.id AND ra.contextid = c.id)
                    JOIN {role} r ON ra.roleid = r.id
                    JOIN {course} cc ON e.courseid = cc.id
                    WHERE u.deleted = 0 AND cc.id IS NOT NULL AND (r.shortname = 'editingteacher')
                    GROUP BY cc.id";

                $userCourses = array_values($DB->get_records_sql($userCourseQuery));
                $tempText .= '<div id="div_class">'.PHP_EOL.
                    "\t".'<h3 class="main_title">تعداد ورود فراگیران به محیط یادگیری در تمام دوره ها</h3>'.PHP_EOL;

                $loginYValues = [];
                $avgLoginYValues = [];
                $courseValues = [];

                foreach ($userCourses as $currentCourse) {
                    $loginCountQuery =
                        "SELECT u.id AS uid, u.username AS username, COUNT(*) AS cnt
                        FROM {user} u
                        JOIN {logstore_standard_log} l ON u.id = l.userid
                        JOIN {user_enrolments} ue ON ue.userid = u.id
                        JOIN {enrol} e ON e.id = ue.enrolid
                        JOIN {course} cc ON e.courseid = cc.id
                        JOIN {role_assignments} ra ON ra.userid = u.id
                        JOIN {role} r ON ra.roleid = r.id
                        WHERE r.shortname = 'student' AND cc.id = {$currentCourse->cid} AND l.eventname = '\\\\core\\\\event\\\\user_loggedin'
                        GROUP BY u.id, u.username";

                    $participantsQuery =
                        "SELECT c.id as cid, COUNT(DISTINCT ue.userid) as participants
                        FROM {user} u
                        JOIN {user_enrolments} ue ON ue.userid = u.id
                        JOIN {enrol} e ON e.id = ue.enrolid
                        JOIN {course} c ON e.courseid = c.id
                        JOIN {role_assignments} ra ON ra.userid = u.id
                        JOIN {role} r ON ra.roleid = r.id
                        WHERE r.shortname = 'student' AND c.id = {$currentCourse->cid}
                        GROUP BY c.id";

                    $loginRecords = array_values($DB->get_records_sql($loginCountQuery));
                    $participants = array_values($DB->get_records_sql($participantsQuery));

                    $totalLogin = 0;
                    foreach ($loginRecords as $logins) {
                        $totalLogin += $logins->cnt;
                    }
                    $participantCount = 0;
                    $avgLogins = 0;
                    if (!empty($participants) && $participants[0]->participants)
                        $participantCount = $participants[0]->participants;
                    if (!empty($participants) && $participantCount > 0)
                        $avgLogins = number_format(($totalLogin / $participants[0]->participants), 2, '.', '');

                    array_push($loginYValues, $totalLogin);
                    array_push($avgLoginYValues, $avgLogins);
                    array_push($courseValues, $currentCourse->coursename);
                }
                if ($plot == 'line_sharp') {
                    $chart = new \core\chart_line();
                } else if ($plot == 'line_smooth') {
                    $chart = new \core\chart_line();
                    $chart->set_smooth(true);

                } else if ($plot == 'pie') {
                    $chart = new \core\chart_pie();

                } else if ($plot == 'doughnut') {
                    $chart = new \core\chart_pie();
                    $chart->set_doughnut(true);
                } else if ($plot == 'bar') {
                    $chart = new \core\chart_bar();
                }


                if ($plot == 'line_sharp') {
                    $chart2 = new \core\chart_line();
                } else if ($plot == 'line_smooth') {
                    $chart2 = new \core\chart_line();
                    $chart2->set_smooth(true);

                } else if ($plot == 'pie') {
                    $chart2 = new \core\chart_pie();

                } else if ($plot == 'doughnut') {
                    $chart2 = new \core\chart_pie();
                    $chart2->set_doughnut(true);
                } else if ($plot == 'bar') {
                    $chart2 = new \core\chart_bar();
                }


                if ($plot !== 'pie' && $plot !== 'doughnut') {
                    $series = new \core\chart_series('تعداد ورود فراگیران به محیط یادگیری', $loginYValues);
                    $series2 = new \core\chart_series('میانگین ورود فراگیران به محیط یادگیری', $avgLoginYValues);
                    $chart->add_series($series);
                    $chart->add_series($series2);
                    $chart->set_labels($courseValues);
                    $chart->set_title(' تعداد ورود فراگیران به محیط یادگیری در تمام دوره ها');
                }
                else {
                    $series = new \core\chart_series('تعداد ورود فراگیران به محیط یادگیری', $loginYValues);
                    $chart->add_series($series);
                    $chart->set_labels($courseValues);
                    $chart->set_title(' تعداد ورود فراگیران به محیط یادگیری در تمام دوره ها');

                    $series2 = new \core\chart_series('میانگین ورود فراگیران به محیط یادگیری', $avgLoginYValues);
                    $chart2->add_series($series2);
                    $chart2->set_labels($courseValues);
                    $chart2->set_title(' میانگین تعداد ورود فراگیران به محیط یادگیری در تمام دوره ها');
                }
                if ($plot !== 'pie' && $plot !== 'doughnut') $chart->get_yaxis(0, true)->set_min(0);

                $tempText .= $OUTPUT->render($chart).'<br>';
                if ($plot === 'pie' || $plot === 'doughnut') $tempText .= $OUTPUT->render($chart2).'<br>';

            }  else if ($user === 'admin_all_user_self') {
                $roles = get_user_roles($context, $USER->id, true);
                $role = key($roles);
                $rolename = $roles[$role]->shortname;
                if ($rolename === 'manager') {
                    return $this->student_login_count('all', $plot);
                } else if ($rolename === 'editingteacher') {
                    return $this->student_login_count('user', $plot);
                }
            }
            $tempText .= "\t".PHP_EOL.'</div>'.'<br>';
        }

        return $tempText;

	}

}

?>