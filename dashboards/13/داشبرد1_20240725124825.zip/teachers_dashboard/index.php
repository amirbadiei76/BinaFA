<?php
/**
* @package     local_teachers_dashboard
* @author      Kristian
* @license     http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
* @var stdClass $plugin
*/

require_once (__DIR__.'/../../config.php');

global $PAGE, $OUTPUT, $USER, $DB, $CFG;


try {
	require_login();
} catch (coding_exception $e) {
} catch (require_login_exception $e) {
} catch (moodle_exception $e) {
}

try {
	$PAGE->requires->css('/local/teachers_dashboard/Styles/styles.css');
} catch (exception $e) {
}

$CFG->chart_colorset = ['#875692', '#f38400', '#a1caf1', '#f3c300', '#be0032', '#c2b280', '#7f180d', '#008856', '#e68fac', '#0067a5',
                '#f307fc', '#86671d', '#ecd17f', '#ea3946', '#b2607d', '#4ffa60', '#2b3f1e', '#f98ddb', '#44ac37', '#0d9a93', '#dfaaf9', '#811f65', '#faf17c', '#cbcb48', '#661be3', '#697373', '#92bcb9', '#bf7e77', '#0c8bfa', '#73e116', '#d636a2', '#3d69ca', '#1bf168', '#ac6abc', '#af5c25', '#e54b17', '#70dced', '#23baf8', '#93a74c', '#09b174', '#e04949', '#2acbca', '#0e511d', '#f283be', '#76484e', '#b826d3', '#ca18c8', '#a682c8', '#b8f6f1', '#b45d95', '#0fa18f', '#a8c13d', '#c33b55', '#b643d8', '#124559', '#8bd805', '#7b5e91', '#0395c0', '#3f829f', '#425757', '#4baddf', '#188776', '#f91303', '#79d6f9', '#4099f0', '#9125b8', '#fe631a', '#e72487', '#b1c6f9', '#98d89d', '#443cae', '#6dd5a4', '#854fd4', '#734b4a', '#f4a948', '#3e108f', '#3372fe', '#64bb2b', '#f25639', '#f6440f', '#dcff92', '#9f1250', '#739ff6', '#daaf98', '#d9850e', '#2dc1b6', '#f317ac', '#950c13', '#e82f7e', '#acb324', '#311f1f', '#8c0f39', '#1bef1a', '#cb745b', '#2b41a6', '#e2c656', '#9d3afc', '#e8be08', '#af170d', '#288c5a', '#79e97a'];

$url = $CFG->wwwroot.'/local/teachers_dashboard/index.php';
$PAGE->set_context(context_user::instance($USER->id));
$PAGE->set_url(new moodle_url($url));
$PAGE->set_title("پیشخوان تحلیل عملکرد مدرسان");
$PAGE->set_heading("پیشخوان تحلیل عملکرد مدرسان");

$result = '';


include_once 'classes\TeacherAnalytics.php';
include_once 'classes\StudentAnalytics.php';
include_once 'classes\CourseAnalytics.php';

$student = new StudentAnalytics();
$teacher = new TeacherAnalytics();
$course = new CourseAnalytics();

$result .= $student->student_main_info('user');
$result .= $student->student_active_students('user','table');
$result .= $student->student_login_count('user','table');
$result .= $teacher->teacher_activities('admin_all_user_self','bar','weekly');
$result .= $teacher->teacher_times_pent('admin_all_user_self','bar','weekly');
$result .= $teacher->teacher_average_times_pent('all','line_smooth','daily');
$result .= $course->course_student_participants('all');
$result .= $course->course_student_activity_to_view_percentage('all','pie','weekly');
$result .= $course->course_student_activity_percentage('all','pie','weekly');
$result .= $course->course_view_count('all','pie','daily');
$result .= $course->course_student_view_without_activity_rate('user','line_smooth','weekly');
$result .= $course->course_student_view_rate('all','bar','weekly');


echo $OUTPUT->header();
$allResults = (object) [
	'result' => $result,
];
echo $OUTPUT->render_from_template('local_teachers_dashboard/result', $allResults);
echo $OUTPUT->footer();


?>