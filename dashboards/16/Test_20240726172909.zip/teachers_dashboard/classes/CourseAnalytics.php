<?php
/**
* @package     local_teachers_dashboard
* @author      Kristian
* @license     http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
* @var stdClass $plugin
*/

class CourseAnalytics {

    public function course_student_avg_attempts_to_pass ($user, $plot): string {
        global $DB, $USER, $PAGE, $CFG, $OUTPUT;
        $uid = $USER->id;
        $username = $USER->username;
        $tempText = '';
        $context = context_system::instance();

        try {
            $PAGE->requires->css('/local/teachers_dashboard/Styles/styles.css');
        } catch (exception $e) {
        }

        if ($plot === 'table') {
            if ($user === 'user') {
                $userCourseQuery =
                    "SELECT DISTINCT cc.id AS cid, cc.fullname AS coursename
                    FROM {user} u
                    JOIN {user_enrolments} ue ON ue.userid = u.id
                    JOIN {enrol} e ON e.id = ue.enrolid
                    JOIN {context} c ON c.instanceid = e.courseid
                    JOIN {role_assignments} ra ON (ra.userid = u.id AND ra.contextid = c.id)
                    JOIN {role} r ON ra.roleid = r.id
                    JOIN {course} cc ON e.courseid = cc.id
                    WHERE u.id = {$uid} AND u.deleted = 0 AND cc.id IS NOT NULL AND (r.shortname = 'editingteacher')
                    GROUP BY cc.id";

                $userCourses = array_values($DB->get_records_sql($userCourseQuery));

                $tempText .= '<div id="div_class">'.PHP_EOL.
                    "\t".'<h3 class="main_title">میانگین تعداد تلاش ها برای قبولی در آزمون ها در دوره های '.$username.'</h3>'.PHP_EOL.
                    "\t".'<table class="data-table">'.PHP_EOL."\t\t".'<tr>'.PHP_EOL.
                    "\t\t".'<th>نام دوره</th>'.PHP_EOL."\t\t".'<th>نام آزمون</th>'.PHP_EOL."\t\t".'<th>تعداد شرکت کنندگان در آزمون</th>'.PHP_EOL."\t\t".'<th>مجموع تلاش ها برای قبولی</th>'.PHP_EOL."\t\t".'<th>تعداد مردود شده</th>'.PHP_EOL."\t\t".'<th>تعداد قبولی</th>'.PHP_EOL."\t\t".'<th>میانگین تعداد تلاش ها برای قبولی</th>'."\t\t".'</tr>';

                foreach ($userCourses as $currentCourse) {
                    $passedQuizAttemptsQuery =
                        "SELECT qa.id AS qaid, q.id as qid, c.fullname AS coursename, u.username as username, qa.attempt as attempts, q.name AS quiz, (q.sumgrades / 2) AS quiz_sum, ROUND(MAX(qa.sumgrades), 2) AS grade, COUNT(DISTINCT u.id) as attemptedUsers
                        FROM {quiz_attempts} qa
                        JOIN {quiz} q ON qa.quiz = q.id
                        JOIN {course} c ON q.course = c.id
                        JOIN {user} u ON u.id = qa.userid
                        JOIN {role_assignments} ra ON ra.userid = u.id
                        JOIN {role} r ON ra.roleid = r.id
                        WHERE u.deleted = 0 AND r.shortname = 'student' AND c.id = {$currentCourse->cid} AND qa.state = 'finished'
                        GROUP BY qa.id";
                    $passedQuizAttempts = array_values($DB->get_records_sql($passedQuizAttemptsQuery));

                    $quizGroupedArray = [];
                    foreach ($passedQuizAttempts as $attempts) {
                        $quizGroupedArray[$attempts->qid][] = $attempts;
                    }

                    foreach ($quizGroupedArray as $quiz => $results) {
                        $attemptsByUser = [];
                        $passedUsers = 0;
                        $allAttempsToPass = 0;
                        foreach ($results as $result) {
                            $attemptsByUser[$result->username][] = $result;
                        }
                        foreach ($attemptsByUser as $username => $userAttempt) {
                            $userAttemptCount = 0;
                            foreach ($userAttempt as $currentAttempt) {
                                $userAttemptCount += 1;

                                if ($currentAttempt->grade >= $currentAttempt->quiz_sum) {
                                    $passedUsers += 1;
                                    $allAttempsToPass += $userAttemptCount;
                                    break;
                                }
                            }
                        }
                        $usersCount = count($attemptsByUser);
                        $failedCount = $usersCount - $passedUsers;
                        $quizName = $DB->get_record('quiz', ['id'=>$quiz])->name;


                        if ($usersCount > 0) {
                            $tempText .= '<tr>';
                            $tempText .= '<td>'.$currentCourse->coursename.'</td>';
                            $tempText .= '<td>'.$quizName.'</td>';
                            $tempText .= '<td>'.$usersCount.'</td>';
                            $tempText .= '<td>'.$allAttempsToPass.'</td>';
                            $tempText .= '<td>'.$failedCount.'</td>';
                            $tempText .= '<td>'.$passedUsers.'</td>';

                            $attemptAvg = number_format(($allAttempsToPass / $passedUsers), 2, '.', '');
                            $tempText .= '<td>'.$attemptAvg.'</td>';
                            $tempText .= '</tr>';
                        }

                    }
                }
            } else if ($user === 'all') {
                $allCoursesQuery =
                    "SELECT DISTINCT cc.id AS cid, cc.fullname AS coursename
                    FROM {user} u
                    JOIN {user_enrolments} ue ON ue.userid = u.id
                    JOIN {enrol} e ON e.id = ue.enrolid
                    JOIN {context} c ON c.instanceid = e.courseid
                    JOIN {role_assignments} ra ON (ra.userid = u.id AND ra.contextid = c.id)
                    JOIN {role} r ON ra.roleid = r.id
                    JOIN {course} cc ON e.courseid = cc.id
                    WHERE u.deleted = 0 AND cc.id IS NOT NULL AND (r.shortname = 'editingteacher')
                    GROUP BY cc.id";

                $allCourses = array_values($DB->get_records_sql($allCoursesQuery));

                $tempText .= '<div id="div_class">'.PHP_EOL.
                    "\t".'<h3 class="main_title">میانگین تعداد تلاش ها برای قبولی در آزمون ها در تمام دوره ها </h3>'.PHP_EOL.
                    "\t".'<table class="data-table">'.PHP_EOL."\t\t".'<tr>'.PHP_EOL.
                    "\t\t".'<th>نام دوره</th>'.PHP_EOL."\t\t".'<th>نام آزمون</th>'.PHP_EOL."\t\t".'<th>تعداد شرکت کنندگان در آزمون</th>'.PHP_EOL."\t\t".'<th>مجموع تلاش ها برای قبولی</th>'.PHP_EOL."\t\t".'<th>تعداد مردود شده</th>'.PHP_EOL."\t\t".'<th>تعداد قبولی</th>'.PHP_EOL."\t\t".'<th>میانگین تعداد تلاش ها برای قبولی</th>'."\t\t".'</tr>';

                foreach ($allCourses as $currentCourse) {
                    $passedQuizAttemptsQuery =
                        "SELECT qa.id AS qaid, q.id as qid, c.fullname AS coursename, u.username as username, qa.attempt as attempts, q.name AS quiz, (q.sumgrades / 2) AS quiz_sum, ROUND(MAX(qa.sumgrades), 2) AS grade, COUNT(DISTINCT u.id) as attemptedUsers
                        FROM {quiz_attempts} qa
                        JOIN {quiz} q ON qa.quiz = q.id
                        JOIN {course} c ON q.course = c.id
                        JOIN {user} u ON u.id = qa.userid
                        JOIN {role_assignments} ra ON ra.userid = u.id
                        JOIN {role} r ON ra.roleid = r.id
                        WHERE u.deleted = 0 AND r.shortname = 'student' AND c.id = {$currentCourse->cid} AND qa.state = 'finished'
                        GROUP BY qa.id";
                    $passedQuizAttempts = array_values($DB->get_records_sql($passedQuizAttemptsQuery));

                    $quizGroupedArray = [];
                    foreach ($passedQuizAttempts as $attempts) {
                        $quizGroupedArray[$attempts->qid][] = $attempts;
                    }

                    foreach ($quizGroupedArray as $quiz => $results) {
                        $attemptsByUser = [];
                        $passedUsers = 0;
                        $allAttempsToPass = 0;
                        foreach ($results as $result) {
                            $attemptsByUser[$result->username][] = $result;
                        }
                        foreach ($attemptsByUser as $username => $userAttempt) {
                            $userAttemptCount = 0;
                            foreach ($userAttempt as $currentAttempt) {
                                $userAttemptCount += 1;

                                if ($currentAttempt->grade >= $currentAttempt->quiz_sum) {
                                    $passedUsers += 1;
                                    $allAttempsToPass += $userAttemptCount;
                                    break;
                                }
                            }
                        }
                        $usersCount = count($attemptsByUser);
                        $failedCount = $usersCount - $passedUsers;
                        $quizName = $DB->get_record('quiz', ['id'=>$quiz])->name;


                        if ($usersCount > 0) {
                            $tempText .= '<tr>';
                            $tempText .= '<td>'.$currentCourse->coursename.'</td>';
                            $tempText .= '<td>'.$quizName.'</td>';
                            $tempText .= '<td>'.$usersCount.'</td>';
                            $tempText .= '<td>'.$allAttempsToPass.'</td>';
                            $tempText .= '<td>'.$failedCount.'</td>';
                            $tempText .= '<td>'.$passedUsers.'</td>';

                            $attemptAvg = number_format(($allAttempsToPass / $passedUsers), 2, '.', '');
                            $tempText .= '<td>'.$attemptAvg.'</td>';
                            $tempText .= '</tr>';
                        }

                    }

                }
            }  else if ($user === 'admin_all_user_self') {
                $roles = get_user_roles($context, $USER->id, true);
                $role = key($roles);
                $rolename = $roles[$role]->shortname;
                if ($rolename === 'manager') {
                    return $this->course_student_avg_attempts_to_pass('all', $plot);
                } else if ($rolename === 'editingteacher') {
                    return $this->course_student_avg_attempts_to_pass('user', $plot);
                }
            }

            $tempText .= "\t".'</table>'.PHP_EOL.'</div>'.'<br>';
        } else {
            // is chart
            if ($user === 'user') {
                $userCourseQuery =
                    "SELECT DISTINCT cc.id AS cid, cc.fullname AS coursename
                    FROM {user} u
                    JOIN {user_enrolments} ue ON ue.userid = u.id
                    JOIN {enrol} e ON e.id = ue.enrolid
                    JOIN {context} c ON c.instanceid = e.courseid
                    JOIN {role_assignments} ra ON (ra.userid = u.id AND ra.contextid = c.id)
                    JOIN {role} r ON ra.roleid = r.id
                    JOIN {course} cc ON e.courseid = cc.id
                    WHERE u.id = {$uid} AND u.deleted = 0 AND cc.id IS NOT NULL AND (r.shortname = 'editingteacher')
                    GROUP BY cc.id";

                $userCourses = array_values($DB->get_records_sql($userCourseQuery));
                $tempText .= '<div id="div_class">'.PHP_EOL.
                    "\t".'<h3 class="main_title">میانگین تعداد تلاش ها برای قبولی در آزمون ها در دوره های '.$username.'</h3>'.PHP_EOL;

                foreach ($userCourses as $currentCourse) {
                    $passedQuizAttemptsQuery =
                        "SELECT qa.id AS qaid, q.id as qid, c.fullname AS coursename, u.username as username, qa.attempt as attempts, q.name AS quiz, (q.sumgrades / 2) AS quiz_sum, ROUND(MAX(qa.sumgrades), 2) AS grade, COUNT(DISTINCT u.id) as attemptedUsers
                        FROM {quiz_attempts} qa
                        JOIN {quiz} q ON qa.quiz = q.id
                        JOIN {course} c ON q.course = c.id
                        JOIN {user} u ON u.id = qa.userid
                        JOIN {role_assignments} ra ON ra.userid = u.id
                        JOIN {role} r ON ra.roleid = r.id
                        WHERE u.deleted = 0 AND r.shortname = 'student' AND c.id = {$currentCourse->cid} AND qa.state = 'finished'
                        GROUP BY qa.id";
                    $passedQuizAttempts = array_values($DB->get_records_sql($passedQuizAttemptsQuery));

                    $quizGroupedArray = [];
                    foreach ($passedQuizAttempts as $attempts) {
                        $quizGroupedArray[$attempts->qid][] = $attempts;
                    }
                    $groupX = [];
                    $groupY = [];
                    foreach ($quizGroupedArray as $quiz => $results) {
                        $attemptsByUser = [];
                        $passedUsers = 0;
                        $allAttempsToPass = 0;
                        foreach ($results as $result) {
                            $attemptsByUser[$result->username][] = $result;
                        }
                        foreach ($attemptsByUser as $username => $userAttempt) {
                            $userAttemptCount = 0;
                            foreach ($userAttempt as $currentAttempt) {
                                $userAttemptCount += 1;

                                if ($currentAttempt->grade >= $currentAttempt->quiz_sum) {
                                    $passedUsers += 1;
                                    $allAttempsToPass += $userAttemptCount;
                                    break;
                                }
                            }
                        }
                        $usersCount = count($attemptsByUser);
                        $failedCount = $usersCount - $passedUsers;
                        $quizName = $DB->get_record('quiz', ['id'=>$quiz])->name;



                        if ($usersCount > 0) {
                            $attemptAvg = number_format(($allAttempsToPass / $passedUsers), 2, '.', '');

                            array_push($groupY, $attemptAvg);
                            array_push($groupX, $quizName.' با '.$passedUsers.' نفر قبولی و '.$usersCount.' نفر شرکت کننده');
                        }
                    }

                    if ($plot == 'line_sharp') {
                        $chart = new \core\chart_line();
                    } else if ($plot == 'line_smooth') {
                        $chart = new \core\chart_line();
                        $chart->set_smooth(true);

                    } else if ($plot == 'pie') {
                        $chart = new \core\chart_pie();

                    } else if ($plot == 'doughnut') {
                        $chart = new \core\chart_pie();
                        $chart->set_doughnut(true);
                    } else if ($plot == 'bar') {
                        $chart = new \core\chart_bar();
                    }

                    if (count($groupY) > 0) {
                        $series = new \core\chart_series($currentCourse->coursename, $groupY);
                        $chart->add_series($series);
                        $chart->set_labels($groupX);
                        $chart->set_title(' میانگین تعداد تلاش ها در دوره '.$currentCourse->coursename);
                        if ($plot !== 'pie' && $plot !== 'doughnut') $chart->get_yaxis(0, true)->set_min(0);

                        $tempText .= $OUTPUT->render($chart).'<br>';
                    } else {
                        $tempText .= '<h3>میانگین تعداد تلاش ها برای دوره '.$currentCourse->coursename.' وجود ندارد.</h3><br>';
                    }
                }
            } else if ($user === 'all') {
                $userCourseQuery =
                    "SELECT DISTINCT cc.id AS cid, cc.fullname AS coursename
                    FROM {user} u
                    JOIN {user_enrolments} ue ON ue.userid = u.id
                    JOIN {enrol} e ON e.id = ue.enrolid
                    JOIN {context} c ON c.instanceid = e.courseid
                    JOIN {role_assignments} ra ON (ra.userid = u.id AND ra.contextid = c.id)
                    JOIN {role} r ON ra.roleid = r.id
                    JOIN {course} cc ON e.courseid = cc.id
                    WHERE u.deleted = 0 AND cc.id IS NOT NULL AND (r.shortname = 'editingteacher')
                    GROUP BY cc.id";

                $userCourses = array_values($DB->get_records_sql($userCourseQuery));
                $tempText .= '<div id="div_class">'.PHP_EOL.
                    "\t".'<h3 class="main_title">میانگین تعداد تلاش ها برای قبولی در تمام دوره ها </h3>'.PHP_EOL;

                foreach ($userCourses as $currentCourse) {
                    $passedQuizAttemptsQuery =
                        "SELECT qa.id AS qaid, q.id as qid, c.fullname AS coursename, u.username as username, qa.attempt as attempts, q.name AS quiz, (q.sumgrades / 2) AS quiz_sum, ROUND(MAX(qa.sumgrades), 2) AS grade, COUNT(DISTINCT u.id) as attemptedUsers
                        FROM {quiz_attempts} qa
                        JOIN {quiz} q ON qa.quiz = q.id
                        JOIN {course} c ON q.course = c.id
                        JOIN {user} u ON u.id = qa.userid
                        JOIN {role_assignments} ra ON ra.userid = u.id
                        JOIN {role} r ON ra.roleid = r.id
                        WHERE u.deleted = 0 AND r.shortname = 'student' AND c.id = {$currentCourse->cid} AND qa.state = 'finished'
                        GROUP BY qa.id";
                    $passedQuizAttempts = array_values($DB->get_records_sql($passedQuizAttemptsQuery));

                    $quizGroupedArray = [];
                    foreach ($passedQuizAttempts as $attempts) {
                        $quizGroupedArray[$attempts->qid][] = $attempts;
                    }
                    $groupX = [];
                    $groupY = [];
                    foreach ($quizGroupedArray as $quiz => $results) {
                        $attemptsByUser = [];
                        $passedUsers = 0;
                        $allAttempsToPass = 0;
                        foreach ($results as $result) {
                            $attemptsByUser[$result->username][] = $result;
                        }
                        foreach ($attemptsByUser as $username => $userAttempt) {
                            $userAttemptCount = 0;
                            foreach ($userAttempt as $currentAttempt) {
                                $userAttemptCount += 1;

                                if ($currentAttempt->grade >= $currentAttempt->quiz_sum) {
                                    $passedUsers += 1;
                                    $allAttempsToPass += $userAttemptCount;
                                    break;
                                }
                            }
                        }
                        $usersCount = count($attemptsByUser);
                        $failedCount = $usersCount - $passedUsers;
                        $quizName = $DB->get_record('quiz', ['id'=>$quiz])->name;



                        if ($usersCount > 0) {
                            $attemptAvg = number_format(($allAttempsToPass / $passedUsers), 2, '.', '');

                            array_push($groupY, $attemptAvg);
                            array_push($groupX, $quizName.' با '.$passedUsers.' نفر قبولی و '.$usersCount.' نفر شرکت کننده');
                        }
                    }

                    if ($plot == 'line_sharp') {
                        $chart = new \core\chart_line();
                    } else if ($plot == 'line_smooth') {
                        $chart = new \core\chart_line();
                        $chart->set_smooth(true);

                    } else if ($plot == 'pie') {
                        $chart = new \core\chart_pie();

                    } else if ($plot == 'doughnut') {
                        $chart = new \core\chart_pie();
                        $chart->set_doughnut(true);
                    } else if ($plot == 'bar') {
                        $chart = new \core\chart_bar();
                    }

                    if (count($groupY) > 0) {
                        $series = new \core\chart_series($currentCourse->coursename, $groupY);
                        $chart->add_series($series);
                        $chart->set_labels($groupX);
                        $chart->set_title(' میانگین تعداد تلاش ها در دوره '.$currentCourse->coursename);
                        if ($plot !== 'pie' && $plot !== 'doughnut') $chart->get_yaxis(0, true)->set_min(0);

                        $tempText .= $OUTPUT->render($chart).'<br>';
                    } else {
                        $tempText .= '<h3>میانگین تعداد تلاش ها برای دوره '.$currentCourse->coursename.' وجود ندارد.</h3><br>';
                    }
                }
            }  else if ($user === 'admin_all_user_self') {
                $roles = get_user_roles($context, $USER->id, true);
                $role = key($roles);
                $rolename = $roles[$role]->shortname;
                if ($rolename === 'manager') {
                    return $this->course_student_avg_attempts_to_pass('all', $plot);
                } else if ($rolename === 'editingteacher') {
                    return $this->course_student_avg_attempts_to_pass('user', $plot);
                }
            }
            $tempText .= "\t".PHP_EOL.'</div>'.'<br>';
        }

        return $tempText;

	}
    public function course_student_passed_percentage_first_attempt ($user, $plot): string {
        global $DB, $USER, $PAGE, $CFG, $OUTPUT;
        $uid = $USER->id;
        $username = $USER->username;
        $tempText = '';
        $context = context_system::instance();

        try {
            $PAGE->requires->css('/local/teachers_dashboard/Styles/styles.css');
        } catch (exception $e) {
        }

        if ($plot === 'table') {
            if ($user === 'user') {
                $userCourseQuery =
                    "SELECT DISTINCT cc.id AS cid, cc.fullname AS coursename
                    FROM {user} u
                    JOIN {user_enrolments} ue ON ue.userid = u.id
                    JOIN {enrol} e ON e.id = ue.enrolid
                    JOIN {context} c ON c.instanceid = e.courseid
                    JOIN {role_assignments} ra ON (ra.userid = u.id AND ra.contextid = c.id)
                    JOIN {role} r ON ra.roleid = r.id
                    JOIN {course} cc ON e.courseid = cc.id
                    WHERE u.id = {$uid} AND u.deleted = 0 AND cc.id IS NOT NULL AND (r.shortname = 'editingteacher')
                    GROUP BY cc.id";

                $userCourses = array_values($DB->get_records_sql($userCourseQuery));

                $tempText .= '<div id="div_class">'.PHP_EOL.
                    "\t".'<h3 class="main_title">نسبت فراگیرانی که در اولین تلاش، در آزمون قبول شدند به تمام فراگیرانی که در آزمون شرکت کردند (درصد اتمام آزمون) در دوره های '.$username.'</h3>'.PHP_EOL.
                    "\t".'<table class="data-table">'.PHP_EOL."\t\t".'<tr>'.PHP_EOL.
                    "\t\t".'<th>نام دوره</th>'.PHP_EOL."\t\t".'<th>نام آزمون</th>'.PHP_EOL."\t\t".'<th>تعداد شرکت کنندگان</th>'.PHP_EOL."\t\t".'<th>تعداد قبولی در اولین تلاش</th>'.PHP_EOL."\t\t".'<th>درصد اتمام آزمون</th>'."\t\t".'</tr>';

                foreach ($userCourses as $currentCourse) {
                    $passedQuizFirstAttemptQuery =
                        "SELECT qa.id AS qaid, q.id as qid, c.fullname AS coursename, u.username as username, qa.attempt as attempts, q.name AS quiz, (q.sumgrades / 2) AS quiz_sum, ROUND(MAX(qa.sumgrades), 2) AS grade, COUNT(DISTINCT u.id) as attemptedUsers
                        FROM {quiz_attempts} qa
                        JOIN {quiz} q ON qa.quiz = q.id
                        JOIN {course} c ON q.course = c.id
                        JOIN {user} u ON u.id = qa.userid
                        JOIN {role_assignments} ra ON ra.userid = u.id
                        JOIN {role} r ON ra.roleid = r.id
                        WHERE u.deleted = 0 AND r.shortname = 'student' AND c.id = {$currentCourse->cid} AND qa.state = 'finished'
                        GROUP BY qa.id";
                    $passedQuizFirstAttempt = array_values($DB->get_records_sql($passedQuizFirstAttemptQuery));



                    $quizGroupedArray = [];
                    foreach ($passedQuizFirstAttempt as $attempts) {
                        $quizGroupedArray[$attempts->qid][] = $attempts;
                    }

                    foreach ($quizGroupedArray as $quiz => $results) {
                        $passedUsers = 0;
                        $attemptsByUser = [];
                        foreach ($results as $result) {
                            $attemptsByUser[$result->username][] = $result;
                        }

                        $allAttempted = count($attemptsByUser);
                        foreach ($attemptsByUser as $user =>$attempt) {
                            if (count($attempt) === 1 && $attempt[0]->grade >= $attempt[0]->quiz_sum) {
                                $passedUsers += 1;
                            }
                        }
                        $quizName = $DB->get_record('quiz', ['id'=>$quiz])->name;

                        if ($allAttempted > 0) {
                            $tempText .= '<tr>';
                            $tempText .= '<td>'.$currentCourse->coursename.'</td>';
                            $tempText .= '<td>'.$quizName.'</td>';
                            $tempText .= '<td>'.$allAttempted.'</td>';
                            $tempText .= '<td>'.$passedUsers.'</td>';

                            $attemptPercent = number_format((($passedUsers * 100) / $allAttempted), 2, '.', '');
                            $tempText .= '<td>'.$attemptPercent.'%</td>';
                            $tempText .= '</tr>';
                        }
                    }
                }
            } else if ($user === 'all') {
                $allCoursesQuery =
                    "SELECT DISTINCT cc.id AS cid, cc.fullname AS coursename
                    FROM {user} u
                    JOIN {user_enrolments} ue ON ue.userid = u.id
                    JOIN {enrol} e ON e.id = ue.enrolid
                    JOIN {context} c ON c.instanceid = e.courseid
                    JOIN {role_assignments} ra ON (ra.userid = u.id AND ra.contextid = c.id)
                    JOIN {role} r ON ra.roleid = r.id
                    JOIN {course} cc ON e.courseid = cc.id
                    WHERE u.deleted = 0 AND cc.id IS NOT NULL AND (r.shortname = 'editingteacher')
                    GROUP BY cc.id";

                $allCourses = array_values($DB->get_records_sql($allCoursesQuery));

                $tempText .= '<div id="div_class">'.PHP_EOL.
                    "\t".'<h3 class="main_title">نسبت فراگیرانی که در اولین تلاش، در آزمون قبول شدند به تمام فراگیرانی که در آزمون شرکت کردند (درصد اتمام آزمون) در تمام دوره ها</h3>'.PHP_EOL.
                    "\t".'<table class="data-table">'.PHP_EOL."\t\t".'<tr>'.PHP_EOL.
                    "\t\t".'<th>نام دوره</th>'.PHP_EOL."\t\t".'<th>نام آزمون</th>'.PHP_EOL."\t\t".'<th>تعداد شرکت کنندگان</th>'.PHP_EOL."\t\t".'<th>تعداد قبولی در اولین تلاش</th>'.PHP_EOL."\t\t".'<th>درصد اتمام آزمون</th>'."\t\t".'</tr>';


                foreach ($allCourses as $currentCourse) {
                    $passedQuizFirstAttemptQuery =
                        "SELECT qa.id AS qaid, q.id as qid, c.fullname AS coursename, u.username as username, qa.attempt as attempts, q.name AS quiz, (q.sumgrades / 2) AS quiz_sum, ROUND(MAX(qa.sumgrades), 2) AS grade, COUNT(DISTINCT u.id) as attemptedUsers
                        FROM {quiz_attempts} qa
                        JOIN {quiz} q ON qa.quiz = q.id
                        JOIN {course} c ON q.course = c.id
                        JOIN {user} u ON u.id = qa.userid
                        JOIN {role_assignments} ra ON ra.userid = u.id
                        JOIN {role} r ON ra.roleid = r.id
                        WHERE u.deleted = 0 AND r.shortname = 'student' AND c.id = {$currentCourse->cid} AND qa.state = 'finished'
                        GROUP BY qa.id";
                    $passedQuizFirstAttempt = array_values($DB->get_records_sql($passedQuizFirstAttemptQuery));


                    $quizGroupedArray = [];
                    foreach ($passedQuizFirstAttempt as $attempts) {
                        $quizGroupedArray[$attempts->qid][] = $attempts;
                    }

                    foreach ($quizGroupedArray as $quiz => $results) {
                        $passedUsers = 0;
                        $attemptsByUser = [];
                        foreach ($results as $result) {
                            $attemptsByUser[$result->username][] = $result;
                        }

                        $allAttempted = count($attemptsByUser);
                        foreach ($attemptsByUser as $user =>$attempt) {
                            if (count($attempt) === 1 && $attempt[0]->grade >= $attempt[0]->quiz_sum) {
                                $passedUsers += 1;
                            }
                        }
                        $quizName = $DB->get_record('quiz', ['id'=>$quiz])->name;

                        if ($allAttempted > 0) {
                            $tempText .= '<tr>';
                            $tempText .= '<td>'.$currentCourse->coursename.'</td>';
                            $tempText .= '<td>'.$quizName.'</td>';
                            $tempText .= '<td>'.$allAttempted.'</td>';
                            $tempText .= '<td>'.$passedUsers.'</td>';

                            $attemptPercent = number_format((($passedUsers * 100) / $allAttempted), 2, '.', '');
                            $tempText .= '<td>'.$attemptPercent.'%</td>';
                            $tempText .= '</tr>';
                        }
                    }
                }
            }  else if ($user === 'admin_all_user_self') {
                $roles = get_user_roles($context, $USER->id, true);
                $role = key($roles);
                $rolename = $roles[$role]->shortname;
                if ($rolename === 'manager') {
                    return $this->course_student_passed_percentage_first_attempt('all', $plot);
                } else if ($rolename === 'editingteacher') {
                    return $this->course_student_passed_percentage_first_attempt('user', $plot);
                }
            }

            $tempText .= "\t".'</table>'.PHP_EOL.'</div>'.'<br>';
        } else {
            // is chart

            if ($user === 'user') {
                $userCourseQuery =
                    "SELECT DISTINCT cc.id AS cid, cc.fullname AS coursename
                    FROM {user} u
                    JOIN {user_enrolments} ue ON ue.userid = u.id
                    JOIN {enrol} e ON e.id = ue.enrolid
                    JOIN {context} c ON c.instanceid = e.courseid
                    JOIN {role_assignments} ra ON (ra.userid = u.id AND ra.contextid = c.id)
                    JOIN {role} r ON ra.roleid = r.id
                    JOIN {course} cc ON e.courseid = cc.id
                    WHERE u.id = {$uid} AND u.deleted = 0 AND cc.id IS NOT NULL AND (r.shortname = 'editingteacher')
                    GROUP BY cc.id";

                $userCourses = array_values($DB->get_records_sql($userCourseQuery));
                $tempText .= '<div id="div_class">'.PHP_EOL.
                    "\t".'<h3 class="main_title">نسبت فراگیرانی که در اولین تلاش، در آزمون قبول شدند به تمام فراگیرانی که در آزمون شرکت کردند (درصد اتمام آزمون) در دوره های '.$username.'</h3>'.PHP_EOL;

                foreach ($userCourses as $currentCourse) {
                    $passedQuizFirstAttemptQuery =
                        "SELECT qa.id AS qaid, q.id as qid, c.fullname AS coursename, u.username as username, qa.attempt as attempts, q.name AS quiz, (q.sumgrades / 2) AS quiz_sum, ROUND(MAX(qa.sumgrades), 2) AS grade, COUNT(DISTINCT u.id) as attemptedUsers
                        FROM {quiz_attempts} qa
                        JOIN {quiz} q ON qa.quiz = q.id
                        JOIN {course} c ON q.course = c.id
                        JOIN {user} u ON u.id = qa.userid
                        JOIN {role_assignments} ra ON ra.userid = u.id
                        JOIN {role} r ON ra.roleid = r.id
                        WHERE u.deleted = 0 AND r.shortname = 'student' AND c.id = {$currentCourse->cid} AND qa.state = 'finished'
                        GROUP BY qa.id";
                    $passedQuizFirstAttempt = array_values($DB->get_records_sql($passedQuizFirstAttemptQuery));


                    $quizGroupedArray = [];
                    foreach ($passedQuizFirstAttempt as $attempts) {
                        $quizGroupedArray[$attempts->qid][] = $attempts;
                    }

                    $groupX = [];
                    $groupY = [];
                    foreach ($quizGroupedArray as $quiz => $results) {
                        $passedUsers = 0;
                        $attemptsByUser = [];
                        foreach ($results as $result) {
                            $attemptsByUser[$result->username][] = $result;
                        }

                        $allAttempted = count($attemptsByUser);
                        foreach ($attemptsByUser as $user =>$attempt) {
                            if (count($attempt) === 1 && $attempt[0]->grade >= $attempt[0]->quiz_sum) {
                                $passedUsers += 1;
                            }
                        }
                        $quizName = $DB->get_record('quiz', ['id'=>$quiz])->name;

                        if ($allAttempted > 0) {
                            $attemptPercent = number_format((($passedUsers * 100) / $allAttempted), 2, '.', '');
                            array_push($groupX, $quizName);
                            array_push($groupY, $attemptPercent);
                        }
                    }

                    if ($plot == 'line_sharp') {
                        $chart = new \core\chart_line();
                    } else if ($plot == 'line_smooth') {
                        $chart = new \core\chart_line();
                        $chart->set_smooth(true);

                    } else if ($plot == 'pie') {
                        $chart = new \core\chart_pie();

                    } else if ($plot == 'doughnut') {
                        $chart = new \core\chart_pie();
                        $chart->set_doughnut(true);
                    } else if ($plot == 'bar') {
                        $chart = new \core\chart_bar();
                    }

                    if (count($groupY) > 0) {
                        $series = new \core\chart_series($currentCourse->coursename, $groupY);
                        $chart->add_series($series);
                        $chart->set_labels($groupX);
                        $chart->set_title(' درصد اتمام آزمون در دوره '.$currentCourse->coursename);
                        if ($plot !== 'pie' && $plot !== 'doughnut') $chart->get_yaxis(0, true)->set_min(0);

                        $tempText .= $OUTPUT->render($chart).'<br>';
                    } else {
                        $tempText .= '<h3>درصد اتمام آزمون برای دوره '.$currentCourse->coursename.' وجود ندارد.</h3><br>';
                    }
                }
            } else if ($user === 'all') {
                $userCourseQuery =
                    "SELECT DISTINCT cc.id AS cid, cc.fullname AS coursename
                    FROM {user} u
                    JOIN {user_enrolments} ue ON ue.userid = u.id
                    JOIN {enrol} e ON e.id = ue.enrolid
                    JOIN {context} c ON c.instanceid = e.courseid
                    JOIN {role_assignments} ra ON (ra.userid = u.id AND ra.contextid = c.id)
                    JOIN {role} r ON ra.roleid = r.id
                    JOIN {course} cc ON e.courseid = cc.id
                    WHERE u.deleted = 0 AND cc.id IS NOT NULL AND (r.shortname = 'editingteacher')
                    GROUP BY cc.id";

                $userCourses = array_values($DB->get_records_sql($userCourseQuery));
                $tempText .= '<div id="div_class">'.PHP_EOL.
                    "\t".'<h3 class="main_title">نسبت فراگیرانی که در اولین تلاش، در آزمون قبول شدند به تمام فراگیرانی که در آزمون شرکت کردند (درصد اتمام آزمون) در تمام دوره ها</h3>'.PHP_EOL;

                foreach ($userCourses as $currentCourse) {
                    $passedQuizFirstAttemptQuery =
                        "SELECT qa.id AS qaid, q.id as qid, c.fullname AS coursename, u.username as username, qa.attempt as attempts, q.name AS quiz, (q.sumgrades / 2) AS quiz_sum, ROUND(MAX(qa.sumgrades), 2) AS grade, COUNT(DISTINCT u.id) as attemptedUsers
                        FROM {quiz_attempts} qa
                        JOIN {quiz} q ON qa.quiz = q.id
                        JOIN {course} c ON q.course = c.id
                        JOIN {user} u ON u.id = qa.userid
                        JOIN {role_assignments} ra ON ra.userid = u.id
                        JOIN {role} r ON ra.roleid = r.id
                        WHERE u.deleted = 0 AND r.shortname = 'student' AND c.id = {$currentCourse->cid} AND qa.state = 'finished'
                        GROUP BY qa.id";
                    $passedQuizFirstAttempt = array_values($DB->get_records_sql($passedQuizFirstAttemptQuery));


                    $quizGroupedArray = [];
                    foreach ($passedQuizFirstAttempt as $attempts) {
                        $quizGroupedArray[$attempts->qid][] = $attempts;
                    }

                    $groupX = [];
                    $groupY = [];
                    foreach ($quizGroupedArray as $quiz => $results) {
                        $passedUsers = 0;
                        $attemptsByUser = [];
                        foreach ($results as $result) {
                            $attemptsByUser[$result->username][] = $result;
                        }

                        $allAttempted = count($attemptsByUser);
                        foreach ($attemptsByUser as $user =>$attempt) {
                            if (count($attempt) === 1 && $attempt[0]->grade >= $attempt[0]->quiz_sum) {
                                $passedUsers += 1;
                            }
                        }
                        $quizName = $DB->get_record('quiz', ['id'=>$quiz])->name;

                        if ($allAttempted > 0) {
                            $attemptPercent = number_format((($passedUsers * 100) / $allAttempted), 2, '.', '');
                            array_push($groupX, $quizName);
                            array_push($groupY, $attemptPercent);
                        }
                    }

                    if ($plot == 'line_sharp') {
                        $chart = new \core\chart_line();
                    } else if ($plot == 'line_smooth') {
                        $chart = new \core\chart_line();
                        $chart->set_smooth(true);

                    } else if ($plot == 'pie') {
                        $chart = new \core\chart_pie();

                    } else if ($plot == 'doughnut') {
                        $chart = new \core\chart_pie();
                        $chart->set_doughnut(true);
                    } else if ($plot == 'bar') {
                        $chart = new \core\chart_bar();
                    }

                    if (count($groupY) > 0) {
                        $series = new \core\chart_series($currentCourse->coursename, $groupY);
                        $chart->add_series($series);
                        $chart->set_labels($groupX);
                        $chart->set_title(' درصد اتمام آزمون در دوره '.$currentCourse->coursename);
                        if ($plot !== 'pie' && $plot !== 'doughnut') $chart->get_yaxis(0, true)->set_min(0);

                        $tempText .= $OUTPUT->render($chart).'<br>';
                    } else {
                        $tempText .= '<h3>درصد اتمام آزمون برای دوره '.$currentCourse->coursename.' وجود ندارد.</h3><br>';
                    }
                }
            }  else if ($user === 'admin_all_user_self') {
                $roles = get_user_roles($context, $USER->id, true);
                $role = key($roles);
                $rolename = $roles[$role]->shortname;
                if ($rolename === 'manager') {
                    return $this->course_student_passed_percentage_first_attempt('all', $plot);
                } else if ($rolename === 'editingteacher') {
                    return $this->course_student_passed_percentage_first_attempt('user', $plot);
                }
            }
            $tempText .= "\t".PHP_EOL.'</div>'.'<br>';
        }

        return $tempText;

	}
    public function course_student_participants ($user): string {
        global $DB, $USER, $PAGE, $CFG, $OUTPUT;
        $uid = $USER->id;
        $username = $USER->username;
        $tempText = '';
        $context = context_system::instance();

        try {
            $PAGE->requires->css('/local/teachers_dashboard/Styles/styles.css');
        } catch (exception $e) {
        }

        if ($user === 'user') {
            // get courses that user is the teacher
            $userCoursesQuery =
                "SELECT DISTINCT cc.id AS cid, cc.fullname AS coursename
            FROM {user} u
            JOIN {user_enrolments} ue ON ue.userid = u.id
            JOIN {enrol} e ON e.id = ue.enrolid
            JOIN {context} c ON c.instanceid = e.courseid
            JOIN {role_assignments} ra ON (ra.userid = u.id AND ra.contextid = c.id)
            JOIN {role} r ON ra.roleid = r.id
            JOIN {course} cc ON e.courseid = cc.id
            WHERE u.id = {$uid} AND u.deleted = 0 AND cc.id IS NOT NULL AND (r.shortname = 'editingteacher')
            GROUP BY cc.id";

            $userCourses = array_values($DB->get_records_sql($userCoursesQuery));

            $tempText .= '<div id="div_class">'.PHP_EOL.
                "\t".'<h3 class="main_title">تعداد فراگیران در دوره های '.$username.'</h3>'.PHP_EOL.
                "\t".'<table class="data-table">'.PHP_EOL."\t\t".'<tr>'.PHP_EOL.
                "\t\t".'<th>نام دوره</th>'.PHP_EOL."\t\t".'<th>تعداد فراگیران</th>'."\t\t".'</tr>';

            foreach ($userCourses as $currentCourse) {
                $courseParticipantQuery =
                        "SELECT c.id as cid, c.fullname as coursename, COUNT(DISTINCT ue.userid) as participant
                        FROM {user} u
                        JOIN {user_enrolments} ue ON ue.userid = u.id
                        JOIN {enrol} e ON e.id = ue.enrolid
                        JOIN {course} c ON e.courseid = c.id
                        JOIN {role_assignments} ra ON ra.userid = u.id
                        JOIN {role} r ON ra.roleid = r.id
                        WHERE r.shortname = 'student' AND c.id = {$currentCourse->cid}
                        GROUP BY c.id";

                $courseParticipant = array_values($DB->get_records_sql($courseParticipantQuery));

                foreach ($courseParticipant as $participants) {
                    $tempText .= '<tr>';
                    $tempText .= '<td>'.$participants->coursename.'</td>';
                    $tempText .= '<td>'.$participants->participant.'</td>';
                    $tempText .= '</tr>';
                }
            }
        } else if ($user === 'all') {
            $tempText .= '<div id="div_class">'.PHP_EOL.
                "\t".'<h3 class="main_title">تعداد فراگیران در تمام دوره ها</h3>'.PHP_EOL.
                "\t".'<table class="data-table">'.PHP_EOL."\t\t".'<tr>'.PHP_EOL.
                "\t\t".'<th>نام دوره</th>'.PHP_EOL."\t\t".'<th>تعداد فراگیران</th>'."\t\t".'</tr>';

            $courseParticipantQuery =
            "SELECT c.id as cid, c.fullname as coursename, COUNT(DISTINCT ue.userid) as participant
            FROM {user} u
            JOIN {user_enrolments} ue ON ue.userid = u.id
            JOIN {enrol} e ON e.id = ue.enrolid
            JOIN {course} c ON e.courseid = c.id
            JOIN {role_assignments} ra ON ra.userid = u.id
            JOIN {role} r ON ra.roleid = r.id
            WHERE r.shortname = 'student'
            GROUP BY c.id";

            $courseParticipant = array_values($DB->get_records_sql($courseParticipantQuery));

            foreach ($courseParticipant as $participants) {
                $tempText .= '<tr>';
                $tempText .= '<td>'.$participants->coursename.'</td>';
                $tempText .= '<td>'.$participants->participant.'</td>';
                $tempText .= '</tr>';
            }
        } else if ($user === 'admin_all_user_self') {
            $roles = get_user_roles($context, $USER->id, true);
            $role = key($roles);
            $rolename = $roles[$role]->shortname;
            if ($rolename === 'manager') {
                return $this->course_student_participants('all');
            } else if ($rolename === 'editingteacher') {
                return $this->course_student_participants('user');
            }
        }
        $tempText .= "\t".'</table>'.PHP_EOL.'</div>'.'<br>';
        return $tempText;

	}
    public function course_student_activity_to_view_percentage ($user, $plot, $group): string {
        global $DB, $USER, $PAGE, $CFG, $OUTPUT;
        $uid = $USER->id;
        $username = $USER->username;
        $tempText = '';
        $context = context_system::instance();

        try {
            $PAGE->requires->css('/local/teachers_dashboard/Styles/styles.css');
        } catch (exception $e) {
        }

        if ($plot === 'table') {
            if ($user === 'user') {
                $userCoursesQuery =
                    "SELECT DISTINCT cc.id AS cid, cc.fullname AS coursename
                    FROM {user} u
                    JOIN {user_enrolments} ue ON ue.userid = u.id
                    JOIN {enrol} e ON e.id = ue.enrolid
                    JOIN {context} c ON c.instanceid = e.courseid
                    JOIN {role_assignments} ra ON (ra.userid = u.id AND ra.contextid = c.id)
                    JOIN {role} r ON ra.roleid = r.id
                    JOIN {course} cc ON e.courseid = cc.id
                    WHERE u.id = {$uid} AND u.deleted = 0 AND cc.id IS NOT NULL AND (r.shortname = 'editingteacher')
                    GROUP BY cc.id";

                $userCourses = array_values($DB->get_records_sql($userCoursesQuery));


                $tempText .= '<div id="div_class">'.PHP_EOL.
                    "\t".'<h3 class="main_title">نسبت فعالیت  به بازدید فراگیران در دوره های '.$username.'</h3>'.PHP_EOL.
                    "\t".'<table class="data-table">'.PHP_EOL."\t\t".'<tr>'.PHP_EOL.
                    "\t\t".'<th>نام دوره</th>'.PHP_EOL."\t\t".'<th>تعداد فعالیت ها</th>'.PHP_EOL."\t\t".'<th>تعداد بازدید</th>'.PHP_EOL."\t\t".'<th>نسبت فعالیت به بازدید</th>'.PHP_EOL."\t\t".'</tr>';

                foreach ($userCourses as $currentCourse) {
                    $allActivityQuery =
                        "SELECT c.fullname AS coursename, m.name AS activityname, COUNT(DISTINCT cm.id) AS activitycount, COUNT(DISTINCT cmc.id) AS completioncount, COUNT(DISTINCT l.id) as viewcount
                        FROM {user} u
                        JOIN {user_enrolments} ue ON ue.userid = u.id
                        JOIN {enrol} e ON e.id = ue.enrolid
                        JOIN {course} c ON c.id = e.courseid
                        JOIN {course_modules} cm ON cm.course = c.id
                        JOIN {modules} m ON m.id = cm.module
                        JOIN {role_assignments} ra ON ue.userid = ra.userid
                        JOIN {role} r ON ra.roleid = r.id
                        JOIN {logstore_standard_log} l ON l.courseid = c.id
                        LEFT OUTER JOIN {course_modules_completion} cmc ON cmc.coursemoduleid = cm.id
                        WHERE cm.course = {$currentCourse->cid} AND l.eventname = '\\\\core\\\\event\\\\course_viewed'
                        GROUP BY c.id";

                    $allActivity = array_values($DB->get_records_sql($allActivityQuery));

                    $tempText .= '<tr>';
                    $tempText .= '<td>'.$currentCourse->coursename.'</td>';

                    if (count($allActivity) > 0) {
                        $activityCount = $allActivity[0]->completioncount;
                        $viewCount = $allActivity[0]->viewcount;

                        $activityToViewCount = number_format(($activityCount/$viewCount), 2, '.', '');

                        $tempText .= '<td>'.$activityCount.'</td>';
                        $tempText .= '<td>'.$viewCount.'</td>';
                        $tempText .= '<td>'.$activityToViewCount.'</td>';
                    } else {
                        $tempText .= '<td>0</td>';
                        $tempText .= '<td>0</td>';
                        $tempText .= '<td>-</td>';
                    }
                    $tempText .= '</tr>';
                }
            } else if ($user === 'all') {
                $allCoursesQuery =
                    "SELECT DISTINCT cc.id AS cid, cc.fullname AS coursename
                    FROM {user} u
                    JOIN {user_enrolments} ue ON ue.userid = u.id
                    JOIN {enrol} e ON e.id = ue.enrolid
                    JOIN {context} c ON c.instanceid = e.courseid
                    JOIN {role_assignments} ra ON (ra.userid = u.id AND ra.contextid = c.id)
                    JOIN {role} r ON ra.roleid = r.id
                    JOIN {course} cc ON e.courseid = cc.id
                    WHERE u.deleted = 0 AND cc.id IS NOT NULL AND (r.shortname = 'editingteacher')
                    GROUP BY cc.id";

                $allCourses = array_values($DB->get_records_sql($allCoursesQuery));

                $tempText .= '<div id="div_class">'.PHP_EOL.
                    "\t".'<h3 class="main_title">نسبت فعالیت به بازدید در تمام دوره ها</h3>'.PHP_EOL.
                    "\t".'<table class="data-table">'.PHP_EOL."\t\t".'<tr>'.PHP_EOL.
                    "\t\t".'<th>نام دوره</th>'.PHP_EOL."\t\t".'<th>تعداد فعالیت ها</th>'.PHP_EOL."\t\t".'<th>تعداد بازدید</th>'.PHP_EOL."\t\t".'<th>نسبت فعالیت به بازدید</th>'.PHP_EOL."\t\t".'</tr>';

                foreach ($allCourses as $currentCourse) {
                    $allActivityQuery =
                        "SELECT c.fullname AS coursename, m.name AS activityname, COUNT(DISTINCT cm.id) AS activitycount, COUNT(DISTINCT cmc.id) AS completioncount, COUNT(DISTINCT l.id) as viewcount
                        FROM {user} u
                        JOIN {user_enrolments} ue ON ue.userid = u.id
                        JOIN {enrol} e ON e.id = ue.enrolid
                        JOIN {course} c ON c.id = e.courseid
                        JOIN {course_modules} cm ON cm.course = c.id
                        JOIN {modules} m ON m.id = cm.module
                        JOIN {role_assignments} ra ON ue.userid = ra.userid
                        JOIN {role} r ON ra.roleid = r.id
                        JOIN {logstore_standard_log} l ON l.courseid = c.id
                        LEFT OUTER JOIN {course_modules_completion} cmc ON cmc.coursemoduleid = cm.id
                        WHERE cm.course = {$currentCourse->cid} AND l.eventname = '\\\\core\\\\event\\\\course_viewed'
                        GROUP BY c.id";

                    $allActivity = array_values($DB->get_records_sql($allActivityQuery));

                    $tempText .= '<tr>';
                    $tempText .= '<td>'.$currentCourse->coursename.'</td>';

                    if (count($allActivity) > 0) {
                        $activityCount = $allActivity[0]->completioncount;
                        $viewCount = $allActivity[0]->viewcount;

                        $activityToViewCount = number_format(($activityCount/$viewCount), 2, '.', '');


                        $tempText .= '<td>'.$activityCount.'</td>';
                        $tempText .= '<td>'.$viewCount.'</td>';
                        $tempText .= '<td>'.$activityToViewCount.'</td>';
                    } else {
                        $tempText .= '<td>0</td>';
                        $tempText .= '<td>0</td>';
                        $tempText .= '<td>-</td>';
                    }
                    $tempText .= '</tr>';
                }
            } else if ($user === 'admin_all_user_self') {
                $roles = get_user_roles($context, $USER->id, true);
                $role = key($roles);
                $rolename = $roles[$role]->shortname;
                if ($rolename === 'manager') {
                    return $this->course_student_activity_to_view_percentage('all', $plot, $group);
                } else if ($rolename === 'editingteacher') {
                    return $this->course_student_activity_to_view_percentage('user', $plot, $group);
                }
            }

            $tempText .= "\t".'</table>'.PHP_EOL.'</div>'.'<br>';
        } else {
            // is chart
            $timeText = 'روزانه';
            if ($group === 'weekly') $timeText = 'هفتگی';
            $daystatement = "FROM_UNIXTIME(cm.added, '%j-%H')";

            if ($user === 'user') {
                $tempText .= '<div id="div_class">'.PHP_EOL.
                    "\t".'<h3 class="main_title">نسبت فعالیت به بازدید فراگیران در دوره های '.$username.' به صورت '.$timeText.'</h3>'.PHP_EOL."\t";

                $userCoursesQuery =
                    "SELECT DISTINCT cc.id AS cid, cc.fullname AS coursename
                        FROM {user} u
                        JOIN {user_enrolments} ue ON ue.userid = u.id
                        JOIN {enrol} e ON e.id = ue.enrolid
                        JOIN {context} c ON c.instanceid = e.courseid
                        JOIN {role_assignments} ra ON (ra.userid = u.id AND ra.contextid = c.id)
                        JOIN {role} r ON ra.roleid = r.id
                        JOIN {course} cc ON e.courseid = cc.id
                        WHERE u.id = {$uid} AND u.deleted = 0 AND cc.id IS NOT NULL AND (r.shortname = 'editingteacher')
                        GROUP BY cc.id";

                $userCourses = array_values($DB->get_records_sql($userCoursesQuery));

                foreach ($userCourses as $currentCourse) {
                    $allActivityQuery =
                        "SELECT {$daystatement} as state, c.fullname AS coursename, m.name AS activityname, COUNT(DISTINCT cm.id) AS activitycount, COUNT(DISTINCT cmc.id) AS completioncount, COUNT(DISTINCT l.id) as viewcount, WEEK(FROM_UNIXTIME(cm.added)) as week_num
                        FROM {user} u
                        JOIN {user_enrolments} ue ON ue.userid = u.id
                        JOIN {enrol} e ON e.id = ue.enrolid
                        JOIN {course} c ON c.id = e.courseid
                        JOIN {course_modules} cm ON cm.course = c.id
                        JOIN {modules} m ON m.id = cm.module
                        JOIN {role_assignments} ra ON ue.userid = ra.userid
                        JOIN {role} r ON ra.roleid = r.id
                        JOIN {logstore_standard_log} l ON l.courseid = c.id
                        LEFT OUTER JOIN {course_modules_completion} cmc ON cmc.coursemoduleid = cm.id
                        WHERE cm.course = {$currentCourse->cid} AND l.eventname = '\\\\core\\\\event\\\\course_viewed'
                        GROUP BY c.id, state";

                    $allActivity = array_values($DB->get_records_sql($allActivityQuery));

                    $studentActivityGroupedResult = [];
                    if ($group === 'daily') {
                        foreach ($allActivity as $res) {
                            $studentActivityGroupedResult[(int)(explode('-', $res->state)[0])][] = $res;
                        }
                    } else {
                        foreach ($allActivity as $res) {
                            $studentActivityGroupedResult[$res->week_num][] = $res;
                        }
                    }
                    $mainResultArray = [];
                    foreach ($studentActivityGroupedResult as $time => $results) {
                        $totalCompletionCount = 0;
                        $totalViewCount = 0;
                        foreach ($results as $currentRes) {
                            $totalCompletionCount += $currentRes->completioncount;
                            $totalViewCount += $currentRes->viewcount;
                        }
                        $arrayValue = new stdClass();

                        if ($totalViewCount > 0)
                            $arrayValue->percentage = number_format($totalCompletionCount / $totalViewCount, 2, '.', '');
                        else $arrayValue->percentage = 0;

                        if ($arrayValue->percentage > 0) $mainResultArray[$time] = $arrayValue;
                    }

                    if ($plot == 'line_sharp') {
                        $chart = new \core\chart_line();
                    } else if ($plot == 'line_smooth') {
                        $chart = new \core\chart_line();
                        $chart->set_smooth(true);

                    } else if ($plot == 'pie') {
                        $chart = new \core\chart_pie();

                    } else if ($plot == 'doughnut') {
                        $chart = new \core\chart_pie();
                        $chart->set_doughnut(true);
                    } else if ($plot == 'bar') {
                        $chart = new \core\chart_bar();
                    }
                    $groupX = [];
                    $groupY = [];
                    foreach ($mainResultArray as $time => $content) {
                        array_push($groupX, $time);
                        array_push($groupY, $content->percentage);
                    }
                    if (count($groupY) > 0) {
                        $series = new \core\chart_series($currentCourse->coursename, $groupY);
                        $chart->add_series($series);
                        $chart->set_labels($groupX);
                        $chart->set_title(' نسبت فعالیت  به بازدید فراگیران در دوره '.$currentCourse->coursename);
                        if ($plot !== 'pie' && $plot !== 'doughnut') $chart->get_yaxis(0, true)->set_min(0);

                        $tempText .= $OUTPUT->render($chart).'<br>';
                    } else {
                        $tempText .= '<h3>نسبت فعالیت به بازدید برای دوره '.$currentCourse->coursename.' وجود ندارد.</h3><br>';
                    }
                }
            } else if ($user === 'all') {
                $tempText .= '<div id="div_class">'.PHP_EOL.
                    "\t".'<h3 class="main_title">نسبت فعالیت به بازدید فراگیران در تمام دوره ها به صورت '.$timeText.'</h3>'.PHP_EOL.
                    "\t";

                $allCoursesQuery =
                    "SELECT DISTINCT cc.id AS cid, cc.fullname AS coursename
                        FROM {user} u
                        JOIN {user_enrolments} ue ON ue.userid = u.id
                        JOIN {enrol} e ON e.id = ue.enrolid
                        JOIN {context} c ON c.instanceid = e.courseid
                        JOIN {role_assignments} ra ON (ra.userid = u.id AND ra.contextid = c.id)
                        JOIN {role} r ON ra.roleid = r.id
                        JOIN {course} cc ON e.courseid = cc.id
                        WHERE u.deleted = 0 AND cc.id IS NOT NULL AND (r.shortname = 'editingteacher')
                        GROUP BY cc.id";

                $allCourses = array_values($DB->get_records_sql($allCoursesQuery));

                foreach ($allCourses as $currentCourse) {
                    $allActivityQuery =
                        "SELECT {$daystatement} as state, c.fullname AS coursename, m.name AS activityname, COUNT(DISTINCT cm.id) AS activitycount, COUNT(DISTINCT cmc.id) AS completioncount, COUNT(DISTINCT l.id) as viewcount, WEEK(FROM_UNIXTIME(cm.added)) as week_num
                        FROM {user} u
                        JOIN {user_enrolments} ue ON ue.userid = u.id
                        JOIN {enrol} e ON e.id = ue.enrolid
                        JOIN {course} c ON c.id = e.courseid
                        JOIN {course_modules} cm ON cm.course = c.id
                        JOIN {modules} m ON m.id = cm.module
                        JOIN {role_assignments} ra ON ue.userid = ra.userid
                        JOIN {role} r ON ra.roleid = r.id
                        JOIN {logstore_standard_log} l ON l.courseid = c.id
                        LEFT OUTER JOIN {course_modules_completion} cmc ON cmc.coursemoduleid = cm.id
                        WHERE cm.course = {$currentCourse->cid} AND l.eventname = '\\\\core\\\\event\\\\course_viewed'
                        GROUP BY c.id, state";

                    $allActivity = array_values($DB->get_records_sql($allActivityQuery));

                    $studentActivityGroupedResult = [];
                    if ($group === 'daily') {
                        foreach ($allActivity as $res) {
                            $studentActivityGroupedResult[(int)(explode('-', $res->state)[0])][] = $res;
                        }
                    } else {
                        foreach ($allActivity as $res) {
                            $studentActivityGroupedResult[$res->week_num][] = $res;
                        }
                    }
                    $mainResultArray = [];
                    foreach ($studentActivityGroupedResult as $time => $results) {
                        $totalCompletionCount = 0;
                        $totalViewCount = 0;
                        foreach ($results as $currentRes) {
                            $totalCompletionCount += $currentRes->completioncount;
                            $totalViewCount += $currentRes->viewcount;
                        }
                        $arrayValue = new stdClass();

                        if ($totalViewCount > 0)
                            $arrayValue->percentage = number_format($totalCompletionCount / $totalViewCount, 2, '.', '');
                        else $arrayValue->percentage = 0;

                        if ($arrayValue->percentage > 0) $mainResultArray[$time] = $arrayValue;
                    }

                    if ($plot == 'line_sharp') {
                        $chart = new \core\chart_line();
                    } else if ($plot == 'line_smooth') {
                        $chart = new \core\chart_line();
                        $chart->set_smooth(true);

                    } else if ($plot == 'pie') {
                        $chart = new \core\chart_pie();

                    } else if ($plot == 'doughnut') {
                        $chart = new \core\chart_pie();
                        $chart->set_doughnut(true);
                    } else if ($plot == 'bar') {
                        $chart = new \core\chart_bar();
                    }
                    $groupX = [];
                    $groupY = [];
                    foreach ($mainResultArray as $time => $content) {
                        array_push($groupX, $time);
                        array_push($groupY, $content->percentage);
                    }
                    if (count($groupY) > 0) {
                        $series = new \core\chart_series($currentCourse->coursename, $groupY);
                        $chart->add_series($series);
                        $chart->set_labels($groupX);
                        $chart->set_title(' نسبت فعالیت به بازدید فراگیران در دوره '.$currentCourse->coursename);
                        if ($plot !== 'pie' && $plot !== 'doughnut') $chart->get_yaxis(0, true)->set_min(0);

                        $tempText .= $OUTPUT->render($chart).'<br>';
                    }
                    else {
                        $tempText .= '<h3>نسبت فعالیت به بازدید برای دوره '.$currentCourse->coursename.' وجود ندارد.</h3><br>';
                    }
                }
            } else if ($user === 'admin_all_user_self') {
                $roles = get_user_roles($context, $USER->id, true);
                $role = key($roles);
                $rolename = $roles[$role]->shortname;
                if ($rolename === 'manager') {
                    return $this->course_student_activity_to_view_percentage('all', $plot, $group);
                } else if ($rolename === 'editingteacher') {
                    return $this->course_student_activity_to_view_percentage('user', $plot, $group);
                }
            }
            $tempText .= "\t".PHP_EOL.'</div>'.'<br>';
        }
        return $tempText;

	}
    public function course_student_activity_percentage ($user, $plot, $group): string {
        global $DB, $USER, $PAGE, $CFG, $OUTPUT;
        $uid = $USER->id;
        $username = $USER->username;
        $tempText = '';
        $context = context_system::instance();

        try {
            $PAGE->requires->css('/local/teachers_dashboard/Styles/styles.css');
        } catch (exception $e) {
        }

        if ($plot === 'table') {
            if ($user === 'user') {
                $userCoursesQuery =
                    "SELECT DISTINCT cc.id AS cid, cc.fullname AS coursename
                    FROM {user} u
                    JOIN {user_enrolments} ue ON ue.userid = u.id
                    JOIN {enrol} e ON e.id = ue.enrolid
                    JOIN {context} c ON c.instanceid = e.courseid
                    JOIN {role_assignments} ra ON (ra.userid = u.id AND ra.contextid = c.id)
                    JOIN {role} r ON ra.roleid = r.id
                    JOIN {course} cc ON e.courseid = cc.id
                    WHERE u.id = {$uid} AND u.deleted = 0 AND cc.id IS NOT NULL AND (r.shortname = 'editingteacher')
                    GROUP BY cc.id";

                $userCourses = array_values($DB->get_records_sql($userCoursesQuery));


                $tempText .= '<div id="div_class">'.PHP_EOL.
                    "\t".'<h3 class="main_title">درصد فعالیت فراگیران در دوره های '.$username.'</h3>'.PHP_EOL.
                    "\t".'<table class="data-table">'.PHP_EOL."\t\t".'<tr>'.PHP_EOL.
                    "\t\t".'<th>نام دوره</th>'.PHP_EOL."\t\t".'<th>درصد فعالیت ها</th>'.PHP_EOL."\t\t".'</tr>';

                foreach ($userCourses as $currentCourse) {
                    $allActivityQuery =
                        "SELECT c.fullname AS coursename, m.name AS activityname, COUNT(DISTINCT cm.id) AS activitycount, COUNT(DISTINCT cmc.id) AS completioncount 
                        FROM {user} u
                        JOIN {user_enrolments} ue ON ue.userid = u.id
                        JOIN {enrol} e ON e.id = ue.enrolid
                        JOIN {course} c ON c.id = e.courseid
                        JOIN {course_modules} cm ON cm.course = c.id
                        JOIN {modules} m ON m.id = cm.module
                        JOIN {role_assignments} ra ON ue.userid = ra.userid
                        JOIN {role} r ON ra.roleid = r.id
                        LEFT OUTER JOIN {course_modules_completion} cmc ON cmc.coursemoduleid = cm.id
                        WHERE cm.course = {$currentCourse->cid}
                        GROUP BY c.id";

                    $allActivity = array_values($DB->get_records_sql($allActivityQuery));

                    $tempText .= '<tr>';
                    $tempText .= '<td>'.$currentCourse->coursename.'</td>';

                    if (count($allActivity) > 0) {
                        $activityPercent = ($allActivity[0]->completioncount * 100) / ($allActivity[0]->activitycount + $allActivity[0]->completioncount);
                        $activityPercent = number_format($activityPercent, 2, '.', '');

                        $tempText .= '<td>'.$activityPercent.'%</td>';
                    } else {
                        $tempText .= '<td>0.00%</td>';
                    }
                    $tempText .= '</tr>';
                }
            } else if ($user === 'all') {
                $allCoursesQuery =
                    "SELECT DISTINCT cc.id AS cid, cc.fullname AS coursename
                    FROM {user} u
                    JOIN {user_enrolments} ue ON ue.userid = u.id
                    JOIN {enrol} e ON e.id = ue.enrolid
                    JOIN {context} c ON c.instanceid = e.courseid
                    JOIN {role_assignments} ra ON (ra.userid = u.id AND ra.contextid = c.id)
                    JOIN {role} r ON ra.roleid = r.id
                    JOIN {course} cc ON e.courseid = cc.id
                    WHERE u.deleted = 0 AND cc.id IS NOT NULL AND (r.shortname = 'editingteacher')
                    GROUP BY cc.id";

                $allCourses = array_values($DB->get_records_sql($allCoursesQuery));

                $tempText .= '<div id="div_class">'.PHP_EOL.
                    "\t".'<h3 class="main_title">درصد فعالیت فراگیران در تمام دوره ها</h3>'.PHP_EOL.
                    "\t".'<table class="data-table">'.PHP_EOL."\t\t".'<tr>'.PHP_EOL.
                    "\t\t".'<th>نام دوره</th>'.PHP_EOL."\t\t".'<th>درصد فعالیت ها</th>'.PHP_EOL."\t\t".'</tr>';

                foreach ($allCourses as $currentCourse) {
                    $allActivityQuery =
                        "SELECT c.fullname AS coursename, m.name AS activityname, COUNT(DISTINCT cm.id) AS activitycount, COUNT(DISTINCT cmc.id) AS completioncount
                        FROM {user} u
                        JOIN {user_enrolments} ue ON ue.userid = u.id
                        JOIN {enrol} e ON e.id = ue.enrolid
                        JOIN {course} c ON c.id = e.courseid
                        JOIN {course_modules} cm ON cm.course = c.id
                        JOIN {modules} m ON m.id = cm.module
                        JOIN {role_assignments} ra ON ue.userid = ra.userid
                        JOIN {role} r ON ra.roleid = r.id
                        LEFT OUTER JOIN {course_modules_completion} cmc ON cmc.coursemoduleid = cm.id
                        WHERE cm.course = {$currentCourse->cid}
                        GROUP BY c.id";

                    $allActivity = array_values($DB->get_records_sql($allActivityQuery));

                    $tempText .= '<tr>';
                    $tempText .= '<td>'.$currentCourse->coursename.'</td>';

                    if (count($allActivity) > 0) {
                        $activityPercent = ($allActivity[0]->completioncount * 100) / ($allActivity[0]->activitycount + $allActivity[0]->completioncount);
                        $activityPercent = number_format($activityPercent, 2, '.', '');

                        $tempText .= '<td>'.$activityPercent.'%</td>';
                    } else {
                        $tempText .= '<td>0.00%</td>';
                    }
                    $tempText .= '</tr>';
                }
            } else if ($user === 'admin_all_user_self') {
                $roles = get_user_roles($context, $USER->id, true);
                $role = key($roles);
                $rolename = $roles[$role]->shortname;
                if ($rolename === 'manager') {
                    return $this->course_student_activity_percentage('all', $plot, $group);
                } else if ($rolename === 'editingteacher') {
                    return $this->course_student_activity_percentage('user', $plot, $group);
                }
            }

            $tempText .= "\t".'</table>'.PHP_EOL.'</div>'.'<br>';
        } else {
            // is chart
            $timeText = 'روزانه';
            if ($group === 'weekly') $timeText = 'هفتگی';
            $daystatement = "FROM_UNIXTIME(cm.added, '%j-%H')";

            if ($user === 'user') {

                $tempText .= '<div id="div_class">'.PHP_EOL.
                    "\t".'<h3 class="main_title">درصد فعالیت فراگیران در دوره های '.$username.' به صورت '.$timeText.'</h3>'.PHP_EOL."\t";

                $userCoursesQuery =
                    "SELECT DISTINCT cc.id AS cid, cc.fullname AS coursename
                        FROM {user} u
                        JOIN {user_enrolments} ue ON ue.userid = u.id
                        JOIN {enrol} e ON e.id = ue.enrolid
                        JOIN {context} c ON c.instanceid = e.courseid
                        JOIN {role_assignments} ra ON (ra.userid = u.id AND ra.contextid = c.id)
                        JOIN {role} r ON ra.roleid = r.id
                        JOIN {course} cc ON e.courseid = cc.id
                        WHERE u.id = {$uid} AND u.deleted = 0 AND cc.id IS NOT NULL AND (r.shortname = 'editingteacher')
                        GROUP BY cc.id";

                $userCourses = array_values($DB->get_records_sql($userCoursesQuery));

                foreach ($userCourses as $currentCourse) {
                    $allActivityQuery =
                        "SELECT {$daystatement} as state, c.fullname AS coursename, m.name AS activityname, COUNT(DISTINCT cm.id) AS activitycount, COUNT(DISTINCT cmc.id) AS completioncount, WEEK(FROM_UNIXTIME(cm.added)) as week_num
                        FROM {user} u
                        JOIN {user_enrolments} ue ON ue.userid = u.id
                        JOIN {enrol} e ON e.id = ue.enrolid
                        JOIN {course} c ON c.id = e.courseid
                        JOIN {course_modules} cm ON cm.course = c.id
                        JOIN {modules} m ON m.id = cm.module
                        JOIN {role_assignments} ra ON ue.userid = ra.userid
                        JOIN {role} r ON ra.roleid = r.id
                        LEFT OUTER JOIN {course_modules_completion} cmc ON cmc.coursemoduleid = cm.id
                        WHERE cm.course = {$currentCourse->cid}
                        GROUP BY c.id, state";

                    $allActivity = array_values($DB->get_records_sql($allActivityQuery));

                    $studentActivityGroupedResult = [];
                    if ($group === 'daily') {
                        foreach ($allActivity as $res) {
                            $studentActivityGroupedResult[(int)(explode('-', $res->state)[0])][] = $res;
                        }
                    } else {
                        foreach ($allActivity as $res) {
                            $studentActivityGroupedResult[$res->week_num][] = $res;
                        }
                    }
                    $mainResultArray = [];
                    foreach ($studentActivityGroupedResult as $time => $results) {
                        $totalCompletionCount = 0;
                        $totalActivityCount = 0;
                        foreach ($results as $currentRes) {
                            $totalCompletionCount += $currentRes->completioncount;
                            $totalActivityCount += ($currentRes->activitycount + $currentRes->completioncount);
                        }
                        $arrayValue = new stdClass();
                        if ($totalActivityCount > 0)
                            $arrayValue->percentage = ($totalCompletionCount * 100) / ($totalActivityCount);
                        else $arrayValue->percentage = 0;
                        if ($arrayValue->percentage > 0) $mainResultArray[$time] = $arrayValue;
                    }

                    if ($plot == 'line_sharp') {
                        $chart = new \core\chart_line();
                    } else if ($plot == 'line_smooth') {
                        $chart = new \core\chart_line();
                        $chart->set_smooth(true);

                    } else if ($plot == 'pie') {
                        $chart = new \core\chart_pie();

                    } else if ($plot == 'doughnut') {
                        $chart = new \core\chart_pie();
                        $chart->set_doughnut(true);
                    } else if ($plot == 'bar') {
                        $chart = new \core\chart_bar();
                    }
                    $groupX = [];
                    $groupY = [];
                    foreach ($mainResultArray as $time => $content) {
                        array_push($groupX, $time);
                        array_push($groupY, $content->percentage);
                    }
                    if (count($groupY) > 0) {
                        $series = new \core\chart_series($currentCourse->coursename, $groupY);
                        $chart->add_series($series);
                        $chart->set_labels($groupX);
                        $chart->set_title(' درصد فعالیت فراگیران در دوره '.$currentCourse->coursename);
                        if ($plot !== 'pie' && $plot !== 'doughnut') $chart->get_yaxis(0, true)->set_min(0);

                        $tempText .= $OUTPUT->render($chart).'<br>';
                    }
                    else {
                        $tempText .= '<h3>فعالیتی در دوره '.$currentCourse->coursename.' انجام نشده است. <br></h3>';
                    }
                }
            } else if ($user === 'all') {
                $tempText .= '<div id="div_class">'.PHP_EOL.
                    "\t".'<h3 class="main_title">درصد فعالیت فراگیران در تمام دوره ها به صورت '.$timeText.'</h3>'.PHP_EOL.
                    "\t";

                $allCoursesQuery =
                    "SELECT DISTINCT cc.id AS cid, cc.fullname AS coursename
                        FROM {user} u
                        JOIN {user_enrolments} ue ON ue.userid = u.id
                        JOIN {enrol} e ON e.id = ue.enrolid
                        JOIN {context} c ON c.instanceid = e.courseid
                        JOIN {role_assignments} ra ON (ra.userid = u.id AND ra.contextid = c.id)
                        JOIN {role} r ON ra.roleid = r.id
                        JOIN {course} cc ON e.courseid = cc.id
                        WHERE u.deleted = 0 AND cc.id IS NOT NULL AND (r.shortname = 'editingteacher')
                        GROUP BY cc.id";

                $allCourses = array_values($DB->get_records_sql($allCoursesQuery));

                foreach ($allCourses as $currentCourse) {
                    $allActivityQuery =
                        "SELECT {$daystatement} as state, c.fullname AS coursename, m.name AS activityname, COUNT(DISTINCT cm.id) AS activitycount, COUNT(DISTINCT cmc.id) AS completioncount, WEEK(FROM_UNIXTIME(cm.added)) as week_num
                        FROM {user} u
                        JOIN {user_enrolments} ue ON ue.userid = u.id
                        JOIN {enrol} e ON e.id = ue.enrolid
                        JOIN {course} c ON c.id = e.courseid
                        JOIN {course_modules} cm ON cm.course = c.id
                        JOIN {modules} m ON m.id = cm.module
                        JOIN {role_assignments} ra ON ue.userid = ra.userid
                        JOIN {role} r ON ra.roleid = r.id
                        LEFT OUTER JOIN {course_modules_completion} cmc ON cmc.coursemoduleid = cm.id
                        WHERE cm.course = {$currentCourse->cid}
                        GROUP BY c.id, state";

                    $allActivity = array_values($DB->get_records_sql($allActivityQuery));

                    $studentActivityGroupedResult = [];
                    if ($group === 'daily') {
                        foreach ($allActivity as $res) {
                            $studentActivityGroupedResult[(int)(explode('-', $res->state)[0])][] = $res;
                        }
                    } else {
                        foreach ($allActivity as $res) {
                            $studentActivityGroupedResult[$res->week_num][] = $res;
                        }
                    }
                    $mainResultArray = [];
                    foreach ($studentActivityGroupedResult as $time => $results) {
                        $totalCompletionCount = 0;
                        $totalActivityCount = 0;
                        foreach ($results as $currentRes) {
                            $totalCompletionCount += $currentRes->completioncount;
                            $totalActivityCount += ($currentRes->activitycount + $currentRes->completioncount);
                        }
                        $arrayValue = new stdClass();
                        if ($totalActivityCount > 0)
                            $arrayValue->percentage = ($totalCompletionCount * 100) / ($totalActivityCount);
                        else $arrayValue->percentage = 0;
                        if ($arrayValue->percentage > 0) $mainResultArray[$time] = $arrayValue;
                    }

                    if ($plot == 'line_sharp') {
                        $chart = new \core\chart_line();
                    } else if ($plot == 'line_smooth') {
                        $chart = new \core\chart_line();
                        $chart->set_smooth(true);

                    } else if ($plot == 'pie') {
                        $chart = new \core\chart_pie();

                    } else if ($plot == 'doughnut') {
                        $chart = new \core\chart_pie();
                        $chart->set_doughnut(true);
                    } else if ($plot == 'bar') {
                        $chart = new \core\chart_bar();
                    }
                    $groupX = [];
                    $groupY = [];
                    foreach ($mainResultArray as $time => $content) {
                        array_push($groupX, $time);
                        array_push($groupY, $content->percentage);
                    }
                    foreach ($groupY as $grp) {
                        var_dump($grp);
                        echo '<br>';
                    }
                    echo '<br>';
                    if (count($groupY) > 0) {
                        $series = new \core\chart_series($currentCourse->coursename, $groupY);
                        $chart->add_series($series);
                        $chart->set_labels($groupX);
                        $chart->set_title(' درصد فعالیت فراگیران در دوره '.$currentCourse->coursename);
                        if ($plot !== 'pie' && $plot !== 'doughnut') $chart->get_yaxis(0, true)->set_min(0);

                        $tempText .= $OUTPUT->render($chart).'<br>';
                    } else {
                        $tempText .= '<h3>فعالیتی در دوره '.$currentCourse->coursename.' انجام نشده است. <br></h3>';
                    }
                }
            } else if ($user === 'admin_all_user_self') {
                $roles = get_user_roles($context, $USER->id, true);
                $role = key($roles);
                $rolename = $roles[$role]->shortname;
                if ($rolename === 'manager') {
                    return $this->course_student_activity_percentage('all', $plot, $group);
                } else if ($rolename === 'editingteacher') {
                    return $this->course_student_activity_percentage('user', $plot, $group);
                }
            }
            $tempText .= "\t".PHP_EOL.'</div>'.'<br>';
        }
        return $tempText;

	}
    public function course_view_count ($user, $plot, $group): string {
        global $DB, $USER, $PAGE, $CFG, $OUTPUT;
        $uid = $USER->id;
        $username = $USER->username;
        $tempText = '';
        $context = context_system::instance();

        try {
            $PAGE->requires->css('/local/teachers_dashboard/Styles/styles.css');
        } catch (exception $e) {
        }

        if ($plot === 'total') {
            if ($user == 'user') {

                $userCourseQuery =
                    "SELECT DISTINCT cc.id AS cid, cc.fullname AS coursename
                    FROM {user} u
                    JOIN {user_enrolments} ue ON ue.userid = u.id
                    JOIN {enrol} e ON e.id = ue.enrolid
                    JOIN {context} c ON c.instanceid = e.courseid
                    JOIN {role_assignments} ra ON (ra.userid = u.id AND ra.contextid = c.id)
                    JOIN {role} r ON ra.roleid = r.id
                    JOIN {course} cc ON e.courseid = cc.id
                    WHERE u.id = {$uid} AND u.deleted = 0 AND cc.id IS NOT NULL AND (r.shortname = 'editingteacher')
                    GROUP BY cc.id";

                $userCourses = array_values($DB->get_records_sql($userCourseQuery));


                $tempText .= '<div id="div_class">'.PHP_EOL.
                    "\t".'<h3 class="main_title">تعداد بازدید از دوره های '.$username.'</h3>'.PHP_EOL.
                    "\t".'<table class="data-table">'.PHP_EOL."\t\t".'<tr>'.PHP_EOL.
                    "\t\t".'<th>نام دوره</th>'.PHP_EOL."\t\t".'<th>تعداد بازدید</th>'."\t\t".'</tr>';


                foreach ($userCourses as $currentCourse) {
                    // get all student viewes
                    $courseViewCountQuery =
                        "SELECT c.fullname, l.eventname, COUNT(DISTINCT l.id) AS cnt
                        FROM {course} c                       
                        JOIN {logstore_standard_log} l ON l.courseid = c.id
                        JOIN {user} u ON l.userid = u.id
                        JOIN {user_enrolments} ue ON ue.userid = u.id
                        JOIN {enrol} e ON e.id = ue.enrolid
                        JOIN {role_assignments} ra ON ra.userid = u.id
                        JOIN {role} r ON ra.roleid = r.id
                        WHERE r.shortname = 'student' AND c.id = {$currentCourse->cid} AND l.eventname = '\\\\core\\\\event\\\\course_viewed'
                        GROUP BY l.eventname";

                    $courseViewCount = array_values($DB->get_records_sql($courseViewCountQuery));

                    if (count($courseViewCount) > 0) {
                        $tempText .= '<tr>';
                        $tempText .= '<td>' . $currentCourse->coursename . '</td>';
                        $tempText .= '<td>' . $courseViewCount[0]->cnt . '</td>';
                        $tempText .= '</tr>';
                    }
                }
            } else if ($user === 'all') {
                $userCourseQuery =
                    "SELECT DISTINCT cc.id AS cid, cc.fullname AS coursename
                    FROM {user} u
                    JOIN {user_enrolments} ue ON ue.userid = u.id
                    JOIN {enrol} e ON e.id = ue.enrolid
                    JOIN {context} c ON c.instanceid = e.courseid
                    JOIN {role_assignments} ra ON (ra.userid = u.id AND ra.contextid = c.id)
                    JOIN {role} r ON ra.roleid = r.id
                    JOIN {course} cc ON e.courseid = cc.id
                    WHERE u.deleted = 0 AND cc.id IS NOT NULL AND (r.shortname = 'editingteacher')
                    GROUP BY cc.id";

                $allTeachers = array_values($DB->get_records_sql($userCourseQuery));


                $tempText .= '<div id="div_class">'.PHP_EOL.
                    "\t".'<h3 class="main_title">تعداد بازدید از دوره برای تمام دوره ها</h3>'.PHP_EOL.
                    "\t".'<table class="data-table">'.PHP_EOL."\t\t".'<tr>'.PHP_EOL.
                    "\t\t".'<th>نام دوره</th>'.PHP_EOL."\t\t".'<th>تعداد بازدید</th>'."\t\t".'</tr>';

                foreach ($allTeachers as $currentCourse) {
                    $courseViewCountQuery =
                        "SELECT c.fullname, l.eventname, COUNT(DISTINCT l.id) AS cnt
                        FROM {course} c                       
                        JOIN {logstore_standard_log} l ON l.courseid = c.id
                        JOIN {user} u ON l.userid = u.id
                        JOIN {user_enrolments} ue ON ue.userid = u.id
                        JOIN {enrol} e ON e.id = ue.enrolid
                        JOIN {role_assignments} ra ON ra.userid = u.id
                        JOIN {role} r ON ra.roleid = r.id
                        WHERE r.shortname = 'student' AND c.id = {$currentCourse->cid} AND l.eventname = '\\\\core\\\\event\\\\course_viewed'
                        GROUP BY l.eventname";

                    $courseViewCount = array_values($DB->get_records_sql($courseViewCountQuery));

                    if (count($courseViewCount) > 0) {
                        $tempText .= '<tr>';
                        $tempText .= '<td>'.$currentCourse->coursename.'</td>';
                        $tempText .= '<td>'.$courseViewCount[0]->cnt.'</td>';
                        $tempText .= '</tr>';
                    }
                }
            } else if ($user === 'admin_all_user_self') {
                $roles = get_user_roles($context, $USER->id, true);
                $role = key($roles);
                $rolename = $roles[$role]->shortname;
                if ($rolename === 'manager') {
                    return $this->course_view_count('all', $plot, $group);
                } else if ($rolename === 'editingteacher') {
                    return $this->course_view_count('user', $plot, $group);
                }
            }

            $tempText .= "\t".'</table>'.PHP_EOL.'</div>'.'<br>';
        }
        else {
            // is chart
            $timeText = 'روزانه';
            if ($group === 'weekly') $timeText = 'هفتگی';

            $daystatement = "FROM_UNIXTIME(l.timecreated, '%j-%H')";

            $chartQuery = '';
            if ($user == 'user') {

                $tempText .= '<div id="div_class">'.PHP_EOL.
                    "\t".'<h3 class="main_title">تعداد بازدید از دوره های '.$username.' به صورت '.$timeText.'</h3>'.PHP_EOL."\t";

                $userCourseQuery =
                    "SELECT DISTINCT cc.id AS cid, cc.fullname AS coursename
                    FROM {user} u
                    JOIN {user_enrolments} ue ON ue.userid = u.id
                    JOIN {enrol} e ON e.id = ue.enrolid
                    JOIN {context} c ON c.instanceid = e.courseid
                    JOIN {role_assignments} ra ON (ra.userid = u.id AND ra.contextid = c.id)
                    JOIN {role} r ON ra.roleid = r.id
                    JOIN {course} cc ON e.courseid = cc.id
                    WHERE u.id = {$uid} AND u.deleted = 0 AND cc.id IS NOT NULL AND (r.shortname = 'editingteacher')
                    GROUP BY cc.id";

                $userCourses = array_values($DB->get_records_sql($userCourseQuery));

                foreach ($userCourses as $currentCourse) {
                    $chartQuery = "
                        SELECT {$daystatement} AS state, c.fullname, l.eventname, COUNT(DISTINCT l.id) AS cnt, WEEK(FROM_UNIXTIME(l.timecreated)) as week_num
                        FROM {course} c                       
                        JOIN {logstore_standard_log} l ON l.courseid = c.id
                        JOIN {user} u ON l.userid = u.id
                        JOIN {user_enrolments} ue ON ue.userid = u.id
                        JOIN {enrol} e ON e.id = ue.enrolid
                        JOIN {role_assignments} ra ON ra.userid = u.id
                        JOIN {role} r ON ra.roleid = r.id
                        WHERE r.shortname = 'student' AND c.id = {$currentCourse->cid} AND l.eventname = '\\\\core\\\\event\\\\course_viewed'
                        GROUP BY l.eventname, state
                        ORDER BY state";


                    $userCourseViewCount = array_values($DB->get_records_sql($chartQuery));

                    $mainGroupedResult = [];
                    if ($group === 'daily') {
                        foreach ($userCourseViewCount as $res) {
                            $mainGroupedResult[(int)(explode('-', $res->state)[0])][] = $res;
                        }
                    } else {
                        foreach ($userCourseViewCount as $res) {
                            $mainGroupedResult[$res->week_num][] = $res;
                        }
                    }
                    $mainResultArray = [];
                    foreach ($mainGroupedResult as $time => $results) {
                        $totalCount = 0;
                        foreach ($results as $currentRes) {
                            $totalCount += $currentRes->cnt;
                        }
                        $arrayValue = new stdClass();
                        $arrayValue->viewcount = $totalCount;
                        $mainResultArray[$time] = $arrayValue;
                    }

                    if ($plot == 'line_sharp') {
                        $chart = new \core\chart_line();
                    } else if ($plot == 'line_smooth') {
                        $chart = new \core\chart_line();
                        $chart->set_smooth(true);

                    } else if ($plot == 'pie') {
                        $chart = new \core\chart_pie();

                    } else if ($plot == 'doughnut') {
                        $chart = new \core\chart_pie();
                        $chart->set_doughnut(true);
                    } else if ($plot == 'bar') {
                        $chart = new \core\chart_bar();
                    }
                    $groupX = [];
                    $groupY = [];
                    foreach ($mainResultArray as $time => $content) {
                        array_push($groupX, $time);
                        array_push($groupY, $content->viewcount);
                    }
                    if (count($groupY) > 0) {
                        $series = new \core\chart_series($currentCourse->coursename, $groupY);
                        $chart->add_series($series);
                        $chart->set_labels($groupX);
                        $chart->set_title(' تعداد بازدید از دوره '.$currentCourse->coursename);
                        if ($plot !== 'pie' && $plot !== 'doughnut') $chart->get_yaxis(0, true)->set_min(0);

                        $tempText .= $OUTPUT->render($chart).'<br>';
                    }
                    else {
                        $tempText .= '<h3>هیچ بازدیدی از دوره '.$currentCourse->coursename.' انجام نشده است.</h3><br>';
                    }
                }

            } else if ($user === 'all') {
                $tempText .= '<div id="div_class">'.PHP_EOL.
                    "\t".'<h3 class="main_title">تعداد بازدید از تمام دوره ها بر اساس '.$timeText.'</h3>'.PHP_EOL.
                    "\t";

                $userCourseQuery =
                    "SELECT DISTINCT cc.id AS cid, cc.fullname AS coursename
                    FROM {user} u
                    JOIN {user_enrolments} ue ON ue.userid = u.id
                    JOIN {enrol} e ON e.id = ue.enrolid
                    JOIN {context} c ON c.instanceid = e.courseid
                    JOIN {role_assignments} ra ON (ra.userid = u.id AND ra.contextid = c.id)
                    JOIN {role} r ON ra.roleid = r.id
                    JOIN {course} cc ON e.courseid = cc.id
                    WHERE u.deleted = 0 AND cc.id IS NOT NULL AND (r.shortname = 'editingteacher')
                    GROUP BY cc.id";

                $allTeachers = array_values($DB->get_records_sql($userCourseQuery));

                foreach ($allTeachers as $currentCourse) {
                    $chartQuery = "
                    SELECT {$daystatement} AS state, c.fullname, l.eventname, COUNT(DISTINCT l.id) AS cnt, WEEK(FROM_UNIXTIME(l.timecreated)) as week_num
                    FROM {course} c                       
                    JOIN {logstore_standard_log} l ON l.courseid = c.id
                    JOIN {user} u ON l.userid = u.id
                    JOIN {user_enrolments} ue ON ue.userid = u.id
                    JOIN {enrol} e ON e.id = ue.enrolid
                    JOIN {role_assignments} ra ON ra.userid = u.id
                    JOIN {role} r ON ra.roleid = r.id
                    WHERE r.shortname = 'student' AND c.id = {$currentCourse->cid} AND l.eventname = '\\\\core\\\\event\\\\course_viewed'
                    GROUP BY l.eventname, state
                    ORDER BY state";


                    $userCourseViewCount = array_values($DB->get_records_sql($chartQuery));

                    $mainGroupedResult = [];
                    if ($group === 'daily') {
                        foreach ($userCourseViewCount as $res) {
                            $mainGroupedResult[(int)(explode('-', $res->state)[0])][] = $res;
                        }
                    } else {
                        foreach ($userCourseViewCount as $res) {
                            $mainGroupedResult[$res->week_num][] = $res;
                        }
                    }
                    $mainResultArray = [];
                    foreach ($mainGroupedResult as $time => $results) {
                        $totalCount = 0;
                        foreach ($results as $currentRes) {
                            $totalCount += $currentRes->cnt;
                        }
                        $arrayValue = new stdClass();
                        $arrayValue->viewcount = $totalCount;
                        $mainResultArray[$time] = $arrayValue;
                    }

                    // render chart
                    if ($plot == 'line_sharp') {
                        $chart = new \core\chart_line();
                    } else if ($plot == 'line_smooth') {
                        $chart = new \core\chart_line();
                        $chart->set_smooth(true);
                    } else if ($plot == 'pie') {
                        $chart = new \core\chart_pie();
                    } else if ($plot == 'doughnut') {
                        $chart = new \core\chart_pie();
                        $chart->set_doughnut(true);
                    } else if ($plot == 'bar') {
                        $chart = new \core\chart_bar();
                    }
                    $groupX = [];
                    $groupY = [];
                    foreach ($mainResultArray as $time => $content) {
                        array_push($groupX, $time);
                        array_push($groupY, $content->viewcount);
                    }

                    if (count($groupY) > 0) {
                        $series = new \core\chart_series($currentCourse->coursename, $groupY);
                        $chart->add_series($series);
                        $chart->set_labels($groupX);
                        $chart->set_title(' تعداد بازدید از دوره '.$currentCourse->coursename);
                        if ($plot !== 'pie' && $plot !== 'doughnut') $chart->get_yaxis(0, true)->set_min(0);

                        $tempText .= $OUTPUT->render($chart).'<br>';
                    } else {
                        $tempText .= '<h3>هیچ بازدیدی از دوره '.$currentCourse->coursename.' انجام نشده است.</h3><br>';
                    }
                }
            } else if ($user === 'admin_all_user_self') {
                $roles = get_user_roles($context, $USER->id, true);
                $role = key($roles);
                $rolename = $roles[$role]->shortname;
                if ($rolename === 'manager') {
                    return $this->course_view_count('all', $plot, $group);
                } else if ($rolename === 'editingteacher') {
                    return $this->course_view_count('user', $plot, $group);
                }
            }
            $tempText .= "\t".PHP_EOL.'</div>'.'<br>';

        }
        return $tempText;

	}
    public function course_student_view_without_activity_rate ($user, $plot, $group): string {
        global $DB, $USER, $PAGE, $CFG, $OUTPUT;
        $uid = $USER->id;
        $username = $USER->username;
        $tempText = '';
        $context = context_system::instance();

        try {
            $PAGE->requires->css('/local/teachers_dashboard/Styles/styles.css');
        } catch (exception $e) {
        }

        if ($plot === 'table') {
            if ($user == 'user') {

                $userCourseQuery =
                    "SELECT DISTINCT cc.id AS cid, cc.fullname AS coursename
                    FROM {user} u
                    JOIN {user_enrolments} ue ON ue.userid = u.id
                    JOIN {enrol} e ON e.id = ue.enrolid
                    JOIN {context} c ON c.instanceid = e.courseid
                    JOIN {role_assignments} ra ON (ra.userid = u.id AND ra.contextid = c.id)
                    JOIN {role} r ON ra.roleid = r.id
                    JOIN {course} cc ON e.courseid = cc.id
                    WHERE u.id = {$uid} AND u.deleted = 0 AND cc.id IS NOT NULL AND (r.shortname = 'editingteacher')
                    GROUP BY cc.id";

                $userCourses = array_values($DB->get_records_sql($userCourseQuery));


                $tempText .= '<div id="div_class">'.PHP_EOL.
                    "\t".'<h3 class="main_title">نرخ بازدیدهای بدون فعالیت به کل بازدید ها (نرخ پرش) در دوره های '.$username.'</h3>'.PHP_EOL.
                    "\t".'<table class="data-table">'.PHP_EOL."\t\t".'<tr>'.PHP_EOL.
                    "\t\t".'<th>نام دوره</th>'.PHP_EOL."\t\t".'<th>نرخ پرش</th>'."\t\t".'</tr>';

                foreach ($userCourses as $currentCourse) {
                    // get all student viewes
                    $courseViewCountQuery =
                        "SELECT DISTINCT l.eventname, COUNT(DISTINCT l.id) AS cnt
                        FROM {course} c
                        JOIN {logstore_standard_log} l ON l.courseid = c.id
                        JOIN {user} u ON l.userid = u.id
                        JOIN {user_enrolments} ue ON ue.userid = u.id
                        JOIN {enrol} e ON e.id = ue.enrolid
                        JOIN {role_assignments} ra ON ra.userid = u.id
                        JOIN {role} r ON ra.roleid = r.id
                        WHERE r.shortname = 'student' AND c.id = {$currentCourse->cid} AND l.action = 'viewed'
                        GROUP BY l.eventname";

                    $withoutActivityQuery =
                        "SELECT DISTINCT l.id as lid, cmc.id as cmcid, c.id as cid, COUNT(DISTINCT l.id) AS cnt, COUNT(DISTINCT cmc.id) AS completioncount 
                        FROM {course} c
                        JOIN {logstore_standard_log} l ON l.courseid = c.id
                        JOIN {user} u ON l.userid = u.id
                        JOIN {user_enrolments} ue ON ue.userid = u.id
                        JOIN {enrol} e ON e.id = ue.enrolid
                        JOIN {role_assignments} ra ON ra.userid = u.id
                        JOIN {role} r ON ra.roleid = r.id
                        JOIN {course_modules} cm ON cm.course = c.id
                        JOIN {modules} m ON m.id = cm.module
                        LEFT OUTER JOIN {course_modules_completion} cmc ON cmc.coursemoduleid = cm.id
                        WHERE r.shortname = 'student' AND c.id = {$currentCourse->cid} AND l.action = 'viewed'
                        GROUP BY l.id, cmc.id
                        HAVING completioncount = 0";

                    $courseViewCountQuery = array_values($DB->get_records_sql($courseViewCountQuery));
                    $viewWithoutActivity = array_values($DB->get_records_sql($withoutActivityQuery));

                    $tempText .= '<tr>';
                    if (count($courseViewCountQuery) > 0 && count($viewWithoutActivity) > 0) {
                        $allViewCount = $courseViewCountQuery[0]->cnt;
                        $withoutActivity = $viewWithoutActivity[0]->cnt;
                        $viewRate = number_format(($withoutActivity / $allViewCount), 2, '.', '');

                        $tempText .= '<td>' . $currentCourse->coursename . '</td>';
                        $tempText .= '<td>' .$viewRate. '</td>';
                    } else {
                        if (count($courseViewCountQuery) > 0) {
                            $tempText .= '<td>' . $currentCourse->coursename . '</td>';
                            $tempText .= '<td>-</td>';
                        } else if (count($viewWithoutActivity) > 0) {
                            $tempText .= '<td>' . $currentCourse->coursename . '</td>';
                            $tempText .= '<td>0.00</td>';
                        }
                    }
                    $tempText .= '</tr>';
                }
            } else if ($user === 'all') {
                $userCourseQuery =
                    "SELECT DISTINCT cc.id AS cid, cc.fullname AS coursename
                    FROM {user} u
                    JOIN {user_enrolments} ue ON ue.userid = u.id
                    JOIN {enrol} e ON e.id = ue.enrolid
                    JOIN {context} c ON c.instanceid = e.courseid
                    JOIN {role_assignments} ra ON (ra.userid = u.id AND ra.contextid = c.id)
                    JOIN {role} r ON ra.roleid = r.id
                    JOIN {course} cc ON e.courseid = cc.id
                    WHERE u.deleted = 0 AND cc.id IS NOT NULL AND (r.shortname = 'editingteacher')
                    GROUP BY cc.id";

                $allTeachers = array_values($DB->get_records_sql($userCourseQuery));


                $tempText .= '<div id="div_class">'.PHP_EOL.
                    "\t".'<h3 class="main_title">نرخ بازدیدهای بدون فعالیت به کل بازدید ها (نرخ پرش) برای تمام دوره ها</h3>'.PHP_EOL.
                    "\t".'<table class="data-table">'.PHP_EOL."\t\t".'<tr>'.PHP_EOL.
                    "\t\t".'<th>نام دوره</th>'.PHP_EOL."\t\t".'<th>نرخ پرش</th>'."\t\t".'</tr>';

                foreach ($allTeachers as $currentCourse) {
                    // get all student viewes
                    $courseViewCountQuery =
                        "SELECT DISTINCT l.eventname, COUNT(DISTINCT l.id) AS cnt
                        FROM {course} c
                        JOIN {logstore_standard_log} l ON l.courseid = c.id
                        JOIN {user} u ON l.userid = u.id
                        JOIN {user_enrolments} ue ON ue.userid = u.id
                        JOIN {enrol} e ON e.id = ue.enrolid
                        JOIN {role_assignments} ra ON ra.userid = u.id
                        JOIN {role} r ON ra.roleid = r.id
                        WHERE r.shortname = 'student' AND c.id = {$currentCourse->cid} AND l.action = 'viewed'
                        GROUP BY l.eventname";

                    $withoutActivityQuery =
                        "SELECT DISTINCT l.id as lid, cmc.id as cmcid, c.id as cid, COUNT(DISTINCT l.id) AS cnt, COUNT(DISTINCT cmc.id) AS completioncount 
                        FROM {course} c
                        JOIN {logstore_standard_log} l ON l.courseid = c.id
                        JOIN {user} u ON l.userid = u.id
                        JOIN {user_enrolments} ue ON ue.userid = u.id
                        JOIN {enrol} e ON e.id = ue.enrolid
                        JOIN {role_assignments} ra ON ra.userid = u.id
                        JOIN {role} r ON ra.roleid = r.id
                        JOIN {course_modules} cm ON cm.course = c.id
                        JOIN {modules} m ON m.id = cm.module
                        LEFT OUTER JOIN {course_modules_completion} cmc ON cmc.coursemoduleid = cm.id
                        WHERE r.shortname = 'student' AND c.id = {$currentCourse->cid} AND l.action = 'viewed'
                        GROUP BY l.id, cmc.id
                        HAVING completioncount = 0";

                    $courseViewCountQuery = array_values($DB->get_records_sql($courseViewCountQuery));
                    $viewWithoutActivity = array_values($DB->get_records_sql($withoutActivityQuery));

                    $tempText .= '<tr>';
                    if (count($courseViewCountQuery) > 0 && count($viewWithoutActivity) > 0) {
                        $allViewCount = $courseViewCountQuery[0]->cnt;
                        $withoutActivity = $viewWithoutActivity[0]->cnt;
                        $viewRate = number_format(($withoutActivity / $allViewCount), 2, '.', '');

                        $tempText .= '<td>' . $currentCourse->coursename . '</td>';
                        $tempText .= '<td>' .$viewRate. '</td>';
                    } else {
                        if (count($courseViewCountQuery) > 0) {
                            $tempText .= '<td>' . $currentCourse->coursename . '</td>';
                            $tempText .= '<td>-</td>';
                        } else if (count($viewWithoutActivity) > 0) {
                            $tempText .= '<td>' . $currentCourse->coursename . '</td>';
                            $tempText .= '<td>0.00</td>';
                        }
                    }
                    $tempText .= '</tr>';
                }
            } else if ($user === 'admin_all_user_self') {
                $roles = get_user_roles($context, $USER->id, true);
                $role = key($roles);
                $rolename = $roles[$role]->shortname;
                if ($rolename === 'manager') {
                    return $this->course_student_view_without_activity_rate('all', $plot, $group);
                } else if ($rolename === 'editingteacher') {
                    return $this->course_student_view_without_activity_rate('user', $plot, $group);
                }
            }

            $tempText .= "\t".'</table>'.PHP_EOL.'</div>'.'<br>';
        }
        else {
            // is chart
            $timeText = 'روزانه';
            if ($group === 'weekly') $timeText = 'هفتگی';

            $daystatement = "FROM_UNIXTIME(l.timecreated, '%j-%H')";

            $courseViewCountQuery = '';
            if ($user == 'user') {

                $tempText .= '<div id="div_class">'.PHP_EOL.
                    "\t".'<h3 class="main_title"> نرخ بازدیدهای بدون فعالیت به کل بازدید ها (نرخ پرش) برای دوره های '.$username.' به صورت '.$timeText.'</h3>'.PHP_EOL."\t";

                $userCourseQuery =
                    "SELECT DISTINCT cc.id AS cid, cc.fullname AS coursename
                    FROM {user} u
                    JOIN {user_enrolments} ue ON ue.userid = u.id
                    JOIN {enrol} e ON e.id = ue.enrolid
                    JOIN {context} c ON c.instanceid = e.courseid
                    JOIN {role_assignments} ra ON (ra.userid = u.id AND ra.contextid = c.id)
                    JOIN {role} r ON ra.roleid = r.id
                    JOIN {course} cc ON e.courseid = cc.id
                    WHERE u.id = {$uid} AND u.deleted = 0 AND cc.id IS NOT NULL AND (r.shortname = 'editingteacher')
                    GROUP BY cc.id";

                $userCourses = array_values($DB->get_records_sql($userCourseQuery));

                foreach ($userCourses as $currentCourse) {
                    $courseViewCountQuery = "
                        SELECT DISTINCT l.id, {$daystatement} AS state, c.fullname, l.eventname, COUNT(DISTINCT l.id) AS cnt, c1.cnt as whithoutcount, WEEK(FROM_UNIXTIME(l.timecreated)) as week_num
                        FROM {course} c
                        JOIN {logstore_standard_log} l ON l.courseid = c.id
                        JOIN {user} u ON l.userid = u.id
                        JOIN {user_enrolments} ue ON ue.userid = u.id
                        JOIN {enrol} e ON e.id = ue.enrolid
                        JOIN {role_assignments} ra ON ra.userid = u.id
                        JOIN {role} r ON ra.roleid = r.id
                        JOIN (
                            SELECT DISTINCT l.id as lid, cmc.id as cmcid, {$daystatement} AS state, c.fullname, c.id as cid, COUNT(DISTINCT l.id) AS cnt, COUNT(DISTINCT cmc.id) AS completioncount 
                            FROM {course} c
                            JOIN {logstore_standard_log} l ON l.courseid = c.id
                            JOIN {user} u ON l.userid = u.id
                            JOIN {user_enrolments} ue ON ue.userid = u.id
                            JOIN {enrol} e ON e.id = ue.enrolid
                            JOIN {role_assignments} ra ON ra.userid = u.id
                            JOIN {role} r ON ra.roleid = r.id
                            JOIN {course_modules} cm ON cm.course = c.id
                            JOIN {modules} m ON m.id = cm.module
                            LEFT OUTER JOIN {course_modules_completion} cmc ON cmc.coursemoduleid = cm.id
                            WHERE r.shortname = 'student' AND c.id = {$currentCourse->cid} AND l.action = 'viewed'
                            GROUP BY l.id, cmc.id
                            HAVING completioncount = 0
                        ) c1 ON c1.fullname = c.fullname
                        WHERE r.shortname = 'student' AND c.id = {$currentCourse->cid} AND l.action = 'viewed'
                        GROUP BY l.eventname, state
                        ORDER BY state";

                    $userCourseViewCount = array_values($DB->get_records_sql($courseViewCountQuery));

                    $mainGroupedResult = [];
                    if ($group === 'daily') {
                        foreach ($userCourseViewCount as $res) {
                            $mainGroupedResult[(int)(explode('-', $res->state)[0])][] = $res;
                        }
                    } else {
                        foreach ($userCourseViewCount as $res) {
                            $mainGroupedResult[$res->week_num][] = $res;
                        }
                    }

                    $mainResultArray = [];
                    foreach ($mainGroupedResult as $time => $results) {
                        $totalViewCount = 0;
                        $viewWithoutActivityCount = 0;
                        foreach ($results as $currentRes) {
                            $totalViewCount += $currentRes->cnt;
                            if (!is_null($currentRes->whithoutcount)) $viewWithoutActivityCount += $currentRes->whithoutcount;
                        }
                        $viewRate = $viewWithoutActivityCount / $totalViewCount;
                        $viewRate = number_format($viewRate, 2, '.', '');

                        $arrayValue = new stdClass();
                        $arrayValue->viewcount = $viewRate;
                        $mainResultArray[$time] = $arrayValue;
                    }

                    if ($plot == 'line_sharp') {
                        $chart = new \core\chart_line();
                    } else if ($plot == 'line_smooth') {
                        $chart = new \core\chart_line();
                        $chart->set_smooth(true);

                    } else if ($plot == 'pie') {
                        $chart = new \core\chart_pie();

                    } else if ($plot == 'doughnut') {
                        $chart = new \core\chart_pie();
                        $chart->set_doughnut(true);
                    } else if ($plot == 'bar') {
                        $chart = new \core\chart_bar();
                    }
                    $groupX = [];
                    $groupY = [];
                    foreach ($mainResultArray as $time => $content) {
                        array_push($groupX, $time);
                        array_push($groupY, $content->viewcount);
                    }
                    if (count($groupY) > 0) {
                        $series = new \core\chart_series($currentCourse->coursename, $groupY);
                        $chart->add_series($series);
                        $chart->set_labels($groupX);
                        $chart->set_title(' نرخ پرش برای دوره '.$currentCourse->coursename.' با مدرس '.$username);
                        if ($plot !== 'pie' && $plot !== 'doughnut') $chart->get_yaxis(0, true)->set_min(0);

                        $tempText .= $OUTPUT->render($chart).'<br>';
                    }
                    else {
                        $tempText .= '<h3>نرخ پرش برای دوره '.$currentCourse->coursename.' وجود ندارد.</h3><br>';
                    }
                }
            } else if ($user === 'all') {
                $tempText .= '<div id="div_class">'.PHP_EOL.
                    "\t".'<h3 class="main_title">نرخ بازدیدهای بدون فعالیت به کل بازدید ها (نرخ پرش) برای تمام دوره ها به صورت '.$timeText.'</h3>'.PHP_EOL.
                    "\t";

                $userCourseQuery =
                    "SELECT DISTINCT cc.id AS cid, cc.fullname AS coursename, u.username as username
                    FROM {user} u
                    JOIN {user_enrolments} ue ON ue.userid = u.id
                    JOIN {enrol} e ON e.id = ue.enrolid
                    JOIN {context} c ON c.instanceid = e.courseid
                    JOIN {role_assignments} ra ON (ra.userid = u.id AND ra.contextid = c.id)
                    JOIN {role} r ON ra.roleid = r.id
                    JOIN {course} cc ON e.courseid = cc.id
                    WHERE u.deleted = 0 AND cc.id IS NOT NULL AND (r.shortname = 'editingteacher')
                    GROUP BY cc.id";

                $allTeachers = array_values($DB->get_records_sql($userCourseQuery));

                foreach ($allTeachers as $currentCourse) {
                    $courseViewCountQuery = "
                        SELECT DISTINCT l.id, {$daystatement} AS state, c.fullname, l.eventname, COUNT(DISTINCT l.id) AS cnt, c1.cnt as whithoutcount, WEEK(FROM_UNIXTIME(l.timecreated)) as week_num
                        FROM {course} c
                        JOIN {logstore_standard_log} l ON l.courseid = c.id
                        JOIN {user} u ON l.userid = u.id
                        JOIN {user_enrolments} ue ON ue.userid = u.id
                        JOIN {enrol} e ON e.id = ue.enrolid
                        JOIN {role_assignments} ra ON ra.userid = u.id
                        JOIN {role} r ON ra.roleid = r.id
                        JOIN (
                            SELECT DISTINCT l.id as lid, cmc.id as cmcid, {$daystatement} AS state, c.fullname, c.id as cid, COUNT(DISTINCT l.id) AS cnt, COUNT(DISTINCT cmc.id) AS completioncount 
                            FROM {course} c
                            JOIN {logstore_standard_log} l ON l.courseid = c.id
                            JOIN {user} u ON l.userid = u.id
                            JOIN {user_enrolments} ue ON ue.userid = u.id
                            JOIN {enrol} e ON e.id = ue.enrolid
                            JOIN {role_assignments} ra ON ra.userid = u.id
                            JOIN {role} r ON ra.roleid = r.id
                            JOIN {course_modules} cm ON cm.course = c.id
                            JOIN {modules} m ON m.id = cm.module
                            LEFT OUTER JOIN {course_modules_completion} cmc ON cmc.coursemoduleid = cm.id
                            WHERE r.shortname = 'student' AND c.id = {$currentCourse->cid} AND l.action = 'viewed'
                            GROUP BY l.id, cmc.id
                            HAVING completioncount = 0
                        ) c1 ON c1.fullname = c.fullname
                        WHERE r.shortname = 'student' AND c.id = {$currentCourse->cid} AND l.action = 'viewed'
                        GROUP BY l.eventname, state
                        ORDER BY state";


                    $userCourseViewCount = array_values($DB->get_records_sql($courseViewCountQuery));

                    $mainGroupedResult = [];
                    if ($group === 'daily') {
                        foreach ($userCourseViewCount as $res) {
                            $mainGroupedResult[(int)(explode('-', $res->state)[0])][] = $res;
                        }
                    } else {
                        foreach ($userCourseViewCount as $res) {
                            $mainGroupedResult[$res->week_num][] = $res;
                        }
                    }
                    $mainResultArray = [];
                    foreach ($mainGroupedResult as $time => $results) {
                        $totalViewCount = 0;
                        $viewWithoutActivityCount = 0;
                        foreach ($results as $currentRes) {
                            $totalViewCount += $currentRes->cnt;
                            if (!is_null($currentRes->whithoutcount)) $viewWithoutActivityCount += $currentRes->whithoutcount;
                        }
                        $viewRate = $viewWithoutActivityCount / $totalViewCount;
                        $viewRate = number_format($viewRate, 2, '.', '');

                        $arrayValue = new stdClass();
                        $arrayValue->viewcount = $viewRate;
                        $mainResultArray[$time] = $arrayValue;
                    }

                    // render chart
                    if ($plot == 'line_sharp') {
                        $chart = new \core\chart_line();
                    } else if ($plot == 'line_smooth') {
                        $chart = new \core\chart_line();
                        $chart->set_smooth(true);
                    } else if ($plot == 'pie') {
                        $chart = new \core\chart_pie();
                    } else if ($plot == 'doughnut') {
                        $chart = new \core\chart_pie();
                        $chart->set_doughnut(true);
                    } else if ($plot == 'bar') {
                        $chart = new \core\chart_bar();
                    }
                    $groupX = [];
                    $groupY = [];
                    foreach ($mainResultArray as $time => $content) {
                        array_push($groupX, $time);
                        array_push($groupY, $content->viewcount);
                    }

                    if (count($groupY) > 0) {
                        $series = new \core\chart_series($currentCourse->coursename, $groupY);
                        $chart->add_series($series);
                        $chart->set_labels($groupX);
                        $chart->set_title(' نرخ پرش برای دوره '.$currentCourse->coursename.' با مدرس '.$currentCourse->username);
                        if ($plot !== 'pie' && $plot !== 'doughnut') $chart->get_yaxis(0, true)->set_min(0);

                        $tempText .= $OUTPUT->render($chart).'<br>';
                    } else {
                        $tempText .= '<h3>نرخ پرش برای دوره '.$currentCourse->coursename.' وجود ندارد.</h3><br>';
                    }
                }
            } else if ($user === 'admin_all_user_self') {
                $roles = get_user_roles($context, $USER->id, true);
                $role = key($roles);
                $rolename = $roles[$role]->shortname;
                if ($rolename === 'manager') {
                    return $this->course_student_view_without_activity_rate('all', $plot, $group);
                } else if ($rolename === 'editingteacher') {
                    return $this->course_student_view_without_activity_rate('user', $plot, $group);
                }
            }
            $tempText .= "\t".PHP_EOL.'</div>'.'<br>';
        }
        return $tempText;

	}
    public function course_student_view_rate ($user, $plot, $group): string {
        global $DB, $USER, $PAGE, $CFG, $OUTPUT;
        $uid = $USER->id;
        $username = $USER->username;
        $tempText = '';
        $context = context_system::instance();

        try {
            $PAGE->requires->css('/local/teachers_dashboard/Styles/styles.css');
        } catch (exception $e) {
        }

        if ($plot === 'table') {
            if ($user == 'user') {

                $userCourseQuery =
                    "SELECT DISTINCT cc.id AS cid, cc.fullname AS coursename
                    FROM {user} u
                    JOIN {user_enrolments} ue ON ue.userid = u.id
                    JOIN {enrol} e ON e.id = ue.enrolid
                    JOIN {context} c ON c.instanceid = e.courseid
                    JOIN {role_assignments} ra ON (ra.userid = u.id AND ra.contextid = c.id)
                    JOIN {role} r ON ra.roleid = r.id
                    JOIN {course} cc ON e.courseid = cc.id
                    WHERE u.id = {$uid} AND u.deleted = 0 AND cc.id IS NOT NULL AND (r.shortname = 'editingteacher')
                    GROUP BY cc.id";

                $userCourses = array_values($DB->get_records_sql($userCourseQuery));


                $tempText .= '<div id="div_class">'.PHP_EOL.
                    "\t".'<h3 class="main_title">نرخ بازدید از دوره های '.$username.'</h3>'.PHP_EOL.
                    "\t".'<table class="data-table">'.PHP_EOL."\t\t".'<tr>'.PHP_EOL.
                    "\t\t".'<th>نام دوره</th>'.PHP_EOL."\t\t".'<th>تعداد فراگیران</th>'.PHP_EOL."\t\t".'<th>نرخ بازدید</th>'."\t\t".'</tr>';


                foreach ($userCourses as $currentCourse) {
                    $participantsQuery =
                        "SELECT c.id as cid, c.fullname as coursename, COUNT(DISTINCT ue.userid) as participants
                        FROM {user} u
                        JOIN {user_enrolments} ue ON ue.userid = u.id
                        JOIN {enrol} e ON e.id = ue.enrolid
                        JOIN {course} c ON e.courseid = c.id
                        JOIN {role_assignments} ra ON ra.userid = u.id
                        JOIN {role} r ON ra.roleid = r.id
                        WHERE r.shortname = 'student' AND c.id = {$currentCourse->cid}
                        GROUP BY c.id";

                    // get all student viewes
                    $courseViewCountQuery =
                        "SELECT c.fullname, l.eventname, COUNT(DISTINCT l.id) AS cnt, COUNT(DISTINCT u.id) as participants 
                        FROM {course} c
                        JOIN {logstore_standard_log} l ON l.courseid = c.id
                        JOIN {user} u ON l.userid = u.id
                        JOIN {user_enrolments} ue ON ue.userid = u.id
                        JOIN {enrol} e ON e.id = ue.enrolid
                        JOIN {role_assignments} ra ON ra.userid = u.id
                        JOIN {role} r ON ra.roleid = r.id
                        WHERE r.shortname = 'student' AND c.id = {$currentCourse->cid} AND l.eventname = '\\\\core\\\\event\\\\course_viewed'
                        GROUP BY l.eventname";

                    $courseViewCount = array_values($DB->get_records_sql($courseViewCountQuery));
                    $participants = array_values($DB->get_records_sql($participantsQuery));

                    if (!empty($participants) > 0) $participants = $participants[0]->participants;
                    else $participants = 0;

                    $tempText .= '<tr>';
                    if (count($courseViewCount) > 0 && !empty($participants)) {
                        $viewRate = $courseViewCount[0]->cnt / $participants;
                        $viewRate = number_format($viewRate, 2, '.', '');

                        $tempText .= '<td>' . $currentCourse->coursename . '</td>';
                        $tempText .= '<td>' . $participants . '</td>';
                        $tempText .= '<td>' .$viewRate. '</td>';
                    } else {
                        $tempText .= '<td>'.$currentCourse->coursename.'</td>';
                        $tempText .= '<td>'.$participants.'</td>';
                        $tempText .= '<td>-</td>';
                    }
                    $tempText .= '</tr>';
                }
            } else if ($user === 'all') {
                $userCourseQuery =
                    "SELECT DISTINCT cc.id AS cid, cc.fullname AS coursename
                    FROM {user} u
                    JOIN {user_enrolments} ue ON ue.userid = u.id
                    JOIN {enrol} e ON e.id = ue.enrolid
                    JOIN {context} c ON c.instanceid = e.courseid
                    JOIN {role_assignments} ra ON (ra.userid = u.id AND ra.contextid = c.id)
                    JOIN {role} r ON ra.roleid = r.id
                    JOIN {course} cc ON e.courseid = cc.id
                    WHERE u.deleted = 0 AND cc.id IS NOT NULL AND (r.shortname = 'editingteacher')
                    GROUP BY cc.id";

                $allTeachers = array_values($DB->get_records_sql($userCourseQuery));


                $tempText .= '<div id="div_class">'.PHP_EOL.
                    "\t".'<h3 class="main_title">نرخ بازدید از دوره برای تمام دوره ها</h3>'.PHP_EOL.
                    "\t".'<table class="data-table">'.PHP_EOL."\t\t".'<tr>'.PHP_EOL.
                    "\t\t".'<th>نام دوره</th>'.PHP_EOL."\t\t".'<th>تعداد فراگیران</th>'.PHP_EOL."\t\t".'<th>نرخ بازدید</th>'."\t\t".'</tr>';

                foreach ($allTeachers as $currentCourse) {
                    $participantsQuery =
                        "SELECT c.id as cid, c.fullname as coursename, COUNT(DISTINCT ue.userid) as participants
                        FROM {user} u
                        JOIN {user_enrolments} ue ON ue.userid = u.id
                        JOIN {enrol} e ON e.id = ue.enrolid
                        JOIN {course} c ON e.courseid = c.id
                        JOIN {role_assignments} ra ON ra.userid = u.id
                        JOIN {role} r ON ra.roleid = r.id
                        WHERE r.shortname = 'student' AND c.id = {$currentCourse->cid}
                        GROUP BY c.id";

                    $courseViewCountQuery =
                        "SELECT c.fullname, l.eventname, COUNT(DISTINCT l.id) AS cnt, COUNT(DISTINCT u.id) as participants 
                        FROM {course} c
                        JOIN {logstore_standard_log} l ON l.courseid = c.id
                        JOIN {user} u ON l.userid = u.id
                        JOIN {user_enrolments} ue ON ue.userid = u.id
                        JOIN {enrol} e ON e.id = ue.enrolid
                        JOIN {role_assignments} ra ON ra.userid = u.id
                        JOIN {role} r ON ra.roleid = r.id
                        WHERE r.shortname = 'student' AND c.id = {$currentCourse->cid} AND l.eventname = '\\\\core\\\\event\\\\course_viewed'
                        GROUP BY l.eventname";

                    $courseViewCount = array_values($DB->get_records_sql($courseViewCountQuery));
                    $participants = array_values($DB->get_records_sql($participantsQuery));

                    if (!empty($participants) > 0) $participants = $participants[0]->participants;
                    else $participants = 0;

                    $tempText .= '<tr>';
                    if (count($courseViewCount) > 0 && !empty($participants)) {
                        $viewRate = $courseViewCount[0]->cnt / $participants;
                        $viewRate = number_format($viewRate, 2, '.', '');

                        $tempText .= '<td>'.$currentCourse->coursename.'</td>';
                        $tempText .= '<td>'.$participants.'</td>';
                        $tempText .= '<td>'.$viewRate.'</td>';
                    } else {
                        $tempText .= '<td>'.$currentCourse->coursename.'</td>';
                        $tempText .= '<td>'.$participants.'</td>';
                        $tempText .= '<td>-</td>';
                    }
                    $tempText .= '</tr>';
                }
            } else if ($user === 'admin_all_user_self') {
                $roles = get_user_roles($context, $USER->id, true);
                $role = key($roles);
                $rolename = $roles[$role]->shortname;
                if ($rolename === 'manager') {
                    return $this->course_student_view_rate('all', $plot, $group);
                } else if ($rolename === 'editingteacher') {
                    return $this->course_student_view_rate('user', $plot, $group);
                }
            }

            $tempText .= "\t".'</table>'.PHP_EOL.'</div>'.'<br>';
        }
        else {
            // is chart
            $timeText = 'روزانه';
            if ($group === 'weekly') $timeText = 'هفتگی';

            $daystatement = "FROM_UNIXTIME(l.timecreated, '%j-%H')";

            $chartQuery = '';
            if ($user == 'user') {

                $tempText .= '<div id="div_class">'.PHP_EOL.
                    "\t".'<h3 class="main_title">نرخ بازدید از دوره های '.$username.' به صورت '.$timeText.'</h3>'.PHP_EOL."\t";

                $userCourseQuery =
                    "SELECT DISTINCT cc.id AS cid, cc.fullname AS coursename
                    FROM {user} u
                    JOIN {user_enrolments} ue ON ue.userid = u.id
                    JOIN {enrol} e ON e.id = ue.enrolid
                    JOIN {context} c ON c.instanceid = e.courseid
                    JOIN {role_assignments} ra ON (ra.userid = u.id AND ra.contextid = c.id)
                    JOIN {role} r ON ra.roleid = r.id
                    JOIN {course} cc ON e.courseid = cc.id
                    WHERE u.id = {$uid} AND u.deleted = 0 AND cc.id IS NOT NULL AND (r.shortname = 'editingteacher')
                    GROUP BY cc.id";

                $userCourses = array_values($DB->get_records_sql($userCourseQuery));

                foreach ($userCourses as $currentCourse) {
                    $participantsQuery =
                        "SELECT c.id as cid, c.fullname as coursename, COUNT(DISTINCT ue.userid) as participants
                        FROM {user} u
                        JOIN {user_enrolments} ue ON ue.userid = u.id
                        JOIN {enrol} e ON e.id = ue.enrolid
                        JOIN {course} c ON e.courseid = c.id
                        JOIN {role_assignments} ra ON ra.userid = u.id
                        JOIN {role} r ON ra.roleid = r.id
                        WHERE r.shortname = 'student' AND c.id = {$currentCourse->cid}
                        GROUP BY c.id";

                    $chartQuery = "
                        SELECT {$daystatement} AS state, c.fullname, l.eventname, COUNT(DISTINCT l.id) AS cnt, WEEK(FROM_UNIXTIME(l.timecreated)) as week_num
                        FROM {course} c
                        JOIN {logstore_standard_log} l ON l.courseid = c.id
                        JOIN {user} u ON l.userid = u.id
                        JOIN {user_enrolments} ue ON ue.userid = u.id
                        JOIN {enrol} e ON e.id = ue.enrolid
                        JOIN {role_assignments} ra ON ra.userid = u.id
                        JOIN {role} r ON ra.roleid = r.id
                        WHERE r.shortname = 'student' AND c.id = {$currentCourse->cid} AND l.eventname = '\\\\core\\\\event\\\\course_viewed'
                        GROUP BY l.eventname, state
                        ORDER BY state";


                    $userCourseViewCount = array_values($DB->get_records_sql($chartQuery));
                    $participants = array_values($DB->get_records_sql($participantsQuery));

                    if (!empty($participants) > 0) $participants = $participants[0]->participants;
                    else $participants = 0;

                    $mainGroupedResult = [];
                    if ($group === 'daily') {
                        foreach ($userCourseViewCount as $res) {
                            $mainGroupedResult[(int)(explode('-', $res->state)[0])][] = $res;
                        }
                    } else {
                        foreach ($userCourseViewCount as $res) {
                            $mainGroupedResult[$res->week_num][] = $res;
                        }
                    }

                    $mainResultArray = [];
                    foreach ($mainGroupedResult as $time => $results) {
                        $totalCount = 0;
                        foreach ($results as $currentRes) {
                            $totalCount += $currentRes->cnt;
                        }
                        $viewRate = $totalCount / $participants;
                        $viewRate = number_format($viewRate, 2, '.', '');

                        $arrayValue = new stdClass();
                        $arrayValue->viewcount = $viewRate;
                        $mainResultArray[$time] = $arrayValue;
                    }

                    if ($plot == 'line_sharp') {
                        $chart = new \core\chart_line();
                    } else if ($plot == 'line_smooth') {
                        $chart = new \core\chart_line();
                        $chart->set_smooth(true);

                    } else if ($plot == 'pie') {
                        $chart = new \core\chart_pie();

                    } else if ($plot == 'doughnut') {
                        $chart = new \core\chart_pie();
                        $chart->set_doughnut(true);
                    } else if ($plot == 'bar') {
                        $chart = new \core\chart_bar();
                    }
                    $groupX = [];
                    $groupY = [];
                    foreach ($mainResultArray as $time => $content) {
                        array_push($groupX, $time);
                        array_push($groupY, $content->viewcount);
                    }
                    if (count($groupY) > 0 && !empty($participants)) {
                        $series = new \core\chart_series($currentCourse->coursename, $groupY);
                        $chart->add_series($series);
                        $chart->set_labels($groupX);
                        if ($plot !== 'pie' && $plot !== 'doughnut') $chart->set_title(' نرخ بازدید از دوره های '.$username.' با '.$participants.' نفر فراگیر ');
                        else $chart->set_title(' نرخ بازدید از دوره '.$currentCourse->coursename.' با مدرس '.$username.' با '.$participants.' نفر فراگیر ');

                        if ($plot !== 'pie' && $plot !== 'doughnut') $chart->get_yaxis(0, true)->set_min(0);

                        $tempText .= $OUTPUT->render($chart).'<br>';
                    }
                    else {
                        $tempText .= '<h3>هیچ بازدیدی از دوره '.$currentCourse->coursename.' انجام نشده است.</h3><br>';
                    }
                }
            } else if ($user === 'all') {
                $tempText .= '<div id="div_class">'.PHP_EOL.
                    "\t".'<h3 class="main_title">نرخ بازدید از تمام دوره ها به صورت '.$timeText.'</h3>'.PHP_EOL.
                    "\t";

                $userCourseQuery =
                    "SELECT DISTINCT cc.id AS cid, cc.fullname AS coursename, u.username as username
                    FROM {user} u
                    JOIN {user_enrolments} ue ON ue.userid = u.id
                    JOIN {enrol} e ON e.id = ue.enrolid
                    JOIN {context} c ON c.instanceid = e.courseid
                    JOIN {role_assignments} ra ON (ra.userid = u.id AND ra.contextid = c.id)
                    JOIN {role} r ON ra.roleid = r.id
                    JOIN {course} cc ON e.courseid = cc.id
                    WHERE u.deleted = 0 AND cc.id IS NOT NULL AND (r.shortname = 'editingteacher')
                    GROUP BY cc.id";

                $allTeachers = array_values($DB->get_records_sql($userCourseQuery));

                foreach ($allTeachers as $currentCourse) {
                    $participantsQuery =
                        "SELECT c.id as cid, c.fullname as coursename, COUNT(DISTINCT ue.userid) as participants
                        FROM {user} u
                        JOIN {user_enrolments} ue ON ue.userid = u.id
                        JOIN {enrol} e ON e.id = ue.enrolid
                        JOIN {course} c ON e.courseid = c.id
                        JOIN {role_assignments} ra ON ra.userid = u.id
                        JOIN {role} r ON ra.roleid = r.id
                        WHERE r.shortname = 'student' AND c.id = {$currentCourse->cid}
                        GROUP BY c.id";

                    $chartQuery = "
                    SELECT {$daystatement} AS state, c.fullname, l.eventname, COUNT(DISTINCT l.id) AS cnt, WEEK(FROM_UNIXTIME(l.timecreated)) as week_num, COUNT(DISTINCT u.id) as participants 
                    FROM {course} c                       
                    JOIN {logstore_standard_log} l ON l.courseid = c.id
                    JOIN {user} u ON l.userid = u.id
                    JOIN {user_enrolments} ue ON ue.userid = u.id
                    JOIN {enrol} e ON e.id = ue.enrolid
                    JOIN {role_assignments} ra ON ra.userid = u.id
                    JOIN {role} r ON ra.roleid = r.id
                    WHERE r.shortname = 'student' AND c.id = {$currentCourse->cid} AND l.eventname = '\\\\core\\\\event\\\\course_viewed'
                    GROUP BY l.eventname, state
                    ORDER BY state";


                    $userCourseViewCount = array_values($DB->get_records_sql($chartQuery));
                    $participants = array_values($DB->get_records_sql($participantsQuery));

                    if (!empty($participants)) $participants = $participants[0]->participants;
                    else $participants = 0;

                    $mainGroupedResult = [];
                    if ($group === 'daily') {
                        foreach ($userCourseViewCount as $res) {
                            $mainGroupedResult[(int)(explode('-', $res->state)[0])][] = $res;
                        }
                    } else {
                        foreach ($userCourseViewCount as $res) {
                            $mainGroupedResult[$res->week_num][] = $res;
                        }
                    }
                    $mainResultArray = [];
                    $participantCount = null;
                    foreach ($mainGroupedResult as $time => $results) {
                        $totalCount = 0;
                        foreach ($results as $currentRes) {
                            $totalCount += $currentRes->cnt;
                        }
                        $viewRate = $totalCount / $participants;
                        $viewRate = number_format($viewRate, 2, '.', '');

                        $arrayValue = new stdClass();
                        $arrayValue->viewcount = $viewRate;
                        $mainResultArray[$time] = $arrayValue;
                    }

                    // render chart
                    if ($plot == 'line_sharp') {
                        $chart = new \core\chart_line();
                    } else if ($plot == 'line_smooth') {
                        $chart = new \core\chart_line();
                        $chart->set_smooth(true);
                    } else if ($plot == 'pie') {
                        $chart = new \core\chart_pie();
                    } else if ($plot == 'doughnut') {
                        $chart = new \core\chart_pie();
                        $chart->set_doughnut(true);
                    } else if ($plot == 'bar') {
                        $chart = new \core\chart_bar();
                    }
                    $groupX = [];
                    $groupY = [];
                    foreach ($mainResultArray as $time => $content) {
                        array_push($groupX, $time);
                        array_push($groupY, $content->viewcount);
                    }

                    if (count($groupY) > 0 && !empty($participants)) {
                        $series = new \core\chart_series($currentCourse->coursename, $groupY);
                        $chart->add_series($series);
                        $chart->set_labels($groupX);
                        if ($plot !== 'pie' && $plot !== 'doughnut') $chart->set_title(' نرخ بازدید از دوره های '.$currentCourse->username.' با '.$participants.' نفر فراگیر ');
                        else $chart->set_title(' نرخ بازدید از دوره '.$currentCourse->coursename.' با مدرس '.$currentCourse->username.' با '.$participants.' نفر فراگیر ');
                        if ($plot !== 'pie' && $plot !== 'doughnut') $chart->get_yaxis(0, true)->set_min(0);

                        $tempText .= $OUTPUT->render($chart).'<br>';
                    } else {
                        $tempText .= '<h3>هیچ بازدیدی از دوره '.$currentCourse->coursename.' انجام نشده است.</h3><br>';
                    }
                }
            } else if ($user === 'admin_all_user_self') {
                $roles = get_user_roles($context, $USER->id, true);
                $role = key($roles);
                $rolename = $roles[$role]->shortname;
                if ($rolename === 'manager') {
                    return $this->course_student_view_rate('all', $plot, $group);
                } else if ($rolename === 'editingteacher') {
                    return $this->course_student_view_rate('user', $plot, $group);
                }
            }
            $tempText .= "\t".PHP_EOL.'</div>'.'<br>';
        }
        return $tempText;

	}

}

?>