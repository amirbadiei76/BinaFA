<?php
/**
* @package     local_teachers_dashboard
* @author      Kristian
* @license     http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
* @var stdClass $plugin
*/

class CourseAnalytics {

    public function course_student_avg_attempts_to_pass ($user, $plot): string {
        global $DB, $USER, $PAGE, $CFG, $OUTPUT;
        $uid = $USER->id;
        $username = $USER->username;
        $tempText = '';
        $context = context_system::instance();

        try {
            $PAGE->requires->css('/local/teachers_dashboard/Styles/styles.css');
        } catch (exception $e) {
        }

        if ($plot === 'table') {
            if ($user === 'user') {
                $userCourseQuery =
                    "SELECT DISTINCT cc.id AS cid, cc.fullname AS coursename
                    FROM {user} u
                    JOIN {user_enrolments} ue ON ue.userid = u.id
                    JOIN {enrol} e ON e.id = ue.enrolid
                    JOIN {context} c ON c.instanceid = e.courseid
                    JOIN {role_assignments} ra ON (ra.userid = u.id AND ra.contextid = c.id)
                    JOIN {role} r ON ra.roleid = r.id
                    JOIN {course} cc ON e.courseid = cc.id
                    WHERE u.id = {$uid} AND u.deleted = 0 AND cc.id IS NOT NULL AND (r.shortname = 'editingteacher')
                    GROUP BY cc.id";

                $userCourses = array_values($DB->get_records_sql($userCourseQuery));

                $tempText .= '<div id="div_class">'.PHP_EOL.
                    "\t".'<h3 class="main_title">میانگین تعداد تلاش ها برای قبولی در آزمون ها در دوره های '.$username.'</h3>'.PHP_EOL.
                    "\t".'<table class="data-table">'.PHP_EOL."\t\t".'<tr>'.PHP_EOL.
                    "\t\t".'<th>نام دوره</th>'.PHP_EOL."\t\t".'<th>نام آزمون</th>'.PHP_EOL."\t\t".'<th>تعداد شرکت کنندگان در آزمون</th>'.PHP_EOL."\t\t".'<th>مجموع تلاش ها برای قبولی</th>'.PHP_EOL."\t\t".'<th>تعداد مردود شده</th>'.PHP_EOL."\t\t".'<th>تعداد قبولی</th>'.PHP_EOL."\t\t".'<th>میانگین تعداد تلاش ها برای قبولی</th>'."\t\t".'</tr>';

                foreach ($userCourses as $currentCourse) {
                    $passedQuizAttemptsQuery =
                        "SELECT qa.id AS qaid, q.id as qid, c.fullname AS coursename, u.username as username, qa.attempt as attempts, q.name AS quiz, (q.sumgrades / 2) AS quiz_sum, ROUND(MAX(qa.sumgrades), 2) AS grade, COUNT(DISTINCT u.id) as attemptedUsers
                        FROM {quiz_attempts} qa
                        JOIN {quiz} q ON qa.quiz = q.id
                        JOIN {course} c ON q.course = c.id
                        JOIN {user} u ON u.id = qa.userid
                        JOIN {role_assignments} ra ON ra.userid = u.id
                        JOIN {role} r ON ra.roleid = r.id
                        WHERE u.deleted = 0 AND r.shortname = 'student' AND c.id = {$currentCourse->cid} AND qa.state = 'finished'
                        GROUP BY qa.id";
                    $passedQuizAttempts = array_values($DB->get_records_sql($passedQuizAttemptsQuery));

                    $quizGroupedArray = [];
                    foreach ($passedQuizAttempts as $attempts) {
                        $quizGroupedArray[$attempts->qid][] = $attempts;
                    }

                    foreach ($quizGroupedArray as $quiz => $results) {
                        $attemptsByUser = [];
                        $passedUsers = 0;
                        $allAttempsToPass = 0;
                        foreach ($results as $result) {
                            $attemptsByUser[$result->username][] = $result;
                        }
                        foreach ($attemptsByUser as $username => $userAttempt) {
                            $userAttemptCount = 0;
                            foreach ($userAttempt as $currentAttempt) {
                                $userAttemptCount += 1;

                                if ($currentAttempt->grade >= $currentAttempt->quiz_sum) {
                                    $passedUsers += 1;
                                    $allAttempsToPass += $userAttemptCount;
                                    break;
                                }
                            }
                        }
                        $usersCount = count($attemptsByUser);
                        $failedCount = $usersCount - $passedUsers;
                        $quizName = $DB->get_record('quiz', ['id'=>$quiz])->name;


                        if ($usersCount > 0) {
                            $tempText .= '<tr>';
                            $tempText .= '<td>'.$currentCourse->coursename.'</td>';
                            $tempText .= '<td>'.$quizName.'</td>';
                            $tempText .= '<td>'.$usersCount.'</td>';
                            $tempText .= '<td>'.$allAttempsToPass.'</td>';
                            $tempText .= '<td>'.$failedCount.'</td>';
                            $tempText .= '<td>'.$passedUsers.'</td>';

                            $attemptAvg = number_format(($allAttempsToPass / $passedUsers), 2, '.', '');
                            $tempText .= '<td>'.$attemptAvg.'</td>';
                            $tempText .= '</tr>';
                        }

                    }
                }
            } else if ($user === 'all') {
                $allCoursesQuery =
                    "SELECT DISTINCT cc.id AS cid, cc.fullname AS coursename
                    FROM {user} u
                    JOIN {user_enrolments} ue ON ue.userid = u.id
                    JOIN {enrol} e ON e.id = ue.enrolid
                    JOIN {context} c ON c.instanceid = e.courseid
                    JOIN {role_assignments} ra ON (ra.userid = u.id AND ra.contextid = c.id)
                    JOIN {role} r ON ra.roleid = r.id
                    JOIN {course} cc ON e.courseid = cc.id
                    WHERE u.deleted = 0 AND cc.id IS NOT NULL AND (r.shortname = 'editingteacher')
                    GROUP BY cc.id";

                $allCourses = array_values($DB->get_records_sql($allCoursesQuery));

                $tempText .= '<div id="div_class">'.PHP_EOL.
                    "\t".'<h3 class="main_title">میانگین تعداد تلاش ها برای قبولی در آزمون ها در تمام دوره ها </h3>'.PHP_EOL.
                    "\t".'<table class="data-table">'.PHP_EOL."\t\t".'<tr>'.PHP_EOL.
                    "\t\t".'<th>نام دوره</th>'.PHP_EOL."\t\t".'<th>نام آزمون</th>'.PHP_EOL."\t\t".'<th>تعداد شرکت کنندگان در آزمون</th>'.PHP_EOL."\t\t".'<th>مجموع تلاش ها برای قبولی</th>'.PHP_EOL."\t\t".'<th>تعداد مردود شده</th>'.PHP_EOL."\t\t".'<th>تعداد قبولی</th>'.PHP_EOL."\t\t".'<th>میانگین تعداد تلاش ها برای قبولی</th>'."\t\t".'</tr>';

                foreach ($allCourses as $currentCourse) {
                    $passedQuizAttemptsQuery =
                        "SELECT qa.id AS qaid, q.id as qid, c.fullname AS coursename, u.username as username, qa.attempt as attempts, q.name AS quiz, (q.sumgrades / 2) AS quiz_sum, ROUND(MAX(qa.sumgrades), 2) AS grade, COUNT(DISTINCT u.id) as attemptedUsers
                        FROM {quiz_attempts} qa
                        JOIN {quiz} q ON qa.quiz = q.id
                        JOIN {course} c ON q.course = c.id
                        JOIN {user} u ON u.id = qa.userid
                        JOIN {role_assignments} ra ON ra.userid = u.id
                        JOIN {role} r ON ra.roleid = r.id
                        WHERE u.deleted = 0 AND r.shortname = 'student' AND c.id = {$currentCourse->cid} AND qa.state = 'finished'
                        GROUP BY qa.id";
                    $passedQuizAttempts = array_values($DB->get_records_sql($passedQuizAttemptsQuery));

                    $quizGroupedArray = [];
                    foreach ($passedQuizAttempts as $attempts) {
                        $quizGroupedArray[$attempts->qid][] = $attempts;
                    }

                    foreach ($quizGroupedArray as $quiz => $results) {
                        $attemptsByUser = [];
                        $passedUsers = 0;
                        $allAttempsToPass = 0;
                        foreach ($results as $result) {
                            $attemptsByUser[$result->username][] = $result;
                        }
                        foreach ($attemptsByUser as $username => $userAttempt) {
                            $userAttemptCount = 0;
                            foreach ($userAttempt as $currentAttempt) {
                                $userAttemptCount += 1;

                                if ($currentAttempt->grade >= $currentAttempt->quiz_sum) {
                                    $passedUsers += 1;
                                    $allAttempsToPass += $userAttemptCount;
                                    break;
                                }
                            }
                        }
                        $usersCount = count($attemptsByUser);
                        $failedCount = $usersCount - $passedUsers;
                        $quizName = $DB->get_record('quiz', ['id'=>$quiz])->name;


                        if ($usersCount > 0) {
                            $tempText .= '<tr>';
                            $tempText .= '<td>'.$currentCourse->coursename.'</td>';
                            $tempText .= '<td>'.$quizName.'</td>';
                            $tempText .= '<td>'.$usersCount.'</td>';
                            $tempText .= '<td>'.$allAttempsToPass.'</td>';
                            $tempText .= '<td>'.$failedCount.'</td>';
                            $tempText .= '<td>'.$passedUsers.'</td>';

                            $attemptAvg = number_format(($allAttempsToPass / $passedUsers), 2, '.', '');
                            $tempText .= '<td>'.$attemptAvg.'</td>';
                            $tempText .= '</tr>';
                        }

                    }

                }
            }  else if ($user === 'admin_all_user_self') {
                $roles = get_user_roles($context, $USER->id, true);
                $role = key($roles);
                $rolename = $roles[$role]->shortname;
                if ($rolename === 'manager') {
                    return $this->course_student_avg_attempts_to_pass('all', $plot);
                } else if ($rolename === 'editingteacher') {
                    return $this->course_student_avg_attempts_to_pass('user', $plot);
                }
            }

            $tempText .= "\t".'</table>'.PHP_EOL.'</div>'.'<br>';
        } else {
            // is chart
            if ($user === 'user') {
                $userCourseQuery =
                    "SELECT DISTINCT cc.id AS cid, cc.fullname AS coursename
                    FROM {user} u
                    JOIN {user_enrolments} ue ON ue.userid = u.id
                    JOIN {enrol} e ON e.id = ue.enrolid
                    JOIN {context} c ON c.instanceid = e.courseid
                    JOIN {role_assignments} ra ON (ra.userid = u.id AND ra.contextid = c.id)
                    JOIN {role} r ON ra.roleid = r.id
                    JOIN {course} cc ON e.courseid = cc.id
                    WHERE u.id = {$uid} AND u.deleted = 0 AND cc.id IS NOT NULL AND (r.shortname = 'editingteacher')
                    GROUP BY cc.id";

                $userCourses = array_values($DB->get_records_sql($userCourseQuery));
                $tempText .= '<div id="div_class">'.PHP_EOL.
                    "\t".'<h3 class="main_title">میانگین تعداد تلاش ها برای قبولی در آزمون ها در دوره های '.$username.'</h3>'.PHP_EOL;

                foreach ($userCourses as $currentCourse) {
                    $passedQuizAttemptsQuery =
                        "SELECT qa.id AS qaid, q.id as qid, c.fullname AS coursename, u.username as username, qa.attempt as attempts, q.name AS quiz, (q.sumgrades / 2) AS quiz_sum, ROUND(MAX(qa.sumgrades), 2) AS grade, COUNT(DISTINCT u.id) as attemptedUsers
                        FROM {quiz_attempts} qa
                        JOIN {quiz} q ON qa.quiz = q.id
                        JOIN {course} c ON q.course = c.id
                        JOIN {user} u ON u.id = qa.userid
                        JOIN {role_assignments} ra ON ra.userid = u.id
                        JOIN {role} r ON ra.roleid = r.id
                        WHERE u.deleted = 0 AND r.shortname = 'student' AND c.id = {$currentCourse->cid} AND qa.state = 'finished'
                        GROUP BY qa.id";
                    $passedQuizAttempts = array_values($DB->get_records_sql($passedQuizAttemptsQuery));

                    $quizGroupedArray = [];
                    foreach ($passedQuizAttempts as $attempts) {
                        $quizGroupedArray[$attempts->qid][] = $attempts;
                    }
                    $groupX = [];
                    $groupY = [];
                    foreach ($quizGroupedArray as $quiz => $results) {
                        $attemptsByUser = [];
                        $passedUsers = 0;
                        $allAttempsToPass = 0;
                        foreach ($results as $result) {
                            $attemptsByUser[$result->username][] = $result;
                        }
                        foreach ($attemptsByUser as $username => $userAttempt) {
                            $userAttemptCount = 0;
                            foreach ($userAttempt as $currentAttempt) {
                                $userAttemptCount += 1;

                                if ($currentAttempt->grade >= $currentAttempt->quiz_sum) {
                                    $passedUsers += 1;
                                    $allAttempsToPass += $userAttemptCount;
                                    break;
                                }
                            }
                        }
                        $usersCount = count($attemptsByUser);
                        $failedCount = $usersCount - $passedUsers;
                        $quizName = $DB->get_record('quiz', ['id'=>$quiz])->name;



                        if ($usersCount > 0) {
                            $attemptAvg = number_format(($allAttempsToPass / $passedUsers), 2, '.', '');

                            array_push($groupY, $attemptAvg);
                            array_push($groupX, $quizName.' با '.$passedUsers.' نفر قبولی و '.$usersCount.' نفر شرکت کننده');
                        }
                    }

                    if ($plot == 'line_sharp') {
                        $chart = new \core\chart_line();
                    } else if ($plot == 'line_smooth') {
                        $chart = new \core\chart_line();
                        $chart->set_smooth(true);

                    } else if ($plot == 'pie') {
                        $chart = new \core\chart_pie();

                    } else if ($plot == 'doughnut') {
                        $chart = new \core\chart_pie();
                        $chart->set_doughnut(true);
                    } else if ($plot == 'bar') {
                        $chart = new \core\chart_bar();
                    }

                    if (count($groupY) > 0) {
                        $series = new \core\chart_series($currentCourse->coursename, $groupY);
                        $chart->add_series($series);
                        $chart->set_labels($groupX);
                        $chart->set_title(' میانگین تعداد تلاش ها در دوره '.$currentCourse->coursename);
                        if ($plot !== 'pie' && $plot !== 'doughnut') $chart->get_yaxis(0, true)->set_min(0);

                        $tempText .= $OUTPUT->render($chart).'<br>';
                    } else {
                        $tempText .= '<h3>میانگین تعداد تلاش ها برای دوره '.$currentCourse->coursename.' وجود ندارد.</h3><br>';
                    }
                }
            } else if ($user === 'all') {
                $userCourseQuery =
                    "SELECT DISTINCT cc.id AS cid, cc.fullname AS coursename
                    FROM {user} u
                    JOIN {user_enrolments} ue ON ue.userid = u.id
                    JOIN {enrol} e ON e.id = ue.enrolid
                    JOIN {context} c ON c.instanceid = e.courseid
                    JOIN {role_assignments} ra ON (ra.userid = u.id AND ra.contextid = c.id)
                    JOIN {role} r ON ra.roleid = r.id
                    JOIN {course} cc ON e.courseid = cc.id
                    WHERE u.deleted = 0 AND cc.id IS NOT NULL AND (r.shortname = 'editingteacher')
                    GROUP BY cc.id";

                $userCourses = array_values($DB->get_records_sql($userCourseQuery));
                $tempText .= '<div id="div_class">'.PHP_EOL.
                    "\t".'<h3 class="main_title">میانگین تعداد تلاش ها برای قبولی در تمام دوره ها </h3>'.PHP_EOL;

                foreach ($userCourses as $currentCourse) {
                    $passedQuizAttemptsQuery =
                        "SELECT qa.id AS qaid, q.id as qid, c.fullname AS coursename, u.username as username, qa.attempt as attempts, q.name AS quiz, (q.sumgrades / 2) AS quiz_sum, ROUND(MAX(qa.sumgrades), 2) AS grade, COUNT(DISTINCT u.id) as attemptedUsers
                        FROM {quiz_attempts} qa
                        JOIN {quiz} q ON qa.quiz = q.id
                        JOIN {course} c ON q.course = c.id
                        JOIN {user} u ON u.id = qa.userid
                        JOIN {role_assignments} ra ON ra.userid = u.id
                        JOIN {role} r ON ra.roleid = r.id
                        WHERE u.deleted = 0 AND r.shortname = 'student' AND c.id = {$currentCourse->cid} AND qa.state = 'finished'
                        GROUP BY qa.id";
                    $passedQuizAttempts = array_values($DB->get_records_sql($passedQuizAttemptsQuery));

                    $quizGroupedArray = [];
                    foreach ($passedQuizAttempts as $attempts) {
                        $quizGroupedArray[$attempts->qid][] = $attempts;
                    }
                    $groupX = [];
                    $groupY = [];
                    foreach ($quizGroupedArray as $quiz => $results) {
                        $attemptsByUser = [];
                        $passedUsers = 0;
                        $allAttempsToPass = 0;
                        foreach ($results as $result) {
                            $attemptsByUser[$result->username][] = $result;
                        }
                        foreach ($attemptsByUser as $username => $userAttempt) {
                            $userAttemptCount = 0;
                            foreach ($userAttempt as $currentAttempt) {
                                $userAttemptCount += 1;

                                if ($currentAttempt->grade >= $currentAttempt->quiz_sum) {
                                    $passedUsers += 1;
                                    $allAttempsToPass += $userAttemptCount;
                                    break;
                                }
                            }
                        }
                        $usersCount = count($attemptsByUser);
                        $failedCount = $usersCount - $passedUsers;
                        $quizName = $DB->get_record('quiz', ['id'=>$quiz])->name;



                        if ($usersCount > 0) {
                            $attemptAvg = number_format(($allAttempsToPass / $passedUsers), 2, '.', '');

                            array_push($groupY, $attemptAvg);
                            array_push($groupX, $quizName.' با '.$passedUsers.' نفر قبولی و '.$usersCount.' نفر شرکت کننده');
                        }
                    }

                    if ($plot == 'line_sharp') {
                        $chart = new \core\chart_line();
                    } else if ($plot == 'line_smooth') {
                        $chart = new \core\chart_line();
                        $chart->set_smooth(true);

                    } else if ($plot == 'pie') {
                        $chart = new \core\chart_pie();

                    } else if ($plot == 'doughnut') {
                        $chart = new \core\chart_pie();
                        $chart->set_doughnut(true);
                    } else if ($plot == 'bar') {
                        $chart = new \core\chart_bar();
                    }

                    if (count($groupY) > 0) {
                        $series = new \core\chart_series($currentCourse->coursename, $groupY);
                        $chart->add_series($series);
                        $chart->set_labels($groupX);
                        $chart->set_title(' میانگین تعداد تلاش ها در دوره '.$currentCourse->coursename);
                        if ($plot !== 'pie' && $plot !== 'doughnut') $chart->get_yaxis(0, true)->set_min(0);

                        $tempText .= $OUTPUT->render($chart).'<br>';
                    } else {
                        $tempText .= '<h3>میانگین تعداد تلاش ها برای دوره '.$currentCourse->coursename.' وجود ندارد.</h3><br>';
                    }
                }
            }  else if ($user === 'admin_all_user_self') {
                $roles = get_user_roles($context, $USER->id, true);
                $role = key($roles);
                $rolename = $roles[$role]->shortname;
                if ($rolename === 'manager') {
                    return $this->course_student_avg_attempts_to_pass('all', $plot);
                } else if ($rolename === 'editingteacher') {
                    return $this->course_student_avg_attempts_to_pass('user', $plot);
                }
            }
            $tempText .= "\t".PHP_EOL.'</div>'.'<br>';
        }

        return $tempText;

	}

}

?>